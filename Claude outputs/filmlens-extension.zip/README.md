# FilmLens — Film Breakdown Recorder

A Chrome extension that sits beside you while you watch a film on YouTube,
counts every cut, groups the scenes, measures the composition, and records your
own notes into one data file.

**There is not a single line of AI in it.** No API key, no server, no network
request. Everything happens inside your browser, so it costs nothing. The
thinking happens afterwards — hand the exported file to Claude and ask for the
report, or print the built-in PDF.

---

## Install (2 minutes)

1. Put the `filmlens` folder somewhere permanent. If you move or delete it, the
   extension stops working.
2. Open `chrome://extensions` in Chrome.
3. Turn on **Developer mode**, top right.
4. Click **Load unpacked** and select the `filmlens` folder — the one containing
   `manifest.json`.
5. Done. Open any YouTube video and the panel appears at the bottom right.

No need to publish to the Chrome Web Store. This is for your own use.

**Hover any button in the panel** for a three-line card: what it does, when to
press it, why it matters. You never have to remember a shortcut.

---

## Using it

Open a film, press **⏺ Start recording**, and play. `⌥H` hides the panel while
recording continues in the background.

### Two modes

**Silent** never interrupts. You press keys, the extension quietly counts cuts
and scenes. Use this on a first watch.

**Dissect** pauses at every detected scene boundary and asks two questions
about the scene that just ended: its emotional charge, and whether it was
essential. Use this on a rewatch. `⌥D` toggles.

### Keys (⌥ is Option on Mac, Alt on Windows)

| Key | What it does |
|-----|------|
| `⌥1` | 🔥 Hooked — the film had you here |
| `⌥2` | 😐 Drifted — attention slipped here |
| `⌥Q` | 🔄 Switch lens (Free → Story → Screenplay → Dialogue → DOP → Director → Editor) |
| `⌥3`–`⌥8` | The active lens's six markers — meaning changes with the lens |
| `⌥T` | ⚡ Turning point (saves the frame) |
| `⌥C` | 🎭 Character beat |
| `⌥S` | 🎞 Shot to keep (saves the frame) |
| `⌥B` | ✂ New scene starts here — overrides the automatic detection |
| `⌥N` | ✍️ Note — pauses the film |
| `⌥G` | 📐 Composition grid on / off |
| `⌥L` / `⌥U` | Next / previous guide (fourteen of them) |
| `⌥O` | Flip the golden spiral |
| `⌥W` | 👁 Machine lines on / off |
| `⌥M` | 📊 Measure this frame |
| `⌥F` | 🏷 Tag palette — 75 techniques, searchable |
| `⌥Y` | 🖊 Pen on / off — draw straight on the frame |
| `⌥Z` / `⌥X` | Undo last stroke / clear the drawing |
| `⌥P` | 📸 Snapshot — clean PNG + grid PNG |
| `Alt+Shift+K` | 📷 Screen capture — the whole tab (a real Chrome shortcut) |
| `⌥R` | Recording on / off |
| `⌥E` | Export ZIP |
| `⌥J` | Export PDF report |
| `⌥H` | Hide / show the panel |

Every key also has a button in the panel, so the shortcuts are optional. The
note box accepts dictation.

---

## Six lenses — one film, six pairs of eyes

A lens bar sits at the top of the panel. `⌥Q` switches lens; the `☰` button
chooses which lenses stay in the rotation for this film.

**Only one lens runs at a time, and that is the whole design.** A DOP and a
story writer notice different things in the same scene; trying to do both at
once means doing neither. "Multiple roles" means **multiple passes** — watch
once as a story writer, again as a DOP, again as an editor. All three passes
land in the same session file and become three separate chapters in the report.

| Lens | The six markers (`⌥3`–`⌥8`) |
|---|---|
| 🖋 **Story Writer** | Setup · Payoff (links back to its setup) · Turn · Want/Need · Stakes · Theme |
| 📄 **Screenplay Writer** | Charge in→out · Conflict · Exposition · Late-in/early-out · Essential? · Act break |
| 💬 **Dialogue Writer** | Subtext · Keeper line · On-the-nose · Character voice · Silence · Hidden info |
| 🎥 **Cinematographer / DOP** | Shot size + why · Framing grid · Angle · Movement · Light · Great frame |
| 🎬 **Director** | Audience feel · Scene's job · Whose scene · Blocking · Performance · Why here |
| ✂️ **Editor** | Trim earlier · Hold longer · Cut on · Transition · Pace · Verdict |

**Two kinds of marker.** Some log in one tap and never stop the film. Others
open a card — the film pauses, one question is asked, Enter saves. Card buttons
carry an amber stripe down the left, so you know in advance which will pause.

**The machine helps in two lenses only.** In DOP and Editor the extension has
already measured the answer — camera movement, framing grid, depth, shot length
— so the card opens **pre-filled** and you only confirm or correct. In Story,
Screenplay and Dialogue there is nothing to measure, so the card simply asks
and the answer is entirely yours. That is a design decision, not a gap: filling
in a guess would teach you something false.

DOP and Editor are meant to be used paused; Story and Director work while the
film plays. The readout changes with the lens too — framing and movement for
DOP, shot length against the film average for Editor, percentage through the
film and act guess for Story.

---

## Composition — three layers

### 1. Guides — the extension draws, you judge

`⌥G` turns the grid on, `⌥L` cycles through fourteen guides: Rule of Thirds,
Golden Ratio (phi), Golden Spiral, Golden Triangle, Dynamic Symmetry armature,
Centre/Bullseye, Diagonals, Symmetry Axis, Radial, Horizon + Eyeline, Look Room
+ Headroom, 9:16 + 1:1 crop box, Quadrants, and off.

Lines land on the actual picture, not the whole video: baked-in black bars are
detected and excluded, with two guards so a genuinely dark night scene is never
mistaken for a letterbox.

### 2. Measurement — numbers, no AI

Press `⌥M`, or keep machine lines on with `⌥W`:

- **Visual weight** — where the frame's weight sits (green dot) and how far the
  nearest compositional anchor is (red line). This is what tells you the frame
  sits on the thirds, on phi, or dead centre.
- **Symmetry score**, plus left/right and top/bottom balance.
- **Dominant line angles** — horizontal, vertical, diagonal counts — and how
  many degrees the camera is tilted.
- **Vanishing point**, when the lines genuinely converge.
- **Negative space** percentage, tonal and texture contrast, figure-ground
  separation, focus ratio (soft background or all sharp), depth bands, dominant
  hues, and the light pool.
- **Camera movement** per shot — static / pan / tilt / zoom / handheld / drift,
  from block-matching successive frames.
- **Frame rate** — measured fps, likely source (24/25/30), duplicate frames
  (24fps carried in a 30fps stream — telecine), and timing jitter.

Grid on means **two layers** are running. Orange lines are the guide and never
change, like graph paper. Blue lines and coloured dots are the machine's own
reading, and they change twice a second because the picture changes. On a
moving film the blue line means little — **pause to read it**.

All of this is **evidence, not verdict**. The engine knows where a frame is
heavy; it does not know what the subject is. In a close-up those are the same
thing; in a crowded wide they are not.

A note on aperture: **f-stop cannot be read from a video by anything.** It
lives in camera metadata that never reaches the file. What can be measured is
how soft the background is, which is the part that actually matters on screen.

### 3. Tags — the machine asks, you answer

`⌥F` opens a palette of **75 techniques in 10 groups** — grid, lines, symmetry,
depth, subject placement, movement, contrast, lighting, psychological, and film
grammar (180° rule, eyeline match, blocking, motivated framing, visual motif…).

Type two letters, press Enter, tagged. A section at the top — **"✨ The
measurements suggest"** — shows what the maths already found, so you tick rather
than recall. That is why 75 techniques stay usable without memorising them.

---

## Pen tool

`⌥Y` turns the pen on. The film pauses and you can draw straight onto the
frame: circle a subject, trace a leading line, mark a headroom problem. Press
the Pen button again to change colour, `⌥Z` to undo a stroke, `⌥X` to clear.

**Pen marks are burned into every frame the extension saves after that** — the
snapshot, the scene keyframes, the tagged frames, the lens marks and the PDF.
That is the point: your explanation travels with the picture.

Pen strokes are stored as fractions of the picture area, so they stay put when
the player is resized or goes fullscreen.

---

## Two kinds of capture

**📸 Snapshot (`⌥P`)** draws from the video itself, at full video resolution.
Two PNGs: one clean frame and one with the grid burned in. Pen marks appear in
both. This is the one to use for teaching material.

**📷 Screen capture (`Alt+Shift+K`)** captures the whole visible tab instead,
then crops to the player. Lower resolution — viewport pixels, not video pixels
— but it includes **anything another extension has drawn on the page**. If you
use a separate highlighter or circle tool, this is the only capture that can
see it; the canvas snapshot cannot, because it only ever sees the video.

**Why this one needs a different key.** Chrome hands out tab-capture permission
only when the user triggers an extension through Chrome itself — a keyboard
command, the toolbar icon, a context menu. A button drawn inside the page does
not count, whatever host permissions the extension holds. So screen capture
lives on a real Chrome command (`Alt+Shift+K`), and the panel button exists to
remind you of that key. If the shortcut is taken by something else, reassign it
at `chrome://extensions/shortcuts`.

The alternative is to grant the extension access to all sites, which would make
the in-panel button work directly. That is a much broader permission than this
extension needs, so it is deliberately not requested.

---

## Export

**⬇ ZIP (`⌥E`)** — everything in one archive:

```
session.json       → the full data (this is what you hand to Claude)
scenes.csv         → scene log, opens in Excel or Sheets
shots.csv          → every shot, with its camera movement
markers.csv        → your markers
role_marks.csv     → every lens mark with its answers
composition.csv    → the composition numbers per measured frame
tags.csv           → which technique you tagged where
transcript.txt     → if captions were available
ANALYSE_ME.md      → a ready-made prompt for building the report
frames/*.jpg       → scene keyframes, marked shots, tagged and lens frames
```

**📄 PDF (`⌥J`)** — a printable study report built inside the browser: the
session's numbers, the pacing extremes, your attention track, one chapter per
lens with every mark and its answers, your saved frames, the technique tags and
the scene log.

**JSON** — just the data, no images, small file.

Sessions save themselves continuously, so you can leave a film half-watched and
pick it up the next day. ⚙ → Reset session clears one film.

---

## Getting a report

Attach the ZIP (or just `session.json`) to Claude and ask:

> Here is a FilmLens session. Build me a full breakdown report — structure map
> with timestamps, pacing analysis, scene log, how my own engagement markers
> compare with the film's craft, one chapter per lens, and ten reel-ready
> observations.

The same prompt is inside the ZIP as `ANALYSE_ME.md`.

---

## When it will not work

- **DRM-protected video.** Rented or purchased films on YouTube, and streaming
  apps, run the video through a protected path the browser will not let any code
  read. Frames come back black, so cut detection, colour, composition and
  snapshots all get nothing. The extension detects this and shows **DRM** in the
  status tile. Normal YouTube uploads work fine — which includes a great many
  classic films.
- Dissolves and very slow transitions are sometimes missed or double-counted.
  Tune the **cut sensitivity** slider in ⚙ settings.
- Scene grouping is a weighted guess from colour, brightness, shot rhythm and
  dialogue gaps — not an understanding of the story. Treat the boundaries as a
  strong first draft and correct them with `⌥B`, which always wins.

---

## Settings (⚙ in the panel)

- **Cut sensitivity** — higher catches more cuts and more mistakes. Lower it for
  action films.
- **Scene split** — higher makes more scenes, lower makes fewer.
- **Min scene length** — no scene shorter than this. Default 12s.
- **Live captions capture** — records captions while they are on.
- **Scene keyframes** — saves one frame per scene.
- **Measure composition** — measures marked frames and scene keyframes.
- **Clean mode** — dims every line and hides the labels, for when you want to
  look at the picture rather than the geometry.
- **Transcript import** — open YouTube's transcript panel, then press this.
- **Reset session** — erases everything for this film.

---

## Testing

`node test/harness.mjs` runs the whole suite with no browser: cut detection on
synthetic frames, scene-split scoring, the composition engine, guide rendering,
camera-movement classification, frame-rate estimation, the role lenses and their
prefill, the hover-help text, the ZIP writer and the PDF writer.

---

Version 1.6.0 · Everything local. Nothing leaves your browser.

---

## Invite-code access

FilmLens is locked behind an email + invite code, checked against
`tools.u2berclub.com`. The server side is installed inside the u2berhub repo —
an ESM Express router at `server/filmlens.js`, two tables appended to
`server/db/schema.sql`, and a **FilmLens keys** tab in the existing admin page.
`server/README.md` here has the deploy steps and the endpoint list.

How it behaves: the popup asks for email and code once per browser profile, the
server checks the code and its device seats, and returns a token signed RS256
with a private key that never leaves the server. The extension verifies that
token offline against the public key baked into `src/licence.js`, so it keeps
working for 30 days without reaching the server — one VPS hiccup must never
lock out a whole cohort. Only an explicit revoke locks someone out, at their
next daily check.

Admins generate keys from the hub's own admin page, using the hub's own login —
there is no separate admin password. Each key allows two devices by default,
binds to the first email that uses it, and can be revoked or have its seats
freed from the same table.

**Stated plainly:** this is access control, not copy protection. An extension's
code lives on the user's machine, so a technical person can delete the check
and reload. What it genuinely does is stop the folder working when it gets
forwarded, show you who is using it and from how many devices, and let you take
access away.

---

Version 1.6.1 · Everything local. Nothing leaves your browser except the once-a-day licence check.
