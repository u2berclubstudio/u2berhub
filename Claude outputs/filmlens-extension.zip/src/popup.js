/* Popup — activation screen when locked, session list when active.
   All network calls go through the service worker, which holds the host
   permission for the licence server. */

const $ = (id) => document.getElementById(id);

function ask(msg) {
  return new Promise((resolve) => {
    try {
      chrome.runtime.sendMessage(msg, (res) => resolve(res || { ok: false, error: "No response from the extension." }));
    } catch (e) {
      resolve({ ok: false, error: String(e && e.message ? e.message : e) });
    }
  });
}

function show(which) {
  $("gate").style.display = which === "gate" ? "block" : "none";
  $("main").style.display = which === "main" ? "block" : "none";
}

function setStatus(text, kind) {
  const el = $("gate-status");
  el.textContent = text || "";
  el.className = "status" + (kind ? " " + kind : "");
}

async function renderSessions() {
  const all = await new Promise((r) => chrome.storage.local.get(null, (x) => r(x || {})));
  const el = $("stats");
  const keys = Object.keys(all).filter((k) => k.startsWith("fl_") && k !== "fl_licence" && k !== "fl_device");
  if (!keys.length) {
    el.textContent = "No sessions saved yet.";
    return;
  }
  el.innerHTML =
    `<div style="margin-bottom:6px;color:#ffb454">Saved sessions</div>` +
    keys
      .map((k) => all[k])
      .filter((s) => s && s.video)
      .sort((a, b) => (b.started_at || "").localeCompare(a.started_at || ""))
      .slice(0, 6)
      .map((s) => {
        const title = (s.video.title || s.video.id).slice(0, 34);
        return `<div style="margin-bottom:4px"><b style="color:#e8eaed">${title}</b><br>${
          (s.shots || []).length
        } shots · ${(s.scenes || []).length} scenes · ${(s.markers || []).length} markers · ${
          (s.role_marks || []).length
        } lens marks</div>`;
      })
      .join("");
}

async function refreshView() {
  const lic = await ask({ type: "filmlens:licence.check" });
  if (lic && lic.active) {
    show("main");
    $("licence-line").innerHTML =
      `<b>${lic.email}</b> · code ${lic.code} · ${lic.days_left} day${lic.days_left === 1 ? "" : "s"} left on this check`;
    renderSessions();
  } else {
    show("gate");
    if (lic && lic.reason === "no_public_key") {
      setStatus("This build has no licence key yet — run the keygen script on the server.", "bad");
      $("gate-activate").disabled = true;
    } else if (lic && lic.reason === "expired") {
      setStatus("Your licence expired. Enter the same email and code to renew.", "warn");
    } else if (lic && lic.reason === "wrong_device") {
      setStatus("This licence belongs to a different browser profile. Activate again here.", "warn");
    }
  }
}

$("gate-activate").addEventListener("click", async () => {
  const email = $("gate-email").value;
  const code = $("gate-code").value;
  $("gate-activate").disabled = true;
  setStatus("Checking…");
  const res = await ask({ type: "filmlens:licence.activate", email, code });
  $("gate-activate").disabled = false;
  if (res && res.ok) {
    setStatus("Activated. Reload the YouTube tab to start.", "good");
    setTimeout(refreshView, 900);
  } else {
    setStatus((res && res.error) || "Activation failed.", "bad");
  }
});

$("gate-code").addEventListener("keydown", (e) => {
  if (e.key === "Enter") $("gate-activate").click();
});

$("signout").addEventListener("click", async () => {
  if (!confirm("Sign out and free this device's seat?")) return;
  await ask({ type: "filmlens:licence.deactivate" });
  refreshView();
});

refreshView();
