/* FilmLens — content script.
   Everything here runs inside your own browser tab. No API keys, no network
   requests, no AI. It watches the film alongside you, records the craft data
   that can be measured mechanically (cuts, shot lengths, scene boundaries,
   colour, pacing) and the judgement data only you can give (markers, notes,
   emotional charge). Then it hands you a file.
*/
(function () {
  "use strict";

  const FL = (window.__FILMLENS = window.__FILMLENS || {});
  const VERSION = "1.6.1";

  // ---------------------------------------------------------------- state --
  let S = null; // session
  let detector = null;
  let video = null;
  let panel = null;
  let card = null;
  let rafHandle = null;
  let pollHandle = null;
  let saveTimer = null;
  let lastSampled = -1;
  let currentVideoId = null;
  let capCanvas = null;
  let warnedDrm = false;

  const DEFAULTS = {
    sensitivity: 0.5,
    minShot: 0.3,
    minScene: 12,
    sceneSensitivity: 0.5,
    dissect: false,
    captureCaptions: true,
    autoKeyframes: true,
    overlayOn: false,
    guide: "thirds",
    showWeight: true,
    spiralFlip: 0,
    composition: true,
    clean: false,
    role: "free",
    rolesEnabled: ["story", "screenplay", "dialogue", "dop", "director", "editor"],
    pen: false,
    penColor: 0,
    penWidth: 3,
  };

  const CHARGES = [
    "Hope", "Tension", "Fear", "Joy", "Loss",
    "Anger", "Calm", "Doubt", "Relief", "Suspicion",
  ];

  // ---------------------------------------------------------------- utils --
  const $ = (sel, root = document) => root.querySelector(sel);

  function fmt(t) {
    if (!isFinite(t)) return "0:00";
    const h = Math.floor(t / 3600);
    const m = Math.floor((t % 3600) / 60);
    const s = Math.floor(t % 60);
    return h > 0
      ? `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`
      : `${m}:${String(s).padStart(2, "0")}`;
  }

  function hex(c) {
    const h = (v) => v.toString(16).padStart(2, "0");
    return `#${h(c.r)}${h(c.g)}${h(c.b)}`;
  }

  function colorDist(a, b) {
    const dr = a.r - b.r, dg = a.g - b.g, db = a.b - b.b;
    return Math.sqrt(dr * dr + dg * dg + db * db) / 441.673;
  }

  function toast(msg, ms = 1600) {
    let el = $("#filmlens-toast");
    if (!el) {
      el = document.createElement("div");
      el.id = "filmlens-toast";
      document.body.appendChild(el);
    }
    el.textContent = msg;
    el.classList.add("show");
    clearTimeout(el._t);
    el._t = setTimeout(() => el.classList.remove("show"), ms);
  }

  function download(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  }

  function safeName(str) {
    return (str || "film")
      .replace(/[^\w\d\s.-]/g, "")
      .trim()
      .replace(/\s+/g, "_")
      .slice(0, 60) || "film";
  }

  function csvCell(v) {
    if (v === null || v === undefined) return "";
    const s = String(v);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  }

  function toCsv(rows, headers) {
    const lines = [headers.join(",")];
    for (const r of rows) lines.push(headers.map((h) => csvCell(r[h])).join(","));
    return lines.join("\n");
  }

  // ------------------------------------------------------------- session ---
  function blankSession(videoId) {
    return {
      filmlens_version: VERSION,
      video: {
        id: videoId,
        url: location.href.split("&")[0],
        title: document.title.replace(/ - YouTube$/, ""),
        channel: "",
        duration_sec: 0,
      },
      started_at: new Date().toISOString(),
      settings: { ...DEFAULTS },
      recording: false,
      shots: [],
      scenes: [],
      markers: [],
      notes: [],
      transcript: [],
      engagement: [],
      tags: [],
      role_marks: [],
      frames: {}, // id -> dataURL
      sampled_seconds: 0,
      frame_rate: null,
      flags: { drm_suspected: false },
      _open: { shot: null, scene: null, lastCharge: null },
    };
  }

  function storageKey(id) {
    return "fl_" + id;
  }

  function saveSoon() {
    if (saveTimer) return;
    saveTimer = setTimeout(() => {
      saveTimer = null;
      try {
        chrome.storage.local.set({ [storageKey(S.video.id)]: S });
      } catch (e) {
        /* storage full or extension reloaded — keep going, export still works */
      }
    }, 4000);
  }

  function loadSession(videoId) {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.get(storageKey(videoId), (res) => {
          const saved = res && res[storageKey(videoId)];
          resolve(saved && saved.shots ? saved : blankSession(videoId));
        });
      } catch (e) {
        resolve(blankSession(videoId));
      }
    });
  }

  // ------------------------------------------------------------ keyframes --
  function grabFrame(quality = 0.72, width = 384) {
    if (!video || video.readyState < 2) return null;
    if (!capCanvas) capCanvas = document.createElement("canvas");
    const ar = (video.videoHeight || 9) / (video.videoWidth || 16);
    capCanvas.width = width;
    capCanvas.height = Math.round(width * ar);
    try {
      const ctx = capCanvas.getContext("2d");
      ctx.drawImage(video, 0, 0, capCanvas.width, capCanvas.height);
      // anything drawn with the pen belongs to the frame from here on
      if (strokes.length) {
        const pb = lastAnalysis && !lastAnalysis.error ? lastAnalysis.picture_box : null;
        drawStrokesOn(ctx, pb
          ? { x: capCanvas.width * pb.x, y: capCanvas.height * pb.y, w: capCanvas.width * pb.w, h: capCanvas.height * pb.h }
          : { x: 0, y: 0, w: capCanvas.width, h: capCanvas.height });
      }
      return capCanvas.toDataURL("image/jpeg", quality);
    } catch (e) {
      return null;
    }
  }

  // ================================================ composition overlay ====
  let overlay = null;
  let overlayCtx = null;
  let lastAnalysis = null;      // raw, for markers / scenes / export
  let displayAnalysis = null;   // smoothed, for the live overlay only
  let smoother = null;
  let lastAnalyzeAt = 0;
  let motion = null;
  let overlayTimer = null;

  function playerEl() {
    return $("#movie_player") || (video && video.parentElement) || document.body;
  }

  function ensureOverlay() {
    if (!overlay) {
      overlay = document.createElement("canvas");
      overlay.id = "filmlens-overlay";
      overlayCtx = overlay.getContext("2d");
    }
    const host = document.fullscreenElement || playerEl();
    if (overlay.parentElement !== host) host.appendChild(overlay);
    return overlay;
  }

  /** the rect of the ACTUAL picture, minus element padding and black bars */
  function pictureRect() {
    if (!video) return null;
    const host = document.fullscreenElement || playerEl();
    const vr = video.getBoundingClientRect();
    const hr = host.getBoundingClientRect();
    if (!vr.width || !vr.height) return null;

    const dpr = window.devicePixelRatio || 1;
    overlay.style.left = vr.left - hr.left + "px";
    overlay.style.top = vr.top - hr.top + "px";
    overlay.style.width = vr.width + "px";
    overlay.style.height = vr.height + "px";
    if (overlay.width !== Math.round(vr.width * dpr) || overlay.height !== Math.round(vr.height * dpr)) {
      overlay.width = Math.round(vr.width * dpr);
      overlay.height = Math.round(vr.height * dpr);
    }
    overlayCtx.setTransform(dpr, 0, 0, dpr, 0, 0);

    // the video is letterboxed inside its own element (object-fit: contain)
    const va = (video.videoWidth || 16) / (video.videoHeight || 9);
    const ea = vr.width / vr.height;
    let cw = vr.width, ch = vr.height, cx = 0, cy = 0;
    if (ea > va) { cw = vr.height * va; cx = (vr.width - cw) / 2; }
    else { ch = vr.width / va; cy = (vr.height - ch) / 2; }

    // and the film may be letterboxed INSIDE the video frame itself
    const pb = lastAnalysis && !lastAnalysis.error ? lastAnalysis.picture_box : null;
    if (pb) {
      return { x: cx + cw * pb.x, y: cy + ch * pb.y, w: cw * pb.w, h: ch * pb.h };
    }
    return { x: cx, y: cy, w: cw, h: ch };
  }

  /**
   * Returns the RAW single-frame reading — that is what gets stored on a
   * marker or a scene. The smoothed copy lives in `displayAnalysis` and is
   * only for the live overlay and the panel readout, so the lines stop
   * flickering while the film plays.
   */
  function analyzeNow(force) {
    const now = performance.now();
    if (!force && now - lastAnalyzeAt < 420) return lastAnalysis;
    lastAnalyzeAt = now;
    const m = FL.Compose.analyze(video);
    if (m) {
      lastAnalysis = m;
      if (video && video.paused) {
        if (smoother) smoother.reset();
        displayAnalysis = m; // paused: the single reading is the honest one
      } else {
        displayAnalysis = smoother ? smoother.push(m) : m;
      }
    }
    return lastAnalysis;
  }

  function drawOverlay() {
    if (!S || !S.settings.overlayOn || !video) return;
    ensureOverlay();
    if (S.settings.showWeight) analyzeNow(false);
    const R = pictureRect();
    if (!R) return;
    overlayCtx.clearRect(0, 0, overlay.width, overlay.height);
    if (S.settings.guide === "none" && !S.settings.showWeight) return;
    FL.Compose.drawGuides(
      overlayCtx,
      R,
      {
        guide: S.settings.guide,
        spiralFlip: S.settings.spiralFlip || 0,
        showWeight: S.settings.showWeight,
        clean: S.settings.clean,
      },
      displayAnalysis || lastAnalysis
    );
  }

  function setOverlay(on) {
    S.settings.overlayOn = on;
    if (on) {
      ensureOverlay();
      overlay.style.display = "block";
      drawOverlay();
      redrawStrokes();
      if (!overlayTimer) overlayTimer = setInterval(() => { drawOverlay(); redrawStrokes(); }, 500);
    } else {
      if (overlay) overlay.style.display = "none";
      if (drawCanvas) drawCanvas.style.display = "none";
      if (overlayTimer) { clearInterval(overlayTimer); overlayTimer = null; }
    }
    render();
    saveSoon();
  }

  /** the blue detected lines + coloured dots — the machine's own reading */
  function toggleWeightLayer() {
    S.settings.showWeight = !S.settings.showWeight;
    if (S.settings.showWeight && !S.settings.overlayOn) {
      setOverlay(true);
    } else {
      drawOverlay();
      render();
      saveSoon();
    }
    toast(
      S.settings.showWeight
        ? "👁  Machine lines ON — detected lines and dots"
        : "👁  Machine lines OFF — clean grid only"
    );
  }

  function cycleGuide(dir) {
    const ids = FL.Compose.GUIDES.map((g) => g.id);
    let i = ids.indexOf(S.settings.guide);
    if (i < 0) i = 0;
    i = (i + dir + ids.length) % ids.length;
    S.settings.guide = ids[i];
    if (!S.settings.overlayOn) setOverlay(true);
    else { drawOverlay(); render(); saveSoon(); }
    const g = FL.Compose.GUIDES.find((x) => x.id === S.settings.guide);
    toast(`📐  ${g ? g.label : S.settings.guide}`);
  }

  function showReadout() {
    const m = analyzeNow(true);
    if (!m || m.error) {
      toast(m && m.error === "tainted" ? "DRM video — the frame cannot be read" : "Could not analyse this frame");
      return;
    }
    drawOverlay();
    render();
    toast(m.hints.slice(0, 2).join(" · "), 2600);
  }

  /** ⌥P — two PNGs: one with the guides burned in, one clean */
  function snapshot() {
    if (!video) return;
    const m = analyzeNow(true);
    const W = 1280;
    const vh = video.videoHeight || 9, vw = video.videoWidth || 16;
    const H = Math.round((W * vh) / vw);
    const c = document.createElement("canvas");
    c.width = W;
    c.height = H;
    const ctx = c.getContext("2d");
    try {
      ctx.drawImage(video, 0, 0, W, H);
    } catch (e) {
      toast("Frame capture failed — this looks like DRM video");
      return;
    }

    const base = `${safeName(S.video.title)}_${Math.round(video.currentTime)}s`;
    const pb = m && !m.error ? m.picture_box : null;
    const R = pb
      ? { x: W * pb.x, y: H * pb.y, w: W * pb.w, h: H * pb.h }
      : { x: 0, y: 0, w: W, h: H };

    // the "clean" frame still carries the pen marks — those are notes, not grid
    if (strokes.length) drawStrokesOn(ctx, R);
    c.toBlob((b) => b && download(b, `${base}_clean.png`), "image/png");

    // burned-in version: grid on top of frame + pen
    FL.Compose.drawGuides(
      ctx,
      R,
      { guide: S.settings.guide, spiralFlip: S.settings.spiralFlip || 0, showWeight: true },
      m
    );
    const c2 = document.createElement("canvas");
    c2.width = W;
    c2.height = H;
    c2.getContext("2d").drawImage(c, 0, 0);
    c2.toBlob((b) => b && download(b, `${base}_grid.png`), "image/png");

    toast("📸  Two PNGs downloading");
  }

  // ========================================================== pen tool ====
  // Draws on a layer of its own, above the guides. Strokes are stored as
  // fractions of the picture rect, so they stay put when the player resizes,
  // and they are burned into every frame the extension saves.
  let drawCanvas = null;
  let drawCtx = null;
  let strokes = [];
  let penStroke = null;
  const PEN_COLORS = ["#ffb454", "#f2726f", "#5ad19b", "#ffffff"];

  function ensureDraw() {
    if (!drawCanvas) {
      drawCanvas = document.createElement("canvas");
      drawCanvas.id = "filmlens-draw";
      drawCtx = drawCanvas.getContext("2d");
      drawCanvas.addEventListener("pointerdown", onPenDown);
      drawCanvas.addEventListener("pointermove", onPenMove);
      window.addEventListener("pointerup", onPenUp);
    }
    const host = document.fullscreenElement || playerEl();
    if (drawCanvas.parentElement !== host) host.appendChild(drawCanvas);
    return drawCanvas;
  }

  /** keep the draw layer exactly on top of the overlay */
  function syncDrawGeometry() {
    if (!drawCanvas || !overlay) return false;
    drawCanvas.style.left = overlay.style.left;
    drawCanvas.style.top = overlay.style.top;
    drawCanvas.style.width = overlay.style.width;
    drawCanvas.style.height = overlay.style.height;
    if (drawCanvas.width !== overlay.width || drawCanvas.height !== overlay.height) {
      drawCanvas.width = overlay.width;
      drawCanvas.height = overlay.height;
    }
    const dpr = window.devicePixelRatio || 1;
    drawCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
    return true;
  }

  function strokePath(ctx, stroke, rect) {
    if (!stroke.pts.length) return;
    ctx.save();
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.strokeStyle = stroke.color;
    ctx.lineWidth = Math.max(1.2, stroke.width * (rect.w / 600));
    ctx.beginPath();
    stroke.pts.forEach((p, i) => {
      const x = rect.x + p.x * rect.w;
      const y = rect.y + p.y * rect.h;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.stroke();
    ctx.restore();
  }

  /** burn the pen marks onto any canvas, given that canvas's picture rect */
  function drawStrokesOn(ctx, rect) {
    for (const s of strokes) strokePath(ctx, s, rect);
    if (penStroke) strokePath(ctx, penStroke, rect);
  }

  function redrawStrokes() {
    if (!overlay) return;
    ensureDraw();
    if (!syncDrawGeometry()) return;
    const R = pictureRect();
    drawCtx.clearRect(0, 0, drawCanvas.width, drawCanvas.height);
    if (!R) return;
    drawStrokesOn(drawCtx, R);
  }

  function penPoint(e) {
    const R = pictureRect();
    if (!R) return null;
    const box = drawCanvas.getBoundingClientRect();
    return {
      x: +((e.clientX - box.left - R.x) / R.w).toFixed(4),
      y: +((e.clientY - box.top - R.y) / R.h).toFixed(4),
    };
  }

  function onPenDown(e) {
    if (!S || !S.settings.pen) return;
    e.preventDefault();
    e.stopPropagation();
    const p = penPoint(e);
    if (!p) return;
    penStroke = {
      color: PEN_COLORS[S.settings.penColor || 0],
      width: S.settings.penWidth || 3,
      t: video ? +video.currentTime.toFixed(2) : 0,
      pts: [p],
    };
  }

  function onPenMove(e) {
    if (!penStroke) return;
    e.preventDefault();
    const p = penPoint(e);
    if (!p) return;
    const last = penStroke.pts[penStroke.pts.length - 1];
    if (Math.abs(p.x - last.x) < 0.002 && Math.abs(p.y - last.y) < 0.002) return;
    penStroke.pts.push(p);
    redrawStrokes();
  }

  function onPenUp() {
    if (!penStroke) return;
    if (penStroke.pts.length > 1) strokes.push(penStroke);
    penStroke = null;
    redrawStrokes();
    render();
  }

  function setPen(on) {
    S.settings.pen = on;
    if (on && !S.settings.overlayOn) setOverlay(true);
    ensureDraw();
    syncDrawGeometry();
    drawCanvas.style.display = "block";
    drawCanvas.style.pointerEvents = on ? "auto" : "none";
    drawCanvas.style.cursor = on ? "crosshair" : "default";
    if (on && video && !video.paused) video.pause();
    redrawStrokes();
    render();
    saveSoon();
    toast(on ? "🖊  Pen on — draw on the frame (⌥Z undo, ⌥X clear)" : "🖊  Pen off");
  }

  function penUndo() {
    if (!strokes.length) { toast("Nothing to undo"); return; }
    strokes.pop();
    redrawStrokes();
    render();
  }

  function penClear() {
    if (!strokes.length) { toast("Nothing to clear"); return; }
    strokes = [];
    redrawStrokes();
    render();
    toast("🖊  Drawing cleared");
  }

  function cyclePenColor() {
    S.settings.penColor = ((S.settings.penColor || 0) + 1) % PEN_COLORS.length;
    render();
    saveSoon();
    toast("🖊  Pen colour changed");
  }

  // ================================================= whole-tab screenshot ==
  /**
   * Captures the composited tab, which is the only way to include what OTHER
   * extensions have drawn on the page. Lower resolution than the canvas
   * snapshot (viewport pixels, not video pixels), and still black under DRM.
   */
  const CAPTURE_KEY = "Alt+Shift+K";

  /** crop a full-tab screenshot down to the player and save it */
  function processScreenshot(dataUrl) {
    if (!video) return;
    const vr = video.getBoundingClientRect();
    const img = new Image();
    img.onload = () => {
      const scale = img.width / window.innerWidth;
      const c = document.createElement("canvas");
      c.width = Math.max(1, Math.round(vr.width * scale));
      c.height = Math.max(1, Math.round(vr.height * scale));
      c.getContext("2d").drawImage(
        img,
        Math.round(vr.left * scale), Math.round(vr.top * scale),
        c.width, c.height,
        0, 0, c.width, c.height
      );
      c.toBlob((b) => {
        if (!b) { toast("Screen capture produced nothing"); return; }
        download(b, `${safeName(S.video.title)}_${Math.round(video.currentTime)}s_screen.png`);
        toast("📷  Screen capture saved — includes other extensions' drawings");
      }, "image/png");
    };
    img.onerror = () => toast("The screen capture image could not be read");
    img.src = dataUrl;
  }

  /**
   * Chrome only hands out capture permission when the user triggers the
   * extension through Chrome itself, so the keyboard command is the real path
   * and this button exists to say so clearly rather than fail silently.
   */
  function captureScreen() {
    if (!video) return;
    toast("📷  Capturing the tab…");
    try {
      chrome.runtime.sendMessage({ type: "filmlens:captureTab" }, (res) => {
        if (res && res.ok) {
          processScreenshot(res.dataUrl);
          return;
        }
        if (res && res.needsShortcut) {
          toast(
            `Chrome allows tab capture only from its own shortcut — press ${CAPTURE_KEY} instead`,
            5200
          );
          showWarn(
            `Screen capture: press ${CAPTURE_KEY} (Chrome grants capture permission only for its own shortcut). ` +
              `Set or change that key at chrome://extensions/shortcuts.`
          );
          render();
          return;
        }
        toast(`Screen capture failed — ${(res && res.error) || "no response from the extension"}`, 4000);
      });
    } catch (e) {
      toast("Reload the extension at chrome://extensions, then press " + CAPTURE_KEY, 4600);
    }
  }

  // the service worker pushes the captured image back through here
  try {
    chrome.runtime.onMessage.addListener((msg) => {
      if (!msg) return;
      if (msg.type === "filmlens:screenshot") processScreenshot(msg.dataUrl);
      if (msg.type === "filmlens:screenshotFailed") {
        toast(`Screen capture failed — ${msg.error || "unknown error"}`, 4000);
      }
    });
  } catch (e) {
    /* no extension context (test harness) — ignore */
  }

  // ------------------------------------------------------------- tagging ---
  function showTagPalette() {
    if (!video) return;
    const wasPlaying = !video.paused;
    video.pause();
    closeCard(false);

    const t = video.currentTime;
    const m = analyzeNow(true);
    const suggested = m && !m.error ? m.suggested : [];
    const chosen = new Set();

    card = document.createElement("div");
    card.id = "filmlens-card";
    card.classList.add("fl-wide");
    card.innerHTML = `
      <h3>Composition tag — ${fmt(t)}</h3>
      <div class="fl-sub">${
        m && !m.error ? m.hints.slice(0, 3).join(" · ") : "frame could not be analysed"
      }</div>
      <input id="fl-tagsearch" class="fl-search" placeholder="Type to search — thirds, chiaroscuro, blocking…" autocomplete="off">
      <div class="fl-taglist" id="fl-taglist"></div>
      <div class="fl-card-actions">
        <span class="fl-hint"><b id="fl-tagcount">0</b> selected · Enter = top match · Esc = close</span>
        <button class="fl-btn primary" id="fl-tagsave">Save</button>
      </div>`;
    document.body.appendChild(card);

    const listEl = $("#fl-taglist", card);
    const countEl = $("#fl-tagcount", card);
    const search = $("#fl-tagsearch", card);

    function paint(q) {
      const hits = FL.Tags.search(q);
      const sugg = hits.filter((x) => suggested.includes(x.id));
      const rest = hits.filter((x) => !suggested.includes(x.id));
      let html = "";
      if (sugg.length) {
        html += `<div class="fl-taggroup">✨ The measurements suggest</div><div class="fl-chips">`;
        html += sugg.map((x) => chip(x, true)).join("");
        html += `</div>`;
      }
      let lastGroup = null;
      for (const x of rest) {
        if (x.group !== lastGroup) {
          if (lastGroup !== null) html += `</div>`;
          html += `<div class="fl-taggroup">${x.group}</div><div class="fl-chips">`;
          lastGroup = x.group;
        }
        html += chip(x, false);
      }
      if (lastGroup !== null) html += `</div>`;
      listEl.innerHTML = html || `<div class="fl-taggroup">Nothing matched</div>`;
      listEl.querySelectorAll("[data-tag]").forEach((b) =>
        b.addEventListener("click", () => toggle(b.dataset.tag, b))
      );
    }

    function chip(x, isSugg) {
      const on = chosen.has(x.id) ? " sel" : "";
      return `<button class="fl-chip${on}" data-tag="${x.id}">${isSugg ? "✨ " : ""}${x.label}</button>`;
    }

    function toggle(id, el) {
      if (chosen.has(id)) chosen.delete(id);
      else chosen.add(id);
      if (el) el.classList.toggle("sel");
      card.querySelectorAll(`[data-tag="${id}"]`).forEach((b) => b.classList.toggle("sel", chosen.has(id)));
      countEl.textContent = chosen.size;
    }

    const finish = (keep) => {
      if (keep && chosen.size) {
        const f = grabFrame();
        let kf = null;
        if (f) {
          const id = `tag_${String(S.tags.length).padStart(3, "0")}`;
          S.frames[id] = f;
          kf = `frames/${id}.jpg`;
        }
        S.tags.push({
          t: +t.toFixed(2),
          pct: S.video.duration_sec ? +((t / S.video.duration_sec) * 100).toFixed(2) : null,
          scene: S._open.scene ? S._open.scene.i : S.scenes.length - 1,
          shot: S._open.shot ? S._open.shot.i : S.shots.length - 1,
          tags: [...chosen],
          labels: [...chosen].map((id) => FL.Tags.label(id)),
          suggested_by_machine: suggested.filter((s) => chosen.has(s)),
          composition: m && !m.error ? m : null,
          keyframe: kf,
        });
        toast(`🏷  ${chosen.size} tags saved — ${fmt(t)}`);
        saveSoon();
        render();
      }
      closeCard(keep ? wasPlaying : wasPlaying);
    };

    $("#fl-tagsave", card).addEventListener("click", () => finish(true));
    search.addEventListener("input", () => paint(search.value));
    search.addEventListener("keydown", (e) => {
      if (e.key === "Escape") { e.preventDefault(); finish(false); }
      if (e.key === "Enter") {
        e.preventDefault();
        const hits = FL.Tags.search(search.value);
        if (hits.length) {
          toggle(hits[0].id);
          search.value = "";
          paint("");
        } else finish(true);
      }
    });
    paint("");
    search.focus();
  }

  // ============================================================== roles ====
  function activeRole() {
    return FL.Roles.BY_ID[S.settings.role] || FL.Roles.FREE;
  }

  /** everything the machine already knows, handed to a role card for prefill */
  function roleCtx() {
    const shots = S.shots.filter((s) => s.dur > 0);
    const filmAsl = shots.length ? shots.reduce((a, s) => a + s.dur, 0) / shots.length : null;
    return {
      metrics: S.settings.composition ? analyzeNow(true) : lastAnalysis,
      lastShot: S.shots[S.shots.length - 1] || null,
      scene: S._open.scene,
      t: video ? video.currentTime : 0,
      filmAsl,
      S,
    };
  }

  function setRole(id) {
    S.settings.role = FL.Roles.BY_ID[id] ? id : "free";
    const r = activeRole();
    render();
    saveSoon();
    toast(`${r.icon}  ${r.name}${r.blurb ? " — " + r.blurb : ""}`, 2400);
  }

  function cycleRole(dir = 1) {
    const rot = FL.Roles.rotation(S.settings.rolesEnabled);
    let i = rot.indexOf(S.settings.role);
    if (i < 0) i = 0;
    setRole(rot[(i + dir + rot.length) % rot.length]);
  }

  function showRolePicker() {
    const wasPlaying = video && !video.paused;
    if (video) video.pause();
    closeCard(false);

    const enabled = new Set(S.settings.rolesEnabled || []);
    card = document.createElement("div");
    card.id = "filmlens-card";
    card.innerHTML = `
      <h3>Which lens are you watching with?</h3>
      <div class="fl-sub">Only one lens runs at a time — ⌥Q switches between them.
        Here you only choose which lenses stay in the rotation for this film.</div>
      <div class="fl-rolelist" id="fl-rolelist">
        ${FL.Roles.ROLES.map(
          (r) => `
          <div class="fl-rolerow">
            <label class="fl-rolecheck">
              <input type="checkbox" data-en="${r.id}" ${enabled.has(r.id) ? "checked" : ""}>
              <span class="fl-roleic">${r.icon}</span>
              <span>
                <b>${r.name}</b>
                <small>${r.blurb}${r.pausePreferred ? " · better watched paused" : ""}</small>
              </span>
            </label>
            <button class="fl-btn ghost fl-roleuse" data-use="${r.id}">Use now</button>
          </div>`
        ).join("")}
      </div>
      <div class="fl-card-actions">
        <span class="fl-hint">Esc = band</span>
        <button class="fl-btn ghost" id="fl-rolefree">Free watching</button>
        <button class="fl-btn primary" id="fl-roledone">Done</button>
      </div>`;
    document.body.appendChild(card);

    const finish = () => {
      S.settings.rolesEnabled = [...card.querySelectorAll("[data-en]")]
        .filter((c) => c.checked)
        .map((c) => c.dataset.en);
      if (!FL.Roles.rotation(S.settings.rolesEnabled).includes(S.settings.role)) {
        S.settings.role = "free";
      }
      saveSoon();
      render();
      closeCard(wasPlaying);
    };

    card.querySelectorAll("[data-use]").forEach((b) =>
      b.addEventListener("click", () => {
        S.settings.rolesEnabled = [...card.querySelectorAll("[data-en]")]
          .filter((c) => c.checked)
          .map((c) => c.dataset.en);
        if (!S.settings.rolesEnabled.includes(b.dataset.use)) {
          S.settings.rolesEnabled.push(b.dataset.use);
        }
        closeCard(wasPlaying);
        setRole(b.dataset.use);
      })
    );
    $("#fl-roledone", card).addEventListener("click", finish);
    $("#fl-rolefree", card).addEventListener("click", () => {
      closeCard(wasPlaying);
      setRole("free");
    });
    card.addEventListener("keydown", (e) => {
      if (e.key === "Escape") { e.preventDefault(); finish(); }
    });
    card.tabIndex = -1;
    card.focus();
  }

  function logRoleMark(slot, extra = {}) {
    const t = video ? video.currentTime : 0;
    const role = activeRole();
    const ctx = roleCtx();
    const m = {
      i: S.role_marks.length,
      t: +t.toFixed(2),
      pct: S.video.duration_sec ? +((t / S.video.duration_sec) * 100).toFixed(2) : null,
      role: role.id,
      role_name: role.name,
      slot: slot.id,
      label: slot.label,
      scene: S._open.scene ? S._open.scene.i : S.scenes.length - 1,
      shot: S._open.shot ? S._open.shot.i : S.shots.length - 1,
      answers: extra.answers || null,
      note: extra.note || null,
      linked_to: extra.linked === undefined ? null : extra.linked,
      keyframe: null,
      machine: {
        camera: ctx.lastShot ? ctx.lastShot.camera || null : null,
        shot_dur: ctx.lastShot ? ctx.lastShot.dur : null,
        film_asl: ctx.filmAsl ? +ctx.filmAsl.toFixed(2) : null,
      },
    };

    if (slot.keyframe) {
      const f = grabFrame();
      if (f) {
        const id = `role_${String(m.i).padStart(3, "0")}`;
        S.frames[id] = f;
        m.keyframe = `frames/${id}.jpg`;
      }
      if (ctx.metrics && !ctx.metrics.error) m.composition = ctx.metrics;
    }

    S.role_marks.push(m);
    saveSoon();
    render();
    return m;
  }

  function showRoleCard(slot) {
    if (!video) return;
    const wasPlaying = !video.paused;
    video.pause();
    closeCard(false);

    const role = activeRole();
    const ctx = roleCtx();
    const { prefill, evidence } = FL.Roles.resolve(slot, ctx);
    const chosen = {};
    for (const [k, v] of Object.entries(prefill)) chosen[k] = v;

    // the payoff card offers the setups logged earlier in this session
    let linkOptions = [];
    if (slot.linkTo) {
      linkOptions = S.role_marks
        .filter((x) => x.slot === slot.linkTo)
        .slice(-8)
        .map((x) => ({ i: x.i, label: `${fmt(x.t)}${x.note ? " — " + x.note.slice(0, 24) : ""}` }));
    }
    let linked = null;

    const kf = slot.keyframe ? grabFrame(0.7, 420) : null;

    card = document.createElement("div");
    card.id = "filmlens-card";
    card.innerHTML = `
      ${kf ? `<img class="fl-keyframe" src="${kf}" alt="">` : ""}
      <h3>${role.icon} ${slot.label}</h3>
      <div class="fl-sub">${fmt(ctx.t)} · ${role.name}${
        Object.keys(prefill).length ? " · ✨ pre-filled from measurement — confirm or correct" : ""
      }</div>
      ${evidence ? `<div class="fl-evidence">${evidence}</div>` : ""}
      ${(slot.rows || [])
        .map(
          (row) => `
        <div class="fl-label">${row.label}</div>
        <div class="fl-chips" data-row="${row.id}">
          ${row.chips
            .map(
              (c) =>
                `<button class="fl-chip${chosen[row.id] === c ? " sel" : ""}" data-chip="${c}">${c}</button>`
            )
            .join("")}
        </div>`
        )
        .join("")}
      ${
        linkOptions.length
          ? `<div class="fl-label">Which setup does this pay off?</div>
             <div class="fl-chips" id="fl-link">
               ${linkOptions.map((o) => `<button class="fl-chip" data-link="${o.i}">${o.label}</button>`).join("")}
             </div>`
          : slot.linkTo
          ? `<div class="fl-evidence">No setup marked yet — press ⌥3 on a setup first.</div>`
          : ""
      }
      ${slot.note ? `<div class="fl-label">${slot.note}</div><textarea id="fl-rolenote" placeholder="You can dictate this too…"></textarea>` : ""}
      <div class="fl-card-actions">
        <span class="fl-hint">Enter = save · Esc = skip</span>
        <button class="fl-btn ghost" id="fl-roleskip">Skip</button>
        <button class="fl-btn primary" id="fl-rolesave">Save</button>
      </div>`;
    document.body.appendChild(card);

    card.querySelectorAll("[data-row]").forEach((group) => {
      const rowId = group.dataset.row;
      group.querySelectorAll("[data-chip]").forEach((b) =>
        b.addEventListener("click", () => {
          const same = chosen[rowId] === b.dataset.chip;
          group.querySelectorAll("[data-chip]").forEach((x) => x.classList.remove("sel"));
          if (same) {
            delete chosen[rowId];
          } else {
            chosen[rowId] = b.dataset.chip;
            b.classList.add("sel");
          }
        })
      );
    });

    const linkEl = $("#fl-link", card);
    if (linkEl) {
      linkEl.querySelectorAll("[data-link]").forEach((b) =>
        b.addEventListener("click", () => {
          linkEl.querySelectorAll("[data-link]").forEach((x) => x.classList.remove("sel"));
          b.classList.add("sel");
          linked = +b.dataset.link;
        })
      );
    }

    const save = () => {
      const noteEl = $("#fl-rolenote", card);
      logRoleMark(slot, {
        answers: Object.keys(chosen).length ? chosen : null,
        note: noteEl ? noteEl.value.trim() || null : null,
        linked,
      });
      const summary = Object.values(chosen).join(" · ") || slot.short;
      toast(`${role.icon}  ${summary} @ ${fmt(ctx.t)}`);
      closeCard(wasPlaying);
    };

    $("#fl-rolesave", card).addEventListener("click", save);
    $("#fl-roleskip", card).addEventListener("click", () => closeCard(wasPlaying));

    const noteEl = $("#fl-rolenote", card);
    const onKey = (e) => {
      if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); save(); }
      if (e.key === "Escape") { e.preventDefault(); closeCard(wasPlaying); }
    };
    if (noteEl) {
      noteEl.addEventListener("keydown", onKey);
      noteEl.focus();
    } else {
      card.tabIndex = -1;
      card.addEventListener("keydown", onKey);
      card.focus();
    }
  }

  function fireRoleSlot(n) {
    if (!S) return;
    if (S.settings.role === "free") {
      toast("Pick a lens first with ⌥Q (DOP, Editor, Director…)", 2600);
      return;
    }
    const slot = FL.Roles.slotOf(S.settings.role, n);
    if (!slot) {
      toast(`⌥${n} is empty in this lens`);
      return;
    }
    if (slot.type === "mark") {
      logRoleMark(slot);
      toast(`${activeRole().icon}  ${slot.label} @ ${fmt(video ? video.currentTime : 0)}`);
    } else {
      showRoleCard(slot);
    }
  }

  /** the readout changes with the lens — same data, different slice */
  function roleReadout() {
    const role = activeRole();
    const out = [];
    const shots = S.shots.filter((s) => s.dur > 0);
    const asl = shots.length ? shots.reduce((a, s) => a + s.dur, 0) / shots.length : null;
    const lastShot = S.shots[S.shots.length - 1];
    const sc = S._open.scene;
    const t = video ? video.currentTime : 0;
    const pct = S.video.duration_sec ? (t / S.video.duration_sec) * 100 : null;
    const m = displayAnalysis || lastAnalysis;

    const act = (p) => {
      if (p === null) return null;
      if (p < 12) return "Setup";
      if (p < 27) return "Act 1 → turn";
      if (p < 48) return "Act 2a";
      if (p < 56) return "Around the midpoint";
      if (p < 75) return "Act 2b";
      if (p < 90) return "Act 3 / climax";
      return "Resolution";
    };

    if (role.id === "dop") {
      if (m && !m.error) {
        out.push(m.hints[0]);
        if (m.tilt_deg !== null) out.push(`Tilt ${m.tilt_deg}° · symmetry ${m.symmetry}%`);
      }
      if (lastShot && lastShot.camera) out.push(`Last shot: ${lastShot.camera_detail || lastShot.camera}`);
    } else if (role.id === "editor") {
      if (lastShot && lastShot.dur) out.push(`Last shot ${lastShot.dur}s`);
      if (asl) out.push(`Film average ${asl.toFixed(1)}s`);
      if (sc) out.push(`This scene ${Math.round(t - sc.start)}s · ${sc.shot_count} shots`);
    } else if (role.id === "story" || role.id === "director") {
      if (pct !== null) out.push(`${pct.toFixed(0)}% through the film — ${act(pct)}`);
      out.push(`${S.scenes.length} scenes · ${S.shots.length} shots`);
      if (role.id === "director" && lastShot && lastShot.camera) {
        out.push(`Camera: ${lastShot.camera_detail || lastShot.camera}`);
      }
    } else if (role.id === "screenplay") {
      if (sc) out.push(`Scene ${sc.i + 1} running — ${Math.round(t - sc.start)}s, ${sc.shot_count} shots`);
      if (sc && sc.user && sc.user.charge_in) out.push(`Opening charge: ${sc.user.charge_in}`);
      if (pct !== null) out.push(`${pct.toFixed(0)}% · ${act(pct)}`);
    } else if (role.id === "dialogue") {
      const last = S.transcript[S.transcript.length - 1];
      if (last) out.push(`"${last.text.slice(0, 60)}"`);
      else out.push("Turn captions on, or import the transcript");
    }
    return out.filter(Boolean);
  }

  // -------------------------------------------------------- shots & scenes -
  function openShot(t, transition) {
    S._open.shot = {
      i: S.shots.length,
      start: +t.toFixed(2),
      end: null,
      dur: null,
      scene: S.scenes.length,
      transition_in: transition || "cut",
      color: null,
      brightness: null,
      saturation: null,
      _samples: 0,
      _r: 0, _g: 0, _b: 0, _bright: 0, _sat: 0,
    };
  }

  function accumulateShot(res) {
    const sh = S._open.shot;
    if (!sh) return;
    sh._samples++;
    sh._r += res.color.r;
    sh._g += res.color.g;
    sh._b += res.color.b;
    sh._bright += res.brightness;
    sh._sat += res.saturation;
  }

  function closeShot(t) {
    const sh = S._open.shot;
    if (!sh) return null;
    sh.end = +t.toFixed(2);
    sh.dur = +Math.max(0, sh.end - sh.start).toFixed(2);
    const n = Math.max(1, sh._samples);
    sh.color = hex({
      r: Math.round(sh._r / n),
      g: Math.round(sh._g / n),
      b: Math.round(sh._b / n),
    });
    sh.brightness = +(sh._bright / n).toFixed(3);
    sh.saturation = +(sh._sat / n).toFixed(3);
    sh._rgb = { r: Math.round(sh._r / n), g: Math.round(sh._g / n), b: Math.round(sh._b / n) };
    delete sh._r; delete sh._g; delete sh._b;
    delete sh._bright; delete sh._sat; delete sh._samples;
    if (motion && sh.dur > 0.4) {
      const cam = motion.summary();
      sh.camera = cam.move;
      sh.camera_detail = cam.detail || null;
      sh.camera_energy = cam.energy ?? null;
    }
    if (motion) motion.reset();
    S.shots.push(sh);
    S._open.shot = null;
    return sh;
  }

  function openScene(t) {
    S._open.scene = {
      i: S.scenes.length,
      start: +t.toFixed(2),
      end: null,
      dur: null,
      shot_count: 0,
      asl: null,
      transition_in: "cut",
      dominant_color: null,
      brightness_avg: null,
      keyframe: null,
      split_reason: null,
      user: { charge_in: S._open.lastCharge || null, charge_out: null, essential: null, note: null },
      _rgb: { r: 0, g: 0, b: 0 },
      _bright: 0,
      _n: 0,
      _kf: null,
    };
  }

  function closeScene(t) {
    const sc = S._open.scene;
    if (!sc) return null;
    sc.end = +t.toFixed(2);
    sc.dur = +Math.max(0, sc.end - sc.start).toFixed(2);
    const n = Math.max(1, sc._n);
    sc.dominant_color = hex({
      r: Math.round(sc._rgb.r / n),
      g: Math.round(sc._rgb.g / n),
      b: Math.round(sc._rgb.b / n),
    });
    sc.brightness_avg = +(sc._bright / n).toFixed(3);
    sc.asl = sc.shot_count ? +(sc.dur / sc.shot_count).toFixed(2) : null;
    if (S.settings.autoKeyframes && sc._kf) {
      const id = `scene_${String(sc.i).padStart(3, "0")}`;
      S.frames[id] = sc._kf;
      sc.keyframe = `frames/${id}.jpg`;
    }
    delete sc._rgb; delete sc._bright; delete sc._n; delete sc._kf;
    S.scenes.push(sc);
    S._open.scene = null;
    return sc;
  }

  function sceneMeanColor() {
    const sc = S._open.scene;
    if (!sc || !sc._n) return null;
    return {
      r: Math.round(sc._rgb.r / sc._n),
      g: Math.round(sc._rgb.g / sc._n),
      b: Math.round(sc._rgb.b / sc._n),
    };
  }

  function sceneMeanBright() {
    const sc = S._open.scene;
    if (!sc || !sc._n) return null;
    return sc._bright / sc._n;
  }

  /** Was there a stretch of silence around this cut? Strong scene-change hint. */
  function captionGapAt(t) {
    const tr = S.transcript;
    if (!tr || tr.length < 4) return 0;
    let before = null, after = null;
    for (const line of tr) {
      if (line.t <= t) before = line.t;
      else { after = line.t; break; }
    }
    if (before === null || after === null) return 0;
    return after - before;
  }

  /** Close the current scene at `at` and start a new one there. */
  function splitScene(at, reason) {
    const finished = closeScene(at);
    if (finished) finished.split_reason = reason;
    openScene(at);
    if (S._open.shot) S._open.shot.scene = S.scenes.length;
    if (S.settings.dissect && finished) showDissectCard(finished);
    return finished;
  }

  /**
   * Weak signals, added together. No single one is trusted on its own:
   *   colour shift · brightness shift · an establishing shot after fast
   *   cutting · a gap in the dialogue · a scene that has already run long.
   */
  function sceneScore(o) {
    let score = colorDist(o.sceneMean, o.shotMean) / 0.11;
    if (o.sceneBright !== null && o.sceneBright !== undefined) {
      score += Math.min(1.5, Math.abs(o.sceneBright - o.shotBright) / 0.1) * 0.8;
    }
    if (o.elapsed >= 2.0 && o.sceneAsl && o.sceneAsl < 2.2) score += 0.5;
    if (o.captionGap >= 2.0) score += 0.5;
    if (o.sceneDur > o.minScene * 4) score += 0.35;
    return score;
  }

  function sceneThreshold(sens) {
    return 1.6 - 1.1 * (sens ?? 0.5);
  }

  FL.sceneScore = sceneScore;
  FL.sceneThreshold = sceneThreshold;
  FL.colorDist = colorDist;

  /**
   * A scene boundary can't be judged from the single frame at the cut — two
   * different scenes often share one palette. So after every cut we wait for
   * the new shot to settle (~2s) and then score several weak signals together:
   * colour shift, brightness shift, an establishing shot after fast cutting,
   * a gap in the dialogue, and how long the current scene has already run.
   */
  function resolvePending(t, force) {
    const p = S._pending;
    if (!p) return;
    const shot = S._open.shot;
    const elapsed = shot ? t - shot.start : 0;
    if (!force && elapsed < 2.0) return;

    S._pending = null;
    const sc = S._open.scene;
    if (!shot || !sc || !p.sceneMean || !shot._samples) return;

    const sceneDur = p.cutTime - sc.start;
    if (sceneDur < S.settings.minScene) return;

    const n = Math.max(1, shot._samples);
    const score = sceneScore({
      sceneMean: p.sceneMean,
      sceneBright: p.sceneBright,
      sceneAsl: p.sceneAsl,
      shotMean: { r: shot._r / n, g: shot._g / n, b: shot._b / n },
      shotBright: shot._bright / n,
      elapsed,
      captionGap: captionGapAt(p.cutTime),
      sceneDur,
      minScene: S.settings.minScene,
    });

    if (score >= sceneThreshold(S.settings.sceneSensitivity)) {
      splitScene(p.cutTime, "auto");
      render();
    }
  }

  function handleCut(t, res) {
    resolvePending(t, true); // settle the previous cut's decision first

    const closed = closeShot(t);
    const sc = S._open.scene;

    if (sc && closed) {
      sc.shot_count++;
      sc._rgb.r += closed._rgb.r;
      sc._rgb.g += closed._rgb.g;
      sc._rgb.b += closed._rgb.b;
      sc._bright += closed.brightness;
      sc._n++;
    }

    openShot(t, res.transition);

    const sceneDur = sc ? t - sc.start : 0;
    if (res.transition === "fade" && sc && sceneDur > 6) {
      splitScene(t, "fade");
    } else if (sc) {
      S._pending = {
        cutTime: t,
        sceneMean: sceneMeanColor(),
        sceneBright: sceneMeanBright(),
        sceneAsl: sc.shot_count ? sceneDur / sc.shot_count : null,
      };
    }

    render();
    saveSoon();
  }

  /** You saw the scene change — tell it so. Always beats the heuristic. */
  function manualSceneBreak() {
    if (!S || !video) return;
    const t = video.currentTime;
    S._pending = null;
    if (!S._open.scene) { openScene(t); return; }

    const closed = closeShot(t);
    const sc = S._open.scene;
    if (sc && closed) {
      sc.shot_count++;
      sc._rgb.r += closed._rgb.r;
      sc._rgb.g += closed._rgb.g;
      sc._rgb.b += closed._rgb.b;
      sc._bright += closed.brightness;
      sc._n++;
    }
    openShot(t, "manual");
    splitScene(t, "manual");
    toast(`✂  New scene ${S.scenes.length + 1} — ${fmt(t)}`);
    render();
    saveSoon();
  }

  // ---------------------------------------------------------- sample loop --
  function onSample(t) {
    if (!S || !S.recording || !video) return;
    if (video.paused || video.seeking) return;
    if (lastSampled >= 0 && t - lastSampled < 0.075 && t > lastSampled) return;

    const prev = lastSampled;
    lastSampled = t;

    const res = detector.sample(video, t);
    if (!res) return;

    if (res.error) {
      if (!warnedDrm) {
        warnedDrm = true;
        S.flags.drm_suspected = true;
        showWarn(
          res.error === "tainted"
            ? "This video is DRM-protected (rented or purchased). Its frames cannot be read — try a normal YouTube upload."
            : "Frame capture is failing. Try reloading the page."
        );
        render();
      }
      return;
    }

    if (res.drmSuspect && !warnedDrm) {
      warnedDrm = true;
      S.flags.drm_suspected = true;
      showWarn("Every frame is coming back black — this looks like DRM-protected content, so the data would be empty too.");
      render();
    }

    if (prev >= 0 && t > prev && t - prev < 1.5) S.sampled_seconds += t - prev;

    if (!S._open.scene) openScene(t);
    if (!S._open.shot) {
      openShot(t, "start");
      accumulateShot(res);
      return;
    }

    accumulateShot(res);

    // camera movement: cheap optical flow, ~6 times a second
    if (motion && t - (motion._lastFeed || 0) > 0.16) {
      motion._lastFeed = t;
      motion.feed(video, t);
    }

    // one representative frame from INSIDE the scene, not at its edge
    const sc = S._open.scene;
    if (sc && !sc._kf && S.settings.autoKeyframes && t - sc.start > 2) {
      sc._kf = grabFrame();
      if (S.settings.composition) {
        const m = analyzeNow(true);
        if (m && !m.error) sc.composition = m;
      }
    }

    if (res.cut && t - S._open.shot.start >= S.settings.minShot) {
      handleCut(t, res);
    } else {
      resolvePending(t, false);
      if (S.shots.length && S.shots.length % 25 === 0) render();
    }
  }

  function attachLoop() {
    if (!video) return;
    if (rafHandle && video.cancelVideoFrameCallback) {
      try { video.cancelVideoFrameCallback(rafHandle); } catch (e) {}
      rafHandle = null;
    }
    if (pollHandle) { clearInterval(pollHandle); pollHandle = null; }

    if (typeof video.requestVideoFrameCallback === "function") {
      const step = (now, meta) => {
        // every presented frame counts for the frame-rate estimate, before
        // any throttling — that is the whole point of measuring it
        try {
          if (S && S.recording && !video.paused) FL.Compose.Fps.note(meta.mediaTime);
        } catch (e) {}
        try { onSample(meta.mediaTime); } catch (e) { /* never kill the loop */ }
        if (video) rafHandle = video.requestVideoFrameCallback(step);
      };
      rafHandle = video.requestVideoFrameCallback(step);
    } else {
      pollHandle = setInterval(() => {
        try { if (video) onSample(video.currentTime); } catch (e) {}
      }, 80);
    }
  }

  // ------------------------------------------------------------- markers ---
  const MARKER_TYPES = {
    hooked: { label: "Hooked", emoji: "🔥", engagement: 1 },
    drifted: { label: "Drifted", emoji: "😐", engagement: -1 },
    turn: { label: "Turning point", emoji: "⚡", engagement: 0 },
    character: { label: "Character beat", emoji: "🎭", engagement: 0 },
    shot: { label: "Shot to keep", emoji: "🎞", engagement: 0 },
    note: { label: "Note", emoji: "✍️", engagement: 0 },
  };

  function addMarker(type, note) {
    if (!S || !video) return;
    const t = video.currentTime;
    const meta = MARKER_TYPES[type] || { label: type, emoji: "•", engagement: 0 };
    const m = {
      i: S.markers.length,
      t: +t.toFixed(2),
      pct: S.video.duration_sec ? +((t / S.video.duration_sec) * 100).toFixed(2) : null,
      type,
      label: meta.label,
      note: note || null,
      shot: S._open.shot ? S._open.shot.i : S.shots.length - 1,
      scene: S._open.scene ? S._open.scene.i : S.scenes.length - 1,
      keyframe: null,
    };

    if (type === "shot" || type === "turn") {
      const f = grabFrame();
      if (f) {
        const id = `mark_${String(m.i).padStart(3, "0")}`;
        S.frames[id] = f;
        m.keyframe = `frames/${id}.jpg`;
      }
      if (S.settings.composition) {
        const comp = analyzeNow(true);
        if (comp && !comp.error) {
          m.composition = comp;
          m.suggested_tags = comp.suggested;
        }
      }
      if (motion) m.camera = motion.summary().move;
    }

    S.markers.push(m);
    if (meta.engagement !== 0) {
      S.engagement.push({ t: m.t, pct: m.pct, value: meta.engagement });
    }
    toast(`${meta.emoji}  ${meta.label} @ ${fmt(t)}`);
    render();
    saveSoon();
  }

  // ---------------------------------------------------------- dissect card -
  function closeCard(resume) {
    if (card) { card.remove(); card = null; }
    if (resume && video && video.paused) video.play().catch(() => {});
  }

  function showDissectCard(scene) {
    if (!video) return;
    video.pause();
    closeCard(false);

    card = document.createElement("div");
    card.id = "filmlens-card";
    const kf = scene.keyframe ? S.frames[scene.keyframe.replace("frames/", "").replace(".jpg", "")] : null;

    card.innerHTML = `
      ${kf ? `<img class="fl-keyframe" src="${kf}" alt="">` : ""}
      <h3>Scene ${scene.i + 1} ended — ${fmt(scene.start)} → ${fmt(scene.end)}</h3>
      <div class="fl-sub">${scene.dur.toFixed(0)}s · ${scene.shot_count} shots · ASL ${scene.asl ?? "—"}s${
        scene.user.charge_in ? ` · opened on: ${scene.user.charge_in}` : ""
      }</div>

      <div class="fl-label">What is the charge at the end of the scene?</div>
      <div class="fl-chips" id="fl-charges">
        ${CHARGES.map((c) => `<button class="fl-chip" data-charge="${c}">${c}</button>`).join("")}
      </div>

      <div class="fl-label">Does anything break without this scene?</div>
      <div class="fl-chips" id="fl-essential">
        <button class="fl-chip" data-ess="yes">Yes, essential</button>
        <button class="fl-chip" data-ess="no">No, could be cut</button>
        <button class="fl-chip" data-ess="maybe">Not sure</button>
      </div>

      <div class="fl-label">One line — who wanted what, and what changed</div>
      <textarea id="fl-note" placeholder="Bol ke likh sakte ho (dictation)…"></textarea>

      <div class="fl-card-actions">
        <span class="fl-hint">Enter = save &amp; resume · Esc = skip</span>
        <button class="fl-btn ghost" id="fl-skip">Skip</button>
        <button class="fl-btn primary" id="fl-save">Save &amp; resume</button>
      </div>`;

    document.body.appendChild(card);

    let charge = null;
    let ess = null;

    card.querySelectorAll("[data-charge]").forEach((b) =>
      b.addEventListener("click", () => {
        card.querySelectorAll("[data-charge]").forEach((x) => x.classList.remove("sel"));
        b.classList.add("sel");
        charge = b.dataset.charge;
      })
    );
    card.querySelectorAll("[data-ess]").forEach((b) =>
      b.addEventListener("click", () => {
        card.querySelectorAll("[data-ess]").forEach((x) => x.classList.remove("sel"));
        b.classList.add("sel");
        ess = b.dataset.ess;
      })
    );

    const save = () => {
      scene.user.charge_out = charge;
      scene.user.essential = ess;
      scene.user.note = ($("#fl-note", card) || {}).value?.trim() || null;
      S._open.lastCharge = charge;
      if (S._open.scene && !S._open.scene.user.charge_in) S._open.scene.user.charge_in = charge;
      saveSoon();
      closeCard(true);
      render();
    };

    $("#fl-save", card).addEventListener("click", save);
    $("#fl-skip", card).addEventListener("click", () => closeCard(true));
    const ta = $("#fl-note", card);
    ta.focus();
    ta.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); save(); }
      if (e.key === "Escape") { e.preventDefault(); closeCard(true); }
    });
  }

  function showNoteCard() {
    if (!video) return;
    const wasPlaying = !video.paused;
    video.pause();
    closeCard(false);
    const t = video.currentTime;

    card = document.createElement("div");
    card.id = "filmlens-card";
    card.innerHTML = `
      <h3>Note @ ${fmt(t)}</h3>
      <div class="fl-sub">Write whatever came to mind. The film is paused.</div>
      <textarea id="fl-note" placeholder="Write here…"></textarea>
      <div class="fl-card-actions">
        <span class="fl-hint">Enter = save · Esc = cancel</span>
        <button class="fl-btn ghost" id="fl-skip">Cancel</button>
        <button class="fl-btn primary" id="fl-save">Save</button>
      </div>`;
    document.body.appendChild(card);

    const finish = (keep) => {
      if (keep) {
        const txt = ($("#fl-note", card) || {}).value?.trim();
        if (txt) {
          S.notes.push({ t: +t.toFixed(2), text: txt });
          addMarker("note", txt);
        }
      }
      closeCard(wasPlaying);
    };

    $("#fl-save", card).addEventListener("click", () => finish(true));
    $("#fl-skip", card).addEventListener("click", () => finish(false));
    const ta = $("#fl-note", card);
    ta.focus();
    ta.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); finish(true); }
      if (e.key === "Escape") { e.preventDefault(); finish(false); }
    });
  }

  // ---------------------------------------------------------- transcript ---
  let lastCaption = "";
  function pollCaptions() {
    if (!S || !S.settings.captureCaptions || !S.recording || !video) return;
    const box = $(".ytp-caption-window-container");
    if (!box) return;
    const txt = box.innerText.replace(/\s+/g, " ").trim();
    if (txt && txt !== lastCaption) {
      lastCaption = txt;
      S.transcript.push({ t: +video.currentTime.toFixed(2), text: txt, src: "live" });
    }
  }

  function importTranscriptPanel() {
    const segs = document.querySelectorAll("ytd-transcript-segment-renderer");
    if (!segs.length) {
      toast("Open YouTube's transcript panel first (⋯ → Show transcript)", 3200);
      return;
    }
    const out = [];
    segs.forEach((seg) => {
      const ts = seg.querySelector(".segment-timestamp");
      const tx = seg.querySelector(".segment-text");
      if (!ts || !tx) return;
      const parts = ts.textContent.trim().split(":").map(Number);
      let sec = 0;
      if (parts.length === 3) sec = parts[0] * 3600 + parts[1] * 60 + parts[2];
      else if (parts.length === 2) sec = parts[0] * 60 + parts[1];
      out.push({ t: sec, text: tx.textContent.trim(), src: "panel" });
    });
    if (out.length) {
      S.transcript = out;
      toast(`Transcript imported — ${out.length} lines`);
      saveSoon();
      render();
    }
  }

  // ------------------------------------------------------------ analysis ---
  function computeAnalysis() {
    const shots = S.shots.filter((s) => s.dur > 0);
    const durs = shots.map((s) => s.dur).sort((a, b) => a - b);
    const sum = durs.reduce((a, b) => a + b, 0);
    const median = durs.length
      ? durs.length % 2
        ? durs[(durs.length - 1) / 2]
        : (durs[durs.length / 2 - 1] + durs[durs.length / 2]) / 2
      : null;

    const bucket = 120; // 2-minute buckets
    const dur = S.video.duration_sec || (shots.length ? shots[shots.length - 1].end : 0);
    const buckets = [];
    for (let start = 0; start < dur; start += bucket) {
      const end = Math.min(start + bucket, dur);
      const inB = shots.filter((s) => s.start >= start && s.start < end);
      buckets.push({
        start: +start.toFixed(0),
        end: +end.toFixed(0),
        shots: inB.length,
        asl: inB.length ? +(inB.reduce((a, s) => a + s.dur, 0) / inB.length).toFixed(2) : null,
        cuts_per_min: +((inB.length / ((end - start) / 60)) || 0).toFixed(2),
      });
    }

    const rated = buckets.filter((b) => b.asl !== null);
    const fastest = [...rated].sort((a, b) => a.asl - b.asl).slice(0, 5)
      .map((b) => ({ from: fmt(b.start), to: fmt(b.end), asl: b.asl }));
    const slowest = [...rated].sort((a, b) => b.asl - a.asl).slice(0, 5)
      .map((b) => ({ from: fmt(b.start), to: fmt(b.end), asl: b.asl }));

    const buckets5 = [0.5, 1, 2, 4, 8, 15, 30];
    const dist = {};
    let prev = 0;
    for (const b of buckets5) {
      dist[`${prev}-${b}s`] = durs.filter((d) => d > prev && d <= b).length;
      prev = b;
    }
    dist[`>${prev}s`] = durs.filter((d) => d > prev).length;

    return {
      shot_count: shots.length,
      scene_count: S.scenes.length,
      total_measured_sec: +sum.toFixed(1),
      sampled_seconds: +S.sampled_seconds.toFixed(1),
      coverage_pct: dur ? +((S.sampled_seconds / dur) * 100).toFixed(1) : null,
      asl: shots.length ? +(sum / shots.length).toFixed(2) : null,
      median_shot: median !== null ? +median.toFixed(2) : null,
      shortest_shot: durs.length ? durs[0] : null,
      longest_shot: durs.length ? durs[durs.length - 1] : null,
      cuts_per_min: dur ? +((shots.length / (dur / 60)) || 0).toFixed(2) : null,
      shot_length_distribution: dist,
      pacing_buckets: buckets,
      fastest_stretches: fastest,
      slowest_stretches: slowest,
      marker_summary: Object.keys(MARKER_TYPES).reduce((acc, k) => {
        acc[k] = S.markers.filter((m) => m.type === k).length;
        return acc;
      }, {}),
    };
  }

  /** how often each technique showed up, and how the camera behaved */
  function compositionSummary() {
    const tagCount = {};
    for (const entry of S.tags) {
      for (const id of entry.tags) {
        tagCount[id] = (tagCount[id] || 0) + 1;
      }
    }
    const machineCount = {};
    const measured = [
      ...S.scenes.filter((s) => s.composition).map((s) => s.composition),
      ...S.markers.filter((m) => m.composition).map((m) => m.composition),
    ];
    for (const m of measured) {
      for (const id of m.suggested || []) machineCount[id] = (machineCount[id] || 0) + 1;
    }

    const camera = {};
    for (const sh of S.shots) {
      if (sh.camera) camera[sh.camera] = (camera[sh.camera] || 0) + 1;
    }

    // which lens did the watching, and what did each one notice
    const byRole = {};
    for (const rm of S.role_marks) {
      const r = (byRole[rm.role] = byRole[rm.role] || { name: rm.role_name, total: 0, slots: {} });
      r.total++;
      r.slots[rm.slot] = (r.slots[rm.slot] || 0) + 1;
      if (rm.answers) {
        r.answers = r.answers || {};
        for (const [k, v] of Object.entries(rm.answers)) {
          r.answers[k] = r.answers[k] || {};
          r.answers[k][v] = (r.answers[k][v] || 0) + 1;
        }
      }
    }

    const avg = (f) => {
      const vals = measured.map(f).filter((v) => typeof v === "number");
      return vals.length ? +(vals.reduce((a, b) => a + b, 0) / vals.length).toFixed(3) : null;
    };

    const sortDesc = (obj) =>
      Object.entries(obj)
        .sort((a, b) => b[1] - a[1])
        .map(([id, n]) => ({ id, label: FL.Tags.label(id), count: n }));

    return {
      frames_measured: measured.length,
      your_tags: sortDesc(tagCount),
      machine_suggestions: sortDesc(machineCount),
      camera_moves: camera,
      by_role: byRole,
      averages: {
        symmetry: avg((m) => m.symmetry),
        negative_space: avg((m) => m.negative_space),
        tonal_contrast: avg((m) => m.tonal_contrast),
        distance_to_thirds: avg((m) => m.distances && m.distances.third),
        distance_to_center: avg((m) => m.distances && m.distances.center),
      },
    };
  }

  function buildPayload() {
    // close anything still open so the export is complete
    const t = video ? video.currentTime : 0;
    if (S._open.shot) closeShot(t);
    if (S._open.scene) closeScene(t);

    const payload = JSON.parse(
      JSON.stringify({
        filmlens_version: VERSION,
        exported_at: new Date().toISOString(),
        video: S.video,
        started_at: S.started_at,
        settings: S.settings,
        flags: S.flags,
        analysis: computeAnalysis(),
        frame_rate: S.frame_rate || FL.Compose.Fps.estimate(video),
        composition_summary: compositionSummary(),
        scenes: S.scenes,
        shots: S.shots,
        markers: S.markers,
        notes: S.notes,
        engagement: S.engagement,
        tags: S.tags,
        role_marks: S.role_marks,
        transcript: S.transcript,
      })
    );

    // strip internals
    payload.shots.forEach((s) => { delete s._rgb; });
    payload.scenes.forEach((s) => { delete s._meanRgb; });

    // re-open so recording can continue after an export
    openScene(t);
    openShot(t, "resume");
    return payload;
  }

  const ANALYSE_ME = `# FilmLens session — what to do with this file

This folder was produced by a Chrome extension that watched a film frame by
frame **without any AI**. Everything in \`session.json\` is measured or was
typed by the viewer.

Attach this file (or the whole zip) to Claude and ask for a breakdown report.

A prompt that works well:

> Attached is a FilmLens session from <FILM NAME>. Using session.json, build me
> a full filmmaking breakdown report:
> 1. Structure map — act breaks, inciting incident, midpoint, low point and
>    climax, inferred from the pacing buckets, scene lengths and my markers,
>    with timestamps and percentage positions.
> 2. Pacing analysis — where the film speeds up and slows down, and what that
>    tells me about how tension is built.
> 3. Scene log table — every scene with duration, shot count, ASL, dominant
>    colour, my charge in/out and my notes.
> 4. Where my own engagement markers agree and disagree with the film's craft,
>    and what the disagreements teach me.
> 5. Ten reel-ready observations I can turn into 45-90 second episodes.

> 6. Composition report — which techniques appear where, how my own tags
>    compare with what the maths suggested, how the camera moved shot to shot,
>    and what the frame rate tells me about how it was shot.

## Field guide

- \`shots[]\` — every detected shot: start, end, duration, average colour,
  brightness, saturation, which scene it belongs to.
- \`scenes[]\` — grouped shots, plus \`user\` (charge_in, charge_out, essential,
  note) filled in during dissect mode.
- \`markers[]\` — hooked / drifted / turning point / character beat / shot to
  keep / note, each with a timestamp and % position in the film.
- \`engagement[]\` — the +1 / -1 attention track from the viewer.
- \`analysis\` — pre-computed stats: ASL, median shot, cuts per minute, pacing
  buckets, fastest and slowest stretches, shot-length distribution.
- \`tags[]\` — composition techniques the viewer tagged by hand, with the frame
  and which of them the maths had also suggested.
- \`role_marks[]\` — the heart of a teaching report. Each entry says WHICH LENS
  the viewer was wearing (story writer, screenplay writer, dialogue writer,
  cinematographer, director, editor), what that lens asked, and the answer:
  shot size and why that size, framing grid, camera angle and movement, light
  direction, scene value change, conflict type, subtext, what the scene is
  doing, where it should be trimmed, and so on. \`linked_to\` ties a payoff back
  to the setup it pays off. Build the report lens by lens — one chapter per
  role is exactly how a beginner should be taught.
- \`composition_summary\` — technique frequency (viewer's tags vs machine
  suggestions), camera-move counts, and averages for symmetry, negative space,
  contrast and distance-to-thirds.
- Per-frame \`composition\` on scenes and markers: visual-weight position,
  nearest compositional anchor and its distance, symmetry score, balance,
  negative space, tonal/texture contrast, figure-ground, focus ratio, depth
  bands, dominant line inclinations, vanishing point, tilt, dominant hues.
- \`shots[].camera\` — static / pan / tilt / zoom / handheld / drift, measured by
  block-matching successive frames.
- \`frame_rate\` — measured fps, likely source fps, duplicate-frame ratio
  (telecine) and timing jitter.
- \`flags.drm_suspected\` — if true, the video was protected and the visual data
  is unreliable.

## Honest limits

Shot detection is threshold-based, so dissolves and whip pans can be missed or
over-counted, and scene grouping is a colour-and-length heuristic, not a
semantic reading. Treat the scene boundaries as a strong first draft.

The composition numbers are evidence, not verdicts. The engine knows where the
frame's visual weight sits — it does not know what the subject is. In a
close-up that usually agrees with the face; in a crowded wide it may not. The
viewer's own \`tags\` are the authority; \`suggested\` is only a prompt.
`;

  async function exportZip() {
    const payload = buildPayload();
    const base = safeName(S.video.title);
    const files = [
      { name: "session.json", data: JSON.stringify(payload, null, 2) },
      { name: "ANALYSE_ME.md", data: ANALYSE_ME.replace("<FILM NAME>", S.video.title) },
      {
        name: "shots.csv",
        data: toCsv(payload.shots, ["i", "scene", "start", "end", "dur", "transition_in", "color", "brightness", "saturation"]),
      },
      {
        name: "scenes.csv",
        data: toCsv(
          payload.scenes.map((s) => ({
            i: s.i, start: s.start, end: s.end, dur: s.dur,
            shot_count: s.shot_count, asl: s.asl,
            dominant_color: s.dominant_color, brightness_avg: s.brightness_avg,
            charge_in: s.user.charge_in, charge_out: s.user.charge_out,
            essential: s.user.essential, note: s.user.note,
          })),
          ["i", "start", "end", "dur", "shot_count", "asl", "dominant_color", "brightness_avg", "charge_in", "charge_out", "essential", "note"]
        ),
      },
      {
        name: "markers.csv",
        data: toCsv(payload.markers, ["i", "t", "pct", "type", "label", "scene", "shot", "note", "keyframe"]),
      },
    ];

    if (payload.role_marks && payload.role_marks.length) {
      files.push({
        name: "role_marks.csv",
        data: toCsv(
          payload.role_marks.map((x) => ({
            t: x.t, pct: x.pct, role: x.role_name, slot: x.label,
            answers: x.answers ? Object.entries(x.answers).map(([k, v]) => `${k}=${v}`).join(" | ") : "",
            note: x.note || "",
            linked_to: x.linked_to === null ? "" : x.linked_to,
            scene: x.scene, shot: x.shot,
            camera: x.machine ? x.machine.camera || "" : "",
            shot_dur: x.machine ? x.machine.shot_dur ?? "" : "",
            keyframe: x.keyframe || "",
          })),
          ["t", "pct", "role", "slot", "answers", "note", "linked_to", "scene", "shot", "camera", "shot_dur", "keyframe"]
        ),
      });
    }

    if (payload.tags && payload.tags.length) {
      files.push({
        name: "tags.csv",
        data: toCsv(
          payload.tags.map((x) => ({
            t: x.t, pct: x.pct, scene: x.scene, shot: x.shot,
            techniques: x.labels.join(" | "),
            machine_agreed: (x.suggested_by_machine || []).length,
            keyframe: x.keyframe,
          })),
          ["t", "pct", "scene", "shot", "techniques", "machine_agreed", "keyframe"]
        ),
      });
    }

    const compRows = [
      ...payload.scenes.filter((s) => s.composition).map((s) => ({ kind: "scene", i: s.i, t: s.start, c: s.composition })),
      ...payload.markers.filter((m) => m.composition).map((m) => ({ kind: "marker", i: m.i, t: m.t, c: m.composition })),
    ].map((r) => ({
      kind: r.kind, index: r.i, t: r.t,
      weight_x: r.c.weight.x, weight_y: r.c.weight.y,
      nearest_anchor: r.c.nearest.kind, anchor_distance: r.c.nearest.distance,
      symmetry: r.c.symmetry, negative_space: r.c.negative_space,
      tonal_contrast: r.c.tonal_contrast, figure_ground: r.c.figure_ground,
      focus_ratio: r.c.focus_ratio, tilt_deg: r.c.tilt_deg,
      lines_h: r.c.line_types.horizontal, lines_v: r.c.line_types.vertical, lines_d: r.c.line_types.diagonal,
      vanishing_point: r.c.vanishing_point ? `${r.c.vanishing_point.x}×${r.c.vanishing_point.y}` : "",
      aspect: r.c.aspect,
      suggested: (r.c.suggested || []).map((id) => FL.Tags.label(id)).join(" | "),
    }));

    if (compRows.length) {
      files.push({
        name: "composition.csv",
        data: toCsv(compRows, Object.keys(compRows[0])),
      });
    }

    if (payload.transcript.length) {
      files.push({
        name: "transcript.txt",
        data: payload.transcript.map((l) => `[${fmt(l.t)}] ${l.text}`).join("\n"),
      });
    }

    for (const [id, dataUrl] of Object.entries(S.frames)) {
      try {
        files.push({ name: `frames/${id}.jpg`, data: FL.zip.dataUrlToBytes(dataUrl) });
      } catch (e) { /* skip a bad frame rather than fail the whole export */ }
    }

    const blob = FL.zip.buildZip(files);
    download(blob, `filmlens_${base}.zip`);
    toast(`Exported — ${files.length} files`);
  }

  function exportJson() {
    const payload = buildPayload();
    download(
      new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" }),
      `filmlens_${safeName(S.video.title)}.json`
    );
    toast("JSON downloaded");
  }

  // ============================================================ help ======
  /**
   * Hover help. A one-line tooltip is too thin to teach anything and a
   * paragraph is too much to read mid-film, so every control gets exactly
   * three short lines: what it does, when to press it, why it matters.
   */
  const HELP = {
    rec: {
      title: "Start / pause recording",
      what: "The master switch. While it is on, the extension counts every cut, measures every shot, groups scenes, classifies camera movement and estimates the frame rate.",
      when: "Press it once before you start the film. Press again to pause.",
      why: "Nothing is counted until this is on — the numbers above stay at zero.",
    },
    mode: {
      title: "Silent / Dissect",
      what: "Silent never interrupts the film. Dissect pauses at every detected scene boundary and asks two questions about the scene that just ended.",
      when: "Silent on a first watch, Dissect on a second.",
      why: "The first watch should be felt, not analysed. Analysis belongs to the rewatch.",
    },
    hooked: {
      title: "Hooked",
      what: "Logs the exact moment the film had you — nothing else happens, the film keeps playing.",
      when: "Whenever you lean in, or feel something is about to happen.",
      why: "These marks become your own attention curve, which the report lays over the film's measured pacing.",
    },
    drifted: {
      title: "Drifted",
      what: "Logs the moment your attention slipped.",
      when: "When you get bored, or reach for your phone.",
      why: "Where the film slowed and you stayed hooked is the most valuable place in the whole study.",
    },
    turn: {
      title: "Turning point",
      what: "Marks a story pivot and saves the frame.",
      when: "Five or six times in a whole film, no more.",
      why: "Laid over the pacing curve, these few timestamps reveal the act structure.",
    },
    character: {
      title: "Character beat",
      what: "Marks the moment something new opens up about a character.",
      when: "A reveal, a contradiction, a choice under pressure.",
      why: "Shows you where the writer chose to open each character, and in what order.",
    },
    shot: {
      title: "Shot to keep",
      what: "Saves the frame plus its full composition measurement.",
      when: "Any frame that makes you ask how it was made.",
      why: "Twenty of these from one film show you your own taste in a single glance.",
    },
    break: {
      title: "New scene",
      what: "Forces a scene boundary at this exact moment, overriding the automatic detection.",
      when: "Whenever you see the scene change but the extension missed it.",
      why: "Your eye beats the heuristic. The scene log is only as good as these corrections.",
    },
    note: {
      title: "Note",
      what: "Pauses the film and opens a box for free text — you can dictate into it.",
      when: "Best used for payoffs: write down what just cashed in and where it was planted.",
      why: "Setup-and-payoff is the one thing no measurement can catch, because it needs memory.",
    },
    grid: {
      title: "Composition grid",
      what: "Draws a composition guide over the actual picture area, ignoring black bars.",
      when: "Any time, playing or paused. Pause for a serious look.",
      why: "Fourteen guides, from rule of thirds to the golden spiral to a 9:16 reel crop box.",
    },
    guides: {
      title: "Previous / next guide",
      what: "Cycles through the fourteen guides: thirds, phi, spiral, golden triangle, dynamic symmetry, centre, diagonals, symmetry, radial, horizon, look room, crop box, quadrants, off.",
      when: "Start with Rule of Thirds. Dynamic symmetry is the busiest — leave it for later.",
      why: "Each guide is a different theory of where things belong in a frame.",
    },
    weight: {
      title: "Machine lines",
      what: "Shows what the maths found: a green dot at the frame's visual weight, a red dot at the nearest compositional anchor, blue lines for the strongest straight edges, and the vanishing point when one exists.",
      when: "Keep on while studying framing; switch off when it distracts.",
      why: "This layer changes with the picture — pause the film to read it properly.",
    },
    pen: {
      title: "Pen",
      what: "Lets you draw straight onto the frame. The film pauses, and your marks are burned into every frame the extension saves after that.",
      when: "When you want to circle a subject or trace a line to explain something.",
      why: "⌥Z undoes the last stroke, ⌥X clears everything, and the pen button cycles colour on a second press.",
    },
    tag: {
      title: "Technique tags",
      what: "Opens a searchable palette of 75 composition techniques across ten groups, with the ones the measurements suggest shown first.",
      when: "Paused on a frame worth naming.",
      why: "You confirm rather than recall, so the whole vocabulary stays usable without memorising it.",
    },
    snap: {
      title: "Snapshot",
      what: "Saves two PNGs at full video resolution: one clean frame and one with the grid burned in. Pen marks appear in both.",
      when: "On any frame you want to teach from.",
      why: "A frame with the grid drawn on it explains composition better than any paragraph.",
    },
    screen: {
      title: "Screen capture",
      what: "Captures the whole visible tab instead of just the video, so anything another extension has drawn on the page is included, then crops to the player.",
      when: "Press Alt+Shift+K — Chrome only grants capture permission for its own shortcut, so this button can only point you at that key.",
      why: "The canvas snapshot cannot see other extensions; this one can, at viewport resolution rather than video resolution.",
    },
    measure: {
      title: "Measure this frame",
      what: "Reads the frame right now and fills the readout: visual weight, nearest anchor, symmetry, dominant lines, tilt.",
      when: "Paused on a frame you want numbers for.",
      why: "Works even with recording off, because it measures what is on screen rather than the film's history.",
    },
    zip: {
      title: "Export ZIP",
      what: "Everything in one archive: session.json, the CSV tables, your saved frames, the transcript, and a ready-made prompt for building the report.",
      when: "When you finish a film, or any time you want a backup.",
      why: "Nothing leaves the browser until you press this.",
    },
    pdf: {
      title: "Export PDF",
      what: "Builds a printable study report on the spot: the session's numbers, every lens's marks with their answers, and your saved frames.",
      when: "After a watching pass, when you want something to read or hand to someone.",
      why: "Made inside the browser with no server, so it costs nothing and nothing is uploaded.",
    },
    json: {
      title: "Export JSON",
      what: "Just the data, without the images — a small file.",
      when: "When you only need the numbers.",
      why: "Easier to attach somewhere when the frames do not matter.",
    },
    role: {
      title: "Lens",
      what: "Switches which craft you are watching as. The six keys ⌥3–⌥8 change meaning with the lens, and the readout changes with it too.",
      when: "Pick one lens per watching pass — ⌥Q cycles, the ☰ button chooses which lenses stay in the rotation.",
      why: "A DOP and a story writer notice different things. Trying to do both at once means doing neither.",
    },
  };

  let helpEl = null;
  let helpTimer = null;

  function hideHelp() {
    clearTimeout(helpTimer);
    if (helpEl) helpEl.classList.remove("show");
  }

  function showHelp(data, anchor) {
    if (!data) return;
    if (!helpEl) {
      helpEl = document.createElement("div");
      helpEl.id = "filmlens-help";
      document.body.appendChild(helpEl);
    }
    helpEl.innerHTML = `
      <h4>${data.title}</h4>
      <div class="fl-hrow"><span>What</span><p>${data.what}</p></div>
      <div class="fl-hrow"><span>When</span><p>${data.when}</p></div>
      <div class="fl-hrow"><span>Why</span><p>${data.why}</p></div>`;
    helpEl.classList.add("show");

    const a = anchor.getBoundingClientRect();
    const h = helpEl.getBoundingClientRect();
    let left = a.left - h.width - 12;
    if (left < 8) left = a.right + 12;
    let top = a.top - 8;
    if (top + h.height > window.innerHeight - 8) top = window.innerHeight - h.height - 8;
    if (top < 8) top = 8;
    helpEl.style.left = left + "px";
    helpEl.style.top = top + "px";
  }

  /** attach the three-line hover card to any element */
  function attachHelp(el, data) {
    if (!el || !data) return;
    el.addEventListener("mouseenter", () => {
      clearTimeout(helpTimer);
      helpTimer = setTimeout(() => showHelp(data, el), 320);
    });
    el.addEventListener("mouseleave", hideHelp);
    el.addEventListener("click", hideHelp);
  }

  // ============================================================== PDF =====
  function exportPdf() {
    const payload = buildPayload();
    const doc = new FL.Pdf(`FilmLens — ${payload.video.title}`);
    const a = payload.analysis;
    const fr = payload.frame_rate;

    doc.heading(payload.video.title || "Film breakdown", 1);
    doc.text(
      `FilmLens study report · ${new Date().toLocaleString()}` +
        (payload.video.channel ? ` · ${payload.video.channel}` : ""),
      { size: 9, color: [0.45, 0.45, 0.5] }
    );
    doc.space(6);

    doc.heading("What the machine measured", 2);
    doc.kv("Shots detected", a.shot_count);
    doc.kv("Scenes grouped", a.scene_count);
    doc.kv("Average shot length", a.asl ? `${a.asl}s` : "—");
    doc.kv("Median shot", a.median_shot ? `${a.median_shot}s` : "—");
    doc.kv("Cuts per minute", a.cuts_per_min ?? "—");
    doc.kv("Watched / sampled", a.coverage_pct ? `${a.coverage_pct}% of the film` : "—");
    if (fr) {
      doc.kv("Frame rate", `${fr.measured_fps} fps measured, source likely ${fr.likely_source_fps}`);
      if (fr.note) doc.kv("Frame-rate note", fr.note);
    }
    const cam = payload.composition_summary && payload.composition_summary.camera_moves;
    if (cam && Object.keys(cam).length) {
      doc.kv("Camera moves", Object.entries(cam).map(([k, v]) => `${k} ${v}`).join(", "));
    }
    doc.space(4);

    if (a.fastest_stretches && a.fastest_stretches.length) {
      doc.heading("Pacing", 2);
      doc.text("Fastest stretches: " + a.fastest_stretches.map((s) => `${s.from}–${s.to} (${s.asl}s)`).join(", "), { size: 9.6 });
      doc.text("Slowest stretches: " + a.slowest_stretches.map((s) => `${s.from}–${s.to} (${s.asl}s)`).join(", "), { size: 9.6 });
      doc.space(4);
    }

    // your own attention track
    if (payload.markers.length) {
      doc.heading("Your attention track", 2);
      const hooked = payload.markers.filter((m) => m.type === "hooked");
      const drift = payload.markers.filter((m) => m.type === "drifted");
      doc.text(`Hooked at: ${hooked.map((m) => fmt(m.t)).join(", ") || "—"}`, { size: 9.6 });
      doc.text(`Drifted at: ${drift.map((m) => fmt(m.t)).join(", ") || "—"}`, { size: 9.6 });
      doc.space(4);
    }

    // one chapter per lens
    const roles = {};
    for (const rm of payload.role_marks || []) (roles[rm.role] = roles[rm.role] || []).push(rm);
    for (const [roleId, marks] of Object.entries(roles)) {
      const role = FL.Roles.BY_ID[roleId] || { name: roleId };
      doc.heading(`${role.name} — ${marks.length} marks`, 2);
      for (const rm of marks) {
        doc.text(`${fmt(rm.t)}  ${rm.label}`, { size: 10.4, bold: true, gap: 1 });
        if (rm.answers) {
          doc.text(Object.entries(rm.answers).map(([k, v]) => `${k}: ${v}`).join("   ·   "), {
            size: 9.4, indent: 10, color: [0.3, 0.3, 0.35], gap: 1,
          });
        }
        if (rm.note) doc.text(`"${rm.note}"`, { size: 9.6, indent: 10, gap: 1 });
        if (rm.linked_to !== null && rm.linked_to !== undefined) {
          const src = (payload.role_marks || []).find((x) => x.i === rm.linked_to);
          if (src) doc.text(`pays off the setup at ${fmt(src.t)}`, { size: 9, indent: 10, color: [0.5, 0.35, 0.1], gap: 1 });
        }
        if (rm.machine && rm.machine.camera) {
          doc.text(`measured camera: ${rm.machine.camera}${rm.machine.shot_dur ? ` · shot ${rm.machine.shot_dur}s` : ""}`, {
            size: 9, indent: 10, color: [0.35, 0.5, 0.4], gap: 1,
          });
        }
        if (rm.keyframe && S.frames[frameId(rm.keyframe)]) {
          try {
            doc.image(FL.zip.dataUrlToBytes(S.frames[frameId(rm.keyframe)]), 300);
          } catch (e) { /* a bad frame must not break the report */ }
        }
        doc.space(3);
      }
    }

    // tagged frames
    if (payload.tags && payload.tags.length) {
      doc.heading("Technique tags", 2);
      for (const tg of payload.tags) {
        doc.text(`${fmt(tg.t)}  ${tg.labels.join(", ")}`, { size: 10, bold: true, gap: 1 });
        if (tg.keyframe && S.frames[frameId(tg.keyframe)]) {
          try {
            doc.image(FL.zip.dataUrlToBytes(S.frames[frameId(tg.keyframe)]), 300);
          } catch (e) { /* skip */ }
        }
      }
    }

    // scene log
    if (payload.scenes.length) {
      doc.heading("Scene log", 2);
      for (const sc of payload.scenes) {
        const bits = [
          `${fmt(sc.start)}–${fmt(sc.end)}`,
          `${sc.dur}s`,
          `${sc.shot_count} shots`,
          sc.asl ? `ASL ${sc.asl}s` : null,
          sc.user && sc.user.charge_in ? `in ${sc.user.charge_in}` : null,
          sc.user && sc.user.charge_out ? `out ${sc.user.charge_out}` : null,
          sc.user && sc.user.essential ? `essential: ${sc.user.essential}` : null,
        ].filter(Boolean);
        doc.text(`Scene ${sc.i + 1} — ${bits.join(" · ")}`, { size: 9.4, gap: 0.5 });
        if (sc.user && sc.user.note) doc.text(`"${sc.user.note}"`, { size: 9, indent: 10, color: [0.35, 0.35, 0.4], gap: 1 });
      }
    }

    doc.space(10);
    doc.rule();
    doc.text(
      "Measurements are evidence, not verdicts. The engine knows where a frame's visual weight sits; it does not know what the subject is. Aperture cannot be read from a video at all — depth here is measured from how soft the background looks.",
      { size: 8.6, color: [0.45, 0.45, 0.5] }
    );

    download(doc.build(), `filmlens_${safeName(payload.video.title)}.pdf`);
    toast("📄  PDF report downloaded");
  }

  function frameId(path) {
    return String(path).replace("frames/", "").replace(".jpg", "");
  }

  // ---------------------------------------------------------------- panel --
  function showWarn(msg) {
    S._warn = msg;
  }

  function render() {
    if (!panel) return;
    const a = S.shots.length
      ? S.shots.reduce((x, s) => x + (s.dur || 0), 0) / S.shots.length
      : 0;
    const cur = S._open.shot && video ? video.currentTime - S._open.shot.start : 0;

    const dot = $(".fl-dot", panel);
    dot.classList.toggle("on", !!S.recording);

    $("#fl-shots", panel).textContent = S.shots.length;
    $("#fl-scenes", panel).textContent = S.scenes.length + (S._open.scene ? 1 : 0);
    $("#fl-asl", panel).textContent = a ? a.toFixed(1) + "s" : "—";
    $("#fl-cur", panel).textContent = cur > 0 ? cur.toFixed(1) + "s" : "—";
    $("#fl-marks", panel).textContent = S.markers.length;
    $("#fl-time", panel).textContent = video ? fmt(video.currentTime) : "0:00";

    // STATUS tile — it used to sit there empty; now it actually reports
    const st = $("#fl-drm", panel);
    if (S.flags.drm_suspected) {
      st.textContent = "DRM";
      st.style.color = "var(--fl-bad)";
    } else if (S.recording) {
      st.textContent = "REC";
      st.style.color = "var(--fl-good)";
    } else {
      st.textContent = "OK";
      st.style.color = "";
    }

    const wBtn = $("#fl-weight", panel);
    wBtn.classList.toggle("on", !!S.settings.showWeight);
    wBtn.innerHTML = `👁 Machine lines: ${S.settings.showWeight ? "ON" : "OFF"} <kbd>⌥W</kbd>`;

    const penBtn = $("#fl-pen", panel);
    penBtn.classList.toggle("on", !!S.settings.pen);
    penBtn.innerHTML = S.settings.pen
      ? `🖊 Pen ON${strokes.length ? ` · ${strokes.length}` : ""} <kbd>⌥Y</kbd>`
      : `🖊 Pen <kbd>⌥Y</kbd>`;
    penBtn.style.color = S.settings.pen ? PEN_COLORS[S.settings.penColor || 0] : "";

    $("#fl-rec", panel).textContent = S.recording ? "⏸ Pause recording" : "⏺ Start recording";
    panel.querySelectorAll("[data-mode]").forEach((b) =>
      b.classList.toggle("active", (b.dataset.mode === "dissect") === !!S.settings.dissect)
    );

    const warnEl = $("#fl-warn", panel);
    if (S._warn) { warnEl.textContent = S._warn; warnEl.style.display = "block"; }
    else warnEl.style.display = "none";

    // ---- role bar, role slots, and the generic row they replace ----
    const role = activeRole();
    $("#fl-roleicon", panel).textContent = role.icon;
    $("#fl-rolename", panel).textContent = role.name;
    $("#fl-generic", panel).style.display = role.id === "free" ? "block" : "none";

    const slotsEl = $("#fl-slots", panel);
    if (role.slots.length) {
      slotsEl.style.display = "block";
      slotsEl.innerHTML = role.slots
        .map(
          (s, idx) =>
            `<button class="fl-slot${s.type === "card" ? " card" : ""}" data-slot="${idx + 3}" title="${s.label}">
               <kbd>⌥${idx + 3}</kbd> ${s.short}
             </button>`
        )
        .join("");
      slotsEl.querySelectorAll("[data-slot]").forEach((b) => {
        b.addEventListener("click", () => fireRoleSlot(+b.dataset.slot));
        const slot = role.slots[+b.dataset.slot - 3];
        if (slot && slot.help) {
          attachHelp(b, {
            title: `${role.icon} ${slot.label}`,
            what: slot.help.what,
            when: slot.help.when,
            why: slot.help.why,
          });
        }
      });
    } else {
      slotsEl.style.display = "none";
      slotsEl.innerHTML = "";
    }

    // composition readout
    const comp = $("#fl-comp", panel);
    const gDef = FL.Compose.GUIDES.find((x) => x.id === S.settings.guide);
    const gName = gDef ? gDef.label : S.settings.guide;
    const fps = S.frame_rate || FL.Compose.Fps.estimate(video);
    if (fps) S.frame_rate = fps;
    const lastShot = S.shots[S.shots.length - 1];
    const bits = [];
    const head = role.id === "free"
      ? `${S.settings.overlayOn ? "📐 " + gName : "📐 grid off"}`
      : `${role.icon} ${role.name}`;
    bits.push(
      `<div class="fl-comp-head">${head}${
        S.role_marks.length ? ` · ${S.role_marks.length} marks` : ""
      }${S.tags.length ? ` · 🏷 ${S.tags.length}` : ""}</div>`
    );

    if (role.id === "free") {
      const shown = displayAnalysis || lastAnalysis;
      if (shown && !shown.error) {
        for (const h of shown.hints.slice(0, 4)) bits.push(`<div>${h}</div>`);
      }
      if (lastShot && lastShot.camera && lastShot.camera !== "unknown") {
        bits.push(`<div>Camera: ${lastShot.camera_detail || lastShot.camera}</div>`);
      }
    } else {
      for (const line of roleReadout()) bits.push(`<div>${line}</div>`);
    }
    if (fps) {
      bits.push(
        `<div>Frame rate: ${fps.measured_fps} fps${
          fps.confident ? ` (source ~${fps.likely_source_fps})` : ""
        }</div>`
      );
      if (fps.note) bits.push(`<div class="fl-comp-note">${fps.note}</div>`);
    }
    comp.innerHTML = bits.join("");

    const log = $("#fl-log", panel);
    const recent = S.markers.slice(-4).reverse();
    log.innerHTML = recent.length
      ? recent
          .map((m) => {
            const meta = MARKER_TYPES[m.type] || { emoji: "•" };
            const note = m.note ? " — " + m.note.slice(0, 30) : "";
            return `<div>${meta.emoji} <b>${fmt(m.t)}</b> ${m.label}${note}</div>`;
          })
          .join("")
      : `<div>No markers yet. Press Alt+1 to start.</div>`;
  }

  function buildPanel() {
    panel = document.createElement("div");
    panel.id = "filmlens-panel";
    panel.innerHTML = `
      <div class="fl-head">
        <span class="fl-dot"></span>
        <span class="fl-title">FilmLens</span>
        <span class="fl-title" style="flex:none;color:#9aa3af;font-weight:400" id="fl-time">0:00</span>
        <button class="fl-iconbtn" id="fl-gear" title="Settings">⚙</button>
        <button class="fl-iconbtn" id="fl-min" title="Collapse (Alt+H)">–</button>
      </div>
      <div class="fl-body">
        <div class="fl-warn" id="fl-warn" style="display:none"></div>

        <div class="fl-stats">
          <div class="fl-stat"><b id="fl-shots">0</b><span>shots</span></div>
          <div class="fl-stat"><b id="fl-scenes">0</b><span>scenes</span></div>
          <div class="fl-stat"><b id="fl-asl">—</b><span>avg shot</span></div>
          <div class="fl-stat"><b id="fl-cur">—</b><span>this shot</span></div>
          <div class="fl-stat"><b id="fl-marks">0</b><span>markers</span></div>
          <div class="fl-stat"><b id="fl-drm">·</b><span>status</span></div>
        </div>

        <div class="fl-rolebar">
          <span class="fl-roleic" id="fl-roleicon">👀</span>
          <span class="fl-rolename" id="fl-rolename">Free watching</span>
          <button class="fl-iconbtn" id="fl-rolenext" title="Next lens (⌥Q)">⇄</button>
          <button class="fl-iconbtn" id="fl-rolepick" title="Choose lenses">☰</button>
        </div>

        <div class="fl-mode">
          <button data-mode="silent">Silent</button>
          <button data-mode="dissect">Dissect</button>
        </div>

        <div class="fl-row">
          <button class="fl-btn wide primary" id="fl-rec">⏺ Start recording</button>
        </div>
        <div class="fl-row">
          <button class="fl-btn" data-mark="hooked">🔥 Hooked <kbd>⌥1</kbd></button>
          <button class="fl-btn" data-mark="drifted">😐 Drift <kbd>⌥2</kbd></button>
        </div>
        <div id="fl-generic">
          <div class="fl-row">
            <button class="fl-btn" data-mark="turn">⚡ Turn <kbd>⌥T</kbd></button>
            <button class="fl-btn" data-mark="character">🎭 Char <kbd>⌥C</kbd></button>
            <button class="fl-btn" data-mark="shot">🎞 Shot <kbd>⌥S</kbd></button>
          </div>
        </div>

        <div class="fl-slots" id="fl-slots"></div>
        <div class="fl-row">
          <button class="fl-btn" id="fl-break">✂ New scene <kbd>⌥B</kbd></button>
          <button class="fl-btn ghost" id="fl-note-btn">✍️ Note <kbd>⌥N</kbd></button>
        </div>
        <div class="fl-row">
          <button class="fl-btn" id="fl-grid">📐 Grid <kbd>⌥G</kbd></button>
          <button class="fl-btn ghost" id="fl-prevg" title="Previous guide (⌥U)">◀</button>
          <button class="fl-btn ghost" id="fl-nextg" title="Next guide (⌥L)">▶</button>
        </div>
        <div class="fl-row">
          <button class="fl-btn wide" id="fl-weight">👁 Machine lines <kbd>⌥W</kbd></button>
        </div>
        <div class="fl-row">
          <button class="fl-btn" id="fl-pen">🖊 Pen <kbd>⌥Y</kbd></button>
          <button class="fl-btn ghost" id="fl-penundo" title="Undo last stroke (⌥Z)">↶</button>
          <button class="fl-btn ghost" id="fl-penclear" title="Clear drawing (⌥X)">✕</button>
        </div>
        <div class="fl-row">
          <button class="fl-btn" id="fl-tag">🏷 Tag <kbd>⌥F</kbd></button>
          <button class="fl-btn" id="fl-snap">📸 Snap <kbd>⌥P</kbd></button>
        </div>
        <div class="fl-row">
          <button class="fl-btn" id="fl-screen">📷 Screen <kbd>⌥⇧K</kbd></button>
          <button class="fl-btn ghost" id="fl-measure">📊 Measure <kbd>⌥M</kbd></button>
        </div>

        <div class="fl-comp" id="fl-comp"></div>

        <div class="fl-row">
          <button class="fl-btn primary" id="fl-zip">⬇ ZIP <kbd>⌥E</kbd></button>
          <button class="fl-btn" id="fl-pdf">📄 PDF <kbd>⌥J</kbd></button>
          <button class="fl-btn ghost" id="fl-json">JSON</button>
        </div>

        <div class="fl-log" id="fl-log"></div>

        <div class="fl-settings" id="fl-set">
          <div class="fl-field">
            <span>Cut sensitivity</span>
            <input type="range" id="fl-sens" min="0" max="1" step="0.05">
          </div>
          <div class="fl-field">
            <span>Scene split (higher = more scenes)</span>
            <input type="range" id="fl-scenesens" min="0" max="1" step="0.05">
          </div>
          <div class="fl-field">
            <span>Min scene length (s)</span>
            <input type="range" id="fl-minscene" min="4" max="60" step="2">
            <b id="fl-minscene-v" style="color:#e8eaed;width:22px;text-align:right"></b>
          </div>
          <div class="fl-field">
            <span>Live captions capture</span>
            <input type="checkbox" id="fl-caps">
          </div>
          <div class="fl-field">
            <span>Scene keyframes</span>
            <input type="checkbox" id="fl-kf">
          </div>
          <div class="fl-field">
            <span>Measure composition (marked + scenes)</span>
            <input type="checkbox" id="fl-comp-on">
          </div>
          <div class="fl-field">
            <span>Clean mode (dim lines, labels off)</span>
            <input type="checkbox" id="fl-clean">
          </div>
          <div class="fl-row">
            <button class="fl-btn ghost" id="fl-import">Transcript import</button>
            <button class="fl-btn ghost" id="fl-reset">Reset session</button>
          </div>
        </div>
      </div>`;

    document.body.appendChild(panel);

    // drag
    const head = $(".fl-head", panel);
    let drag = null;
    head.addEventListener("mousedown", (e) => {
      if (e.target.closest(".fl-iconbtn")) return;
      const r = panel.getBoundingClientRect();
      drag = { x: e.clientX - r.left, y: e.clientY - r.top };
      e.preventDefault();
    });
    window.addEventListener("mousemove", (e) => {
      if (!drag) return;
      panel.style.left = e.clientX - drag.x + "px";
      panel.style.top = e.clientY - drag.y + "px";
      panel.style.right = "auto";
      panel.style.bottom = "auto";
    });
    window.addEventListener("mouseup", () => (drag = null));

    $("#fl-min", panel).addEventListener("click", () => panel.classList.toggle("fl-collapsed"));
    $("#fl-gear", panel).addEventListener("click", () => $("#fl-set", panel).classList.toggle("open"));
    $("#fl-rec", panel).addEventListener("click", toggleRecording);
    $("#fl-zip", panel).addEventListener("click", exportZip);
    $("#fl-json", panel).addEventListener("click", exportJson);
    $("#fl-note-btn", panel).addEventListener("click", showNoteCard);
    $("#fl-break", panel).addEventListener("click", manualSceneBreak);
    $("#fl-import", panel).addEventListener("click", importTranscriptPanel);
    $("#fl-reset", panel).addEventListener("click", () => {
      if (!confirm("This erases the whole session for this film. Are you sure?")) return;
      S = blankSession(currentVideoId);
      S.video.duration_sec = video ? +video.duration.toFixed(1) : 0;
      detector.reset();
      chrome.storage.local.remove(storageKey(currentVideoId));
      render();
      toast("Session reset");
    });

    panel.querySelectorAll("[data-mark]").forEach((b) =>
      b.addEventListener("click", () => addMarker(b.dataset.mark))
    );
    panel.querySelectorAll("[data-mode]").forEach((b) =>
      b.addEventListener("click", () => {
        S.settings.dissect = b.dataset.mode === "dissect";
        render();
        saveSoon();
        toast(S.settings.dissect ? "Dissect mode — pauses at every scene boundary" : "Silent mode — hotkeys only");
      })
    );

    const sens = $("#fl-sens", panel);
    sens.value = S.settings.sensitivity;
    sens.addEventListener("input", () => {
      S.settings.sensitivity = +sens.value;
      detector.sensitivity = +sens.value;
      saveSoon();
    });

    const ssens = $("#fl-scenesens", panel);
    ssens.value = S.settings.sceneSensitivity;
    ssens.addEventListener("input", () => {
      S.settings.sceneSensitivity = +ssens.value;
      saveSoon();
    });

    const ms = $("#fl-minscene", panel);
    ms.value = S.settings.minScene;
    $("#fl-minscene-v", panel).textContent = S.settings.minScene;
    ms.addEventListener("input", () => {
      S.settings.minScene = +ms.value;
      $("#fl-minscene-v", panel).textContent = ms.value;
      saveSoon();
    });

    const caps = $("#fl-caps", panel);
    caps.checked = S.settings.captureCaptions;
    caps.addEventListener("change", () => { S.settings.captureCaptions = caps.checked; saveSoon(); });

    const kf = $("#fl-kf", panel);
    kf.checked = S.settings.autoKeyframes;
    kf.addEventListener("change", () => { S.settings.autoKeyframes = kf.checked; saveSoon(); });

    const compOn = $("#fl-comp-on", panel);
    compOn.checked = S.settings.composition;
    compOn.addEventListener("change", () => { S.settings.composition = compOn.checked; saveSoon(); });

    const cleanBox = $("#fl-clean", panel);
    cleanBox.checked = !!S.settings.clean;
    cleanBox.addEventListener("change", () => {
      S.settings.clean = cleanBox.checked;
      drawOverlay();
      saveSoon();
    });

    $("#fl-grid", panel).addEventListener("click", () => setOverlay(!S.settings.overlayOn));
    $("#fl-weight", panel).addEventListener("click", toggleWeightLayer);
    $("#fl-rolenext", panel).addEventListener("click", () => cycleRole(1));
    $("#fl-rolepick", panel).addEventListener("click", showRolePicker);
    $("#fl-pdf", panel).addEventListener("click", exportPdf);
    $("#fl-screen", panel).addEventListener("click", captureScreen);
    $("#fl-penundo", panel).addEventListener("click", penUndo);
    $("#fl-penclear", panel).addEventListener("click", penClear);
    $("#fl-pen", panel).addEventListener("click", () => {
      if (S.settings.pen) cyclePenColor();
      else setPen(true);
    });
    $("#fl-pen", panel).addEventListener("dblclick", () => setPen(false));

    // three-line hover help on every control
    const helpMap = {
      "#fl-rec": HELP.rec, '[data-mark="hooked"]': HELP.hooked, '[data-mark="drifted"]': HELP.drifted,
      '[data-mark="turn"]': HELP.turn, '[data-mark="character"]': HELP.character,
      '[data-mark="shot"]': HELP.shot, "#fl-break": HELP.break, "#fl-note-btn": HELP.note,
      "#fl-grid": HELP.grid, "#fl-nextg": HELP.guides, "#fl-prevg": HELP.guides,
      "#fl-weight": HELP.weight, "#fl-pen": HELP.pen, "#fl-penundo": HELP.pen,
      "#fl-penclear": HELP.pen, "#fl-tag": HELP.tag, "#fl-snap": HELP.snap,
      "#fl-screen": HELP.screen, "#fl-measure": HELP.measure, "#fl-zip": HELP.zip,
      "#fl-pdf": HELP.pdf, "#fl-json": HELP.json, "#fl-rolenext": HELP.role,
      "#fl-rolepick": HELP.role, ".fl-rolename": HELP.role,
      '[data-mode="silent"]': HELP.mode, '[data-mode="dissect"]': HELP.mode,
    };
    for (const [sel, data] of Object.entries(helpMap)) {
      panel.querySelectorAll(sel).forEach((el) => attachHelp(el, data));
    }
    $("#fl-nextg", panel).addEventListener("click", () => cycleGuide(1));
    $("#fl-prevg", panel).addEventListener("click", () => cycleGuide(-1));
    $("#fl-tag", panel).addEventListener("click", showTagPalette);
    $("#fl-snap", panel).addEventListener("click", snapshot);
    $("#fl-measure", panel).addEventListener("click", showReadout);
  }

  function toggleRecording() {
    S.recording = !S.recording;
    if (S.recording) {
      detector.reset();
      lastSampled = -1;
      if (video) S.video.duration_sec = +(video.duration || 0).toFixed(1);
      const ch = $("ytd-channel-name #text") || $("#owner #channel-name #text");
      if (ch) S.video.channel = ch.textContent.trim();
      toast("Recording on — now play the film");
    } else {
      toast("Recording paused");
    }
    render();
    saveSoon();
  }

  // -------------------------------------------------------------- hotkeys --
  function onKey(e) {
    if (!S) return;
    const tag = (e.target && e.target.tagName) || "";
    if (/INPUT|TEXTAREA|SELECT/.test(tag) || (e.target && e.target.isContentEditable)) return;
    if (!e.altKey || e.ctrlKey || e.metaKey) return;

    const map = {
      Digit1: () => addMarker("hooked"),
      Digit2: () => addMarker("drifted"),
      Digit3: () => fireRoleSlot(3),
      Digit4: () => fireRoleSlot(4),
      Digit5: () => fireRoleSlot(5),
      Digit6: () => fireRoleSlot(6),
      Digit7: () => fireRoleSlot(7),
      Digit8: () => fireRoleSlot(8),
      KeyQ: () => cycleRole(1),
      KeyT: () => addMarker("turn"),
      KeyC: () => addMarker("character"),
      KeyS: () => addMarker("shot"),
      KeyN: () => showNoteCard(),
      KeyB: () => manualSceneBreak(),
      KeyG: () => setOverlay(!S.settings.overlayOn),
      KeyL: () => cycleGuide(1),
      KeyU: () => cycleGuide(-1),
      KeyO: () => {
        S.settings.spiralFlip = ((S.settings.spiralFlip || 0) + 1) % 4;
        drawOverlay();
        saveSoon();
      },
      KeyW: () => toggleWeightLayer(),
      KeyM: () => showReadout(),
      KeyP: () => snapshot(),
      KeyF: () => showTagPalette(),
      KeyY: () => setPen(!S.settings.pen),
      KeyZ: () => penUndo(),
      KeyX: () => penClear(),
      KeyK: () => captureScreen(),
      KeyJ: () => exportPdf(),
      KeyR: () => toggleRecording(),
      KeyE: () => exportZip(),
      KeyH: () => panel && panel.classList.toggle("fl-collapsed"),
      KeyD: () => {
        S.settings.dissect = !S.settings.dissect;
        render();
        toast(S.settings.dissect ? "Dissect mode ON" : "Silent mode ON");
      },
    };

    const fn = map[e.code];
    if (fn) {
      e.preventDefault();
      e.stopImmediatePropagation();
      fn();
    }
  }

  // ----------------------------------------------------------- fullscreen --
  function onFullscreenChange() {
    const fsEl = document.fullscreenElement;
    if (!panel) return;
    (fsEl || document.body).appendChild(panel);
    if (card) (fsEl || document.body).appendChild(card);
    if (S && S.settings.overlayOn) setTimeout(drawOverlay, 120);
  }

  // ============================================================ licence ====
  const LOCK_MESSAGES = {
    no_public_key:
      "This build has no licence key yet. Run server/scripts/generate-keys.mjs and paste the public key into src/licence.js.",
    not_activated:
      "Enter your email and invite code to activate. Click the FilmLens icon in the Chrome toolbar.",
    expired:
      "Your licence needs a refresh. Connect to the internet and click the FilmLens icon in the toolbar.",
    wrong_device:
      "This licence was activated in a different browser profile. Activate again from the FilmLens icon.",
    bad_signature:
      "The stored licence failed its signature check. Activate again from the FilmLens icon.",
    malformed:
      "The stored licence is unreadable. Activate again from the FilmLens icon.",
  };

  function buildLockedPanel(lic) {
    panel = document.createElement("div");
    panel.id = "filmlens-panel";
    panel.innerHTML = `
      <div class="fl-head">
        <span class="fl-dot"></span>
        <span class="fl-title">FilmLens</span>
        <span class="fl-title" style="flex:none;color:#9aa3af;font-weight:400">locked</span>
        <button class="fl-iconbtn" id="fl-min" title="Collapse">–</button>
      </div>
      <div class="fl-body">
        <div class="fl-warn">🔒 ${LOCK_MESSAGES[lic.reason] || `Licence check failed (${lic.reason}).`}</div>
        <div class="fl-comp">
          <div class="fl-comp-head">How to activate</div>
          <div>1. Click the FilmLens icon in the Chrome toolbar.</div>
          <div>2. Enter the email and invite code you were given.</div>
          <div>3. Reload this page.</div>
        </div>
        ${lic.email ? `<div class="fl-comp"><div>Last used: ${lic.email}</div></div>` : ""}
        <div class="fl-comp" style="color:#6b7280">
          <div>Device ID ${String(lic.device_id || "").slice(0, 8)}</div>
        </div>
      </div>`;
    document.body.appendChild(panel);
    $("#fl-min", panel).addEventListener("click", () => panel.classList.toggle("fl-collapsed"));
  }

  // ------------------------------------------------------------ lifecycle --
  function getVideoId() {
    const m = location.href.match(/[?&]v=([\w-]{5,})/);
    return m ? m[1] : null;
  }

  async function boot() {
    const id = getVideoId();
    if (!id) return teardown();
    if (id === currentVideoId && panel) return;

    teardown();
    currentVideoId = id;

    video = $("#movie_player video") || $("video");
    if (!video) {
      setTimeout(boot, 1200);
      return;
    }

    // Access gate. Verified offline against the embedded public key, so a
    // dropped connection never locks anyone out before their token expires.
    const lic = await FL.Licence.check();
    if (!lic.active) {
      buildLockedPanel(lic);
      return;
    }

    S = await loadSession(id);
    S.settings = { ...DEFAULTS, ...(S.settings || {}) };
    S._open = S._open || { shot: null, scene: null, lastCharge: null };
    S._open.shot = null;
    S._open.scene = null;
    S._pending = null;
    S.frames = S.frames || {};
    S.tags = S.tags || [];
    S.role_marks = S.role_marks || [];
    if (!FL.Roles.BY_ID[S.settings.role]) S.settings.role = "free";
    S.recording = false; // never auto-record; you press the button
    S.video.title = document.title.replace(/ - YouTube$/, "");
    S.video.duration_sec = +(video.duration || S.video.duration_sec || 0).toFixed(1);

    detector = new FL.ShotDetector({
      sensitivity: S.settings.sensitivity,
      minShot: S.settings.minShot,
    });
    motion = new FL.Compose.Motion();
    smoother = new FL.Compose.Smoother();
    FL.Compose.Fps.reset();
    lastAnalysis = null;
    displayAnalysis = null;

    buildPanel();
    render();
    attachLoop();
    if (S.settings.overlayOn) setOverlay(true);

    window.addEventListener("resize", drawOverlay);
    video.addEventListener("loadeddata", () => { lastAnalysis = null; drawOverlay(); });

    video.addEventListener("loadedmetadata", () => {
      S.video.duration_sec = +(video.duration || 0).toFixed(1);
      attachLoop();
    });

    S._capTimer = setInterval(pollCaptions, 600);
    S._uiTimer = setInterval(() => { if (S && S.recording) render(); }, 1000);

    window.addEventListener("keydown", onKey, true);
    document.addEventListener("fullscreenchange", onFullscreenChange);
  }

  function teardown() {
    if (panel) { panel.remove(); panel = null; }
    if (card) { card.remove(); card = null; }
    if (overlay) { overlay.remove(); overlay = null; overlayCtx = null; }
    if (drawCanvas) { drawCanvas.remove(); drawCanvas = null; drawCtx = null; }
    if (helpEl) { helpEl.remove(); helpEl = null; }
    strokes = [];
    penStroke = null;
    if (overlayTimer) { clearInterval(overlayTimer); overlayTimer = null; }
    window.removeEventListener("resize", drawOverlay);
    if (S && S._capTimer) clearInterval(S._capTimer);
    if (S && S._uiTimer) clearInterval(S._uiTimer);
    if (pollHandle) { clearInterval(pollHandle); pollHandle = null; }
    if (rafHandle && video && video.cancelVideoFrameCallback) {
      try { video.cancelVideoFrameCallback(rafHandle); } catch (e) {}
    }
    rafHandle = null;
    window.removeEventListener("keydown", onKey, true);
    document.removeEventListener("fullscreenchange", onFullscreenChange);
    currentVideoId = null;
    warnedDrm = false;
  }

  // YouTube is a single-page app — watch for navigation
  let lastHref = location.href;
  setInterval(() => {
    if (location.href !== lastHref) {
      lastHref = location.href;
      setTimeout(boot, 900);
    }
  }, 700);
  document.addEventListener("yt-navigate-finish", () => setTimeout(boot, 900));

  window.addEventListener("beforeunload", () => {
    if (S) {
      try { chrome.storage.local.set({ [storageKey(S.video.id)]: S }); } catch (e) {}
    }
  });

  if (!window.__FILMLENS_TEST) boot();
})();
