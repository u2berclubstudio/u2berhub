/* FilmLens — minimal, dependency-free PDF writer.

   Only what a study report needs: Helvetica text, rules, and JPEG images
   embedded as-is (PDF reads raw JPEG through /DCTDecode, so the keyframes go
   in without being re-encoded). Byte offsets are tracked exactly, because the
   xref table at the end of a PDF has to point at real positions.

   Text is written in WinAnsi, so anything outside 0–255 (emoji, Devanagari)
   is replaced rather than corrupting the stream. */
(function () {
  "use strict";

  const FL = (window.__FILMLENS = window.__FILMLENS || {});

  const PAGE_W = 595.28; // A4 points
  const PAGE_H = 841.89;
  const MARGIN = 42;
  const LINE = 13.2;

  function latin1(str) {
    let out = "";
    for (const ch of String(str)) {
      const c = ch.codePointAt(0);
      if (c === 10 || c === 13) { out += " "; continue; }
      if (c < 32) continue;
      if (c <= 255) out += ch;
      else if (c === 0x2014 || c === 0x2013) out += "-";
      else if (c === 0x2018 || c === 0x2019) out += "'";
      else if (c === 0x201c || c === 0x201d) out += '"';
      else if (c === 0x00b7 || c === 0x2022) out += "-";
      else if (c === 0x2192) out += "->";
      else if (c === 0x00d7) out += "x";
      else if (c >= 0x1f300 || (c >= 0x2600 && c <= 0x27bf)) out += ""; // emoji
      else out += "?";
    }
    return out;
  }

  function pdfEscape(str) {
    return latin1(str).replace(/\\/g, "\\\\").replace(/\(/g, "\\(").replace(/\)/g, "\\)");
  }

  /** read width/height out of a JPEG's SOF marker */
  function jpegSize(bytes) {
    let i = 2;
    while (i < bytes.length) {
      if (bytes[i] !== 0xff) { i++; continue; }
      const marker = bytes[i + 1];
      if (marker === 0xd8 || marker === 0x01 || (marker >= 0xd0 && marker <= 0xd7)) { i += 2; continue; }
      const len = (bytes[i + 2] << 8) | bytes[i + 3];
      if (marker >= 0xc0 && marker <= 0xcf && marker !== 0xc4 && marker !== 0xc8 && marker !== 0xcc) {
        return { h: (bytes[i + 5] << 8) | bytes[i + 6], w: (bytes[i + 7] << 8) | bytes[i + 8] };
      }
      i += 2 + len;
    }
    return null;
  }

  // Helvetica advance widths (1000-unit em) — enough for honest wrapping
  const W_NORMAL = { " ": 278, "!": 278, '"': 355, "#": 556, $: 556, "%": 889, "&": 667, "'": 191, "(": 333, ")": 333, "*": 389, "+": 584, ",": 278, "-": 333, ".": 278, "/": 278, ":": 278, ";": 278, "<": 584, "=": 584, ">": 584, "?": 556, "@": 1015, "[": 278, "\\": 278, "]": 278, "^": 469, _: 556, "`": 333, "{": 334, "|": 260, "}": 334, "~": 584 };
  function charWidth(ch, bold) {
    const c = ch.charCodeAt(0);
    if (W_NORMAL[ch] !== undefined) return W_NORMAL[ch] * (bold ? 1.05 : 1);
    if (c >= 48 && c <= 57) return 556;
    if (ch >= "A" && ch <= "Z") return (bold ? 1.06 : 1) * 700;
    if (ch >= "a" && ch <= "z") return (bold ? 1.08 : 1) * 540;
    return 556;
  }
  function textWidth(str, size, bold) {
    let w = 0;
    for (const ch of latin1(str)) w += charWidth(ch, bold);
    return (w / 1000) * size;
  }

  class Pdf {
    constructor(title) {
      this.title = title || "FilmLens report";
      this.pages = [];
      this.images = []; // {bytes, w, h, name}
      this.newPage();
    }

    newPage() {
      this.page = { ops: [], images: [] };
      this.pages.push(this.page);
      this.y = PAGE_H - MARGIN;
      return this.page;
    }

    need(space) {
      if (this.y - space < MARGIN) this.newPage();
    }

    op(s) {
      this.page.ops.push(s);
    }

    /** wrap a string to the content width */
    wrap(str, size, bold, width) {
      const max = width || PAGE_W - 2 * MARGIN;
      const words = latin1(str).split(/\s+/).filter(Boolean);
      const lines = [];
      let line = "";
      for (const w of words) {
        const test = line ? line + " " + w : w;
        if (textWidth(test, size, bold) > max && line) {
          lines.push(line);
          line = w;
        } else line = test;
      }
      if (line) lines.push(line);
      return lines.length ? lines : [""];
    }

    text(str, opts = {}) {
      const size = opts.size || 10;
      const bold = !!opts.bold;
      const color = opts.color || [0.1, 0.1, 0.12];
      const indent = opts.indent || 0;
      const width = PAGE_W - 2 * MARGIN - indent;
      const lines = this.wrap(str, size, bold, width);
      for (const line of lines) {
        this.need(size + 3);
        this.op(
          `BT /${bold ? "F2" : "F1"} ${size} Tf ${color[0]} ${color[1]} ${color[2]} rg ` +
            `1 0 0 1 ${(MARGIN + indent).toFixed(2)} ${(this.y - size).toFixed(2)} Tm ` +
            `(${pdfEscape(line)}) Tj ET`
        );
        this.y -= size * 1.32;
      }
      if (opts.gap !== 0) this.y -= opts.gap || 3;
      return this;
    }

    heading(str, level = 1) {
      const size = level === 1 ? 19 : level === 2 ? 13.5 : 11.5;
      this.need(size + 18);
      if (level <= 2) this.y -= level === 1 ? 6 : 12;
      this.text(str, { size, bold: true, color: level === 1 ? [0.08, 0.08, 0.1] : [0.62, 0.38, 0.05], gap: 2 });
      if (level === 1) this.rule();
      return this;
    }

    rule(color = [0.85, 0.85, 0.87]) {
      this.need(8);
      this.op(
        `${color[0]} ${color[1]} ${color[2]} RG 0.7 w ${MARGIN} ${this.y.toFixed(2)} m ` +
          `${(PAGE_W - MARGIN).toFixed(2)} ${this.y.toFixed(2)} l S`
      );
      this.y -= 9;
      return this;
    }

    kv(label, value) {
      const size = 9.6;
      this.need(size + 4);
      this.op(
        `BT /F2 ${size} Tf 0.45 0.45 0.5 rg 1 0 0 1 ${MARGIN} ${(this.y - size).toFixed(2)} Tm ` +
          `(${pdfEscape(label)}) Tj ET`
      );
      this.op(
        `BT /F1 ${size} Tf 0.1 0.1 0.12 rg 1 0 0 1 ${(MARGIN + 132).toFixed(2)} ${(this.y - size).toFixed(2)} Tm ` +
          `(${pdfEscape(String(value))}) Tj ET`
      );
      this.y -= size * 1.5;
      return this;
    }

    /** bytes = Uint8Array of a JPEG */
    image(bytes, maxW) {
      const size = jpegSize(bytes);
      if (!size) return this;
      const w = Math.min(maxW || PAGE_W - 2 * MARGIN, PAGE_W - 2 * MARGIN);
      const h = (w * size.h) / size.w;
      this.need(h + 10);
      const name = `Im${this.images.length + 1}`;
      this.images.push({ bytes, w: size.w, h: size.h, name });
      this.page.images.push(name);
      this.op(
        `q ${w.toFixed(2)} 0 0 ${h.toFixed(2)} ${MARGIN} ${(this.y - h).toFixed(2)} cm /${name} Do Q`
      );
      this.y -= h + 8;
      return this;
    }

    space(n = 6) {
      this.y -= n;
      return this;
    }

    // ---- serialise ------------------------------------------------------
    build() {
      const enc = new TextEncoder();
      const chunks = [];
      const offsets = [];
      let pos = 0;
      const push = (data) => {
        const bytes = typeof data === "string" ? enc.encode(data) : data;
        chunks.push(bytes);
        pos += bytes.length;
      };
      const obj = (n, body, stream) => {
        offsets[n] = pos;
        push(`${n} 0 obj\n${body}\n`);
        if (stream) {
          push("stream\n");
          push(stream);
          push("\nendstream\n");
        }
        push("endobj\n");
      };

      // object numbering: 1 catalog, 2 pages, 3 F1, 4 F2,
      // then per image 2 is not needed (single obj each), then page+content pairs
      const nImages = this.images.length;
      const imgStart = 5;
      const pageStart = imgStart + nImages;
      const pageIds = this.pages.map((_, i) => pageStart + i * 2);

      push("%PDF-1.4\n%\xC7\xEC\x8F\xA2\n");

      obj(1, `<< /Type /Catalog /Pages 2 0 R >>`);
      obj(
        2,
        `<< /Type /Pages /Kids [${pageIds.map((id) => `${id} 0 R`).join(" ")}] /Count ${this.pages.length} >>`
      );
      obj(3, `<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>`);
      obj(4, `<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>`);

      this.images.forEach((im, i) => {
        obj(
          imgStart + i,
          `<< /Type /XObject /Subtype /Image /Width ${im.w} /Height ${im.h} ` +
            `/ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${im.bytes.length} >>`,
          im.bytes
        );
      });

      const imgRef = {};
      this.images.forEach((im, i) => (imgRef[im.name] = imgStart + i));

      this.pages.forEach((page, i) => {
        const pid = pageStart + i * 2;
        const cid = pid + 1;
        const xo = page.images.length
          ? ` /XObject << ${page.images.map((n) => `/${n} ${imgRef[n]} 0 R`).join(" ")} >>`
          : "";
        obj(
          pid,
          `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${PAGE_W.toFixed(2)} ${PAGE_H.toFixed(2)}] ` +
            `/Resources << /Font << /F1 3 0 R /F2 4 0 R >>${xo} >> /Contents ${cid} 0 R >>`
        );
        const content = page.ops.join("\n");
        obj(cid, `<< /Length ${enc.encode(content).length} >>`, enc.encode(content));
      });

      const maxObj = pageStart + this.pages.length * 2 - 1;
      const xrefPos = pos;
      let xref = `xref\n0 ${maxObj + 1}\n0000000000 65535 f \n`;
      for (let n = 1; n <= maxObj; n++) {
        xref += `${String(offsets[n] || 0).padStart(10, "0")} 00000 n \n`;
      }
      push(xref);
      push(
        `trailer\n<< /Size ${maxObj + 1} /Root 1 0 R /Info << /Title (${pdfEscape(
          this.title
        )}) /Producer (FilmLens) >> >>\nstartxref\n${xrefPos}\n%%EOF\n`
      );

      return new Blob(chunks, { type: "application/pdf" });
    }
  }

  FL.Pdf = Pdf;
  FL.pdfHelpers = { jpegSize, latin1, textWidth, PAGE_W, PAGE_H, MARGIN };
})();
