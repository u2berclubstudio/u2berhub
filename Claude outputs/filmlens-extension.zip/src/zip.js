/* FilmLens — minimal, dependency-free ZIP writer (STORE method, no compression).
   JPEGs don't compress anyway, and JSON/CSV inside a store-zip still opens fine
   in Finder, Windows Explorer, and any unzip tool. ~zero dependencies by design. */
(function () {
  "use strict";

  const FL = (window.__FILMLENS = window.__FILMLENS || {});

  // ---- CRC32 -------------------------------------------------------------
  const CRC_TABLE = (function () {
    const t = new Uint32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      t[n] = c >>> 0;
    }
    return t;
  })();

  function crc32(bytes) {
    let c = 0xffffffff;
    for (let i = 0; i < bytes.length; i++) {
      c = CRC_TABLE[(c ^ bytes[i]) & 0xff] ^ (c >>> 8);
    }
    return (c ^ 0xffffffff) >>> 0;
  }

  const enc = new TextEncoder();

  function dosTime(d) {
    return (
      ((d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() / 2)) &
      0xffff
    );
  }
  function dosDate(d) {
    return (
      (((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate()) &
      0xffff
    );
  }

  /**
   * files: [{ name: "path/in/zip.txt", data: Uint8Array | string }]
   * returns: Blob
   */
  function buildZip(files) {
    const now = new Date();
    const time = dosTime(now);
    const date = dosDate(now);

    const entries = files.map((f) => {
      const data = typeof f.data === "string" ? enc.encode(f.data) : f.data;
      return {
        nameBytes: enc.encode(f.name),
        data,
        crc: crc32(data),
      };
    });

    const chunks = [];
    let offset = 0;
    const central = [];

    for (const e of entries) {
      const header = new Uint8Array(30 + e.nameBytes.length);
      const dv = new DataView(header.buffer);
      dv.setUint32(0, 0x04034b50, true); // local file header sig
      dv.setUint16(4, 20, true); // version needed
      dv.setUint16(6, 0, true); // flags
      dv.setUint16(8, 0, true); // method = store
      dv.setUint16(10, time, true);
      dv.setUint16(12, date, true);
      dv.setUint32(14, e.crc, true);
      dv.setUint32(18, e.data.length, true);
      dv.setUint32(22, e.data.length, true);
      dv.setUint16(26, e.nameBytes.length, true);
      dv.setUint16(28, 0, true); // extra len
      header.set(e.nameBytes, 30);

      chunks.push(header, e.data);

      const cd = new Uint8Array(46 + e.nameBytes.length);
      const cdv = new DataView(cd.buffer);
      cdv.setUint32(0, 0x02014b50, true); // central dir sig
      cdv.setUint16(4, 20, true); // version made by
      cdv.setUint16(6, 20, true); // version needed
      cdv.setUint16(8, 0, true);
      cdv.setUint16(10, 0, true);
      cdv.setUint16(12, time, true);
      cdv.setUint16(14, date, true);
      cdv.setUint32(16, e.crc, true);
      cdv.setUint32(20, e.data.length, true);
      cdv.setUint32(24, e.data.length, true);
      cdv.setUint16(28, e.nameBytes.length, true);
      cdv.setUint16(30, 0, true); // extra
      cdv.setUint16(32, 0, true); // comment
      cdv.setUint16(34, 0, true); // disk
      cdv.setUint16(36, 0, true); // int attrs
      cdv.setUint32(38, 0, true); // ext attrs
      cdv.setUint32(42, offset, true);
      cd.set(e.nameBytes, 46);
      central.push(cd);

      offset += header.length + e.data.length;
    }

    const cdStart = offset;
    let cdSize = 0;
    for (const cd of central) {
      chunks.push(cd);
      cdSize += cd.length;
    }

    const eocd = new Uint8Array(22);
    const edv = new DataView(eocd.buffer);
    edv.setUint32(0, 0x06054b50, true);
    edv.setUint16(4, 0, true);
    edv.setUint16(6, 0, true);
    edv.setUint16(8, entries.length, true);
    edv.setUint16(10, entries.length, true);
    edv.setUint32(12, cdSize, true);
    edv.setUint32(16, cdStart, true);
    edv.setUint16(20, 0, true);
    chunks.push(eocd);

    return new Blob(chunks, { type: "application/zip" });
  }

  /** "data:image/jpeg;base64,...." -> Uint8Array */
  function dataUrlToBytes(dataUrl) {
    const base64 = dataUrl.slice(dataUrl.indexOf(",") + 1);
    const bin = atob(base64);
    const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }

  FL.zip = { buildZip, dataUrlToBytes, crc32 };
})();
