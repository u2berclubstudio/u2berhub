/* FilmLens — composition technique taxonomy.
   Atul's own 74-technique list, grouped, searchable, one tap each.

   `auto` marks the techniques the maths engine can *suggest* (never decide) —
   those get surfaced at the top of the palette for the current frame. The rest
   need a human, and that is exactly why the palette exists. */
(function () {
  "use strict";

  const FL = (window.__FILMLENS = window.__FILMLENS || {});

  const GROUPS = [
    "Grid & placement",
    "Lines & shapes",
    "Symmetry & balance",
    "Depth",
    "Subject placement",
    "Movement",
    "Contrast",
    "Lighting",
    "Psychological",
    "Film grammar",
  ];

  // [id, label, groupIndex, autoSuggestable]
  const RAW = [
    ["rule-of-thirds", "Rule of Thirds", 0, 1],
    ["golden-ratio", "Golden Ratio / Golden Mean", 0, 1],
    ["golden-spiral", "Golden Spiral / Fibonacci", 0, 0],
    ["golden-triangle", "Golden Triangle", 0, 0],
    ["dynamic-symmetry", "Dynamic Symmetry", 0, 0],
    ["center-composition", "Center Composition", 0, 1],
    ["dead-center", "Dead Center / Bullseye", 0, 1],

    ["leading-lines", "Leading Lines", 1, 1],
    ["diagonals", "Diagonals", 1, 1],
    ["vertical-lines", "Vertical Lines", 1, 1],
    ["horizontal-lines", "Horizontal Lines", 1, 1],
    ["curved-lines", "Curved Lines", 1, 0],
    ["s-curve", "S-Curve Composition", 1, 0],
    ["triangles", "Triangles", 1, 0],
    ["geometric", "Geometric Composition", 1, 0],
    ["frame-in-frame", "Frame Within a Frame", 1, 0],

    ["symmetrical", "Symmetrical Composition", 2, 1],
    ["asymmetrical-balance", "Asymmetrical Balance", 2, 1],
    ["radial-symmetry", "Radial Symmetry", 2, 0],
    ["pattern-repetition", "Pattern & Repetition", 2, 1],
    ["breaking-pattern", "Breaking the Pattern", 2, 0],

    ["fg-mg-bg", "Foreground–Midground–Background", 3, 1],
    ["layering", "Layering", 3, 1],
    ["overlap", "Overlap / Occlusion", 3, 0],
    ["negative-space", "Negative Space", 3, 1],
    ["deep-focus", "Deep Focus", 3, 1],
    ["shallow-depth", "Shallow Depth", 3, 1],
    ["forced-perspective", "Forced Perspective", 3, 0],
    ["vanishing-point", "Vanishing Point", 3, 1],

    ["look-room", "Look Room / Lead Room", 4, 0],
    ["headroom", "Headroom", 4, 0],
    ["nose-room", "Nose Room", 4, 0],
    ["off-center", "Off-Center Composition", 4, 1],
    ["edge-composition", "Edge Composition", 4, 1],
    ["corner-composition", "Corner Composition", 4, 1],
    ["two-shot", "Two-Shot Balance", 4, 0],
    ["group-composition", "Three-Shot / Group", 4, 0],

    ["movement-into", "Movement Into Frame", 5, 0],
    ["movement-out", "Movement Out of Frame", 5, 0],
    ["directional", "Directional Composition", 5, 0],
    ["diagonal-movement", "Diagonal Movement", 5, 0],
    ["static-framing", "Static Composition", 5, 1],
    ["dynamic-framing", "Dynamic / Unstable Framing", 5, 1],

    ["figure-ground", "Figure–Ground Separation", 6, 1],
    ["tonal-contrast", "Tonal Contrast", 6, 1],
    ["color-contrast", "Color Contrast", 6, 1],
    ["size-contrast", "Size Contrast", 6, 0],
    ["shape-contrast", "Shape Contrast", 6, 0],
    ["texture-contrast", "Texture Contrast", 6, 1],
    ["light-shadow", "Light–Shadow Composition", 6, 1],
    ["silhouette", "Silhouette", 6, 1],

    ["chiaroscuro", "Chiaroscuro", 7, 1],
    ["rembrandt", "Rembrandt Lighting", 7, 0],
    ["backlight", "Backlight / Rim Light", 7, 0],
    ["practical-light", "Practical-Light Composition", 7, 0],
    ["shadow-composition", "Shadow Composition", 7, 0],
    ["light-pool", "Light Pool", 7, 1],

    ["isolation", "Isolation", 8, 1],
    ["confinement", "Confinement", 8, 0],
    ["power-composition", "Power Composition", 8, 0],
    ["negative-space-isolation", "Negative-Space Isolation", 8, 1],
    ["crowding", "Crowding", 8, 1],
    ["visual-hierarchy", "Visual Hierarchy", 8, 0],
    ["eye-trace", "Eye Trace", 8, 0],
    ["psychological-framing", "Psychological Framing", 8, 0],

    ["180-rule", "180° Rule / Screen Direction", 9, 0],
    ["eyeline-match", "Eyeline Matching", 9, 0],
    ["match-on-action", "Match on Action", 9, 0],
    ["shot-reverse-shot", "Shot–Reverse-Shot", 9, 0],
    ["cheat-composition", "Cheat Composition", 9, 0],
    ["motivated-framing", "Motivated Framing", 9, 0],
    ["visual-motif", "Visual Motif", 9, 0],
    ["production-design", "Composition Through Production Design", 9, 0],
    ["blocking", "Blocking Composition", 9, 0],
    ["camera-movement", "Camera Movement Composition", 9, 1],
  ];

  const TAGS = RAW.map(([id, label, g, auto]) => ({
    id,
    label,
    group: GROUPS[g],
    groupIndex: g,
    auto: !!auto,
  }));

  const BY_ID = {};
  for (const t of TAGS) BY_ID[t.id] = t;

  function search(q) {
    const s = (q || "").trim().toLowerCase();
    if (!s) return TAGS;
    return TAGS.filter(
      (t) => t.label.toLowerCase().includes(s) || t.id.includes(s) || t.group.toLowerCase().includes(s)
    );
  }

  FL.Tags = { GROUPS, TAGS, BY_ID, search, label: (id) => (BY_ID[id] ? BY_ID[id].label : id) };
})();
