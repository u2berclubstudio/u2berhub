/* FilmLens — local shot-change detector.
   Pure maths on downscaled frames. No network, no AI, no API key.

   How it works:
     1. Every ~80ms we draw the <video> onto a tiny 48x27 canvas.
     2. We build a 64-bin RGB histogram + a raw pixel signature of that frame.
     3. We compare it with the previous frame -> a "difference score" (0..1).
     4. A hard cut = a score that is BOTH above an absolute floor AND several
        times bigger than the recent rolling average (so fast camera movement
        or an action scene doesn't get mistaken for a cut).
     5. Fades to/from black are tracked separately — they are the strongest
        scene-boundary signal a film gives you.
*/
(function () {
  "use strict";

  const FL = (window.__FILMLENS = window.__FILMLENS || {});

  const W = 48;
  const H = 27;
  const BINS = 64; // 4 levels per channel

  class ShotDetector {
    constructor(opts = {}) {
      this.canvas = document.createElement("canvas");
      this.canvas.width = W;
      this.canvas.height = H;
      this.ctx = this.canvas.getContext("2d", { willReadFrequently: true });

      this.sensitivity = opts.sensitivity ?? 0.5; // 0..1 slider
      this.minShot = opts.minShot ?? 0.30; // seconds
      this.ratio = opts.ratio ?? 3.0; // score must beat ratio * rolling avg

      this.reset();
    }

    reset() {
      this.prevHist = null;
      this.prevPix = null;
      this.ema = 0.02;
      this.lastCutTime = -999;
      this.inBlack = false;
      this.blackSince = null;
      this.blackFrames = 0;
      this.flatFrames = 0;
      this.lastSampleTime = -1;
      this.pendingFade = false;
    }

    /** absolute floor for "this is a cut", derived from the sensitivity slider */
    get floor() {
      // sensitivity 0 (strict) -> 0.46 ; 1 (loose) -> 0.16
      return 0.46 - 0.30 * this.sensitivity;
    }

    /**
     * Sample the current video frame.
     * Returns null if nothing usable, else a result object.
     */
    sample(video, t) {
      if (!video || video.readyState < 2) return null;
      if (this.lastSampleTime >= 0 && Math.abs(t - this.lastSampleTime) > 1.5) {
        // user seeked — throw away history so we don't log a phantom cut
        this.prevHist = null;
        this.prevPix = null;
      }
      this.lastSampleTime = t;

      try {
        this.ctx.drawImage(video, 0, 0, W, H);
      } catch (err) {
        return { error: "draw_failed" };
      }

      let px;
      try {
        px = this.ctx.getImageData(0, 0, W, H).data;
      } catch (err) {
        // tainted canvas — DRM / cross-origin protected media
        return { error: "tainted" };
      }

      const hist = new Float32Array(BINS);
      const pix = new Uint8Array(W * H * 3);
      let rSum = 0,
        gSum = 0,
        bSum = 0,
        lumSum = 0,
        lumSq = 0;

      const n = W * H;
      for (let i = 0, j = 0, k = 0; i < px.length; i += 4, j += 3, k++) {
        const r = px[i],
          g = px[i + 1],
          b = px[i + 2];
        pix[j] = r;
        pix[j + 1] = g;
        pix[j + 2] = b;
        hist[(r >> 6) * 16 + (g >> 6) * 4 + (b >> 6)] += 1;
        rSum += r;
        gSum += g;
        bSum += b;
        const lum = 0.2126 * r + 0.7152 * g + 0.0722 * b;
        lumSum += lum;
        lumSq += lum * lum;
      }
      for (let i = 0; i < BINS; i++) hist[i] /= n;

      const meanLum = lumSum / n / 255;
      const variance = Math.max(0, lumSq / n - (lumSum / n) * (lumSum / n)) / (255 * 255);
      const avg = {
        r: Math.round(rSum / n),
        g: Math.round(gSum / n),
        b: Math.round(bSum / n),
      };
      const maxc = Math.max(avg.r, avg.g, avg.b);
      const minc = Math.min(avg.r, avg.g, avg.b);
      const saturation = maxc === 0 ? 0 : (maxc - minc) / maxc;

      const result = {
        t,
        brightness: +meanLum.toFixed(4),
        saturation: +saturation.toFixed(3),
        variance: +variance.toFixed(5),
        color: avg,
        score: 0,
        cut: false,
        transition: null,
      };

      // ---- black / fade tracking -----------------------------------------
      const isBlack = meanLum < 0.045 && variance < 0.004;
      if (isBlack) {
        this.blackFrames++;
        if (!this.inBlack) {
          this.inBlack = true;
          this.blackSince = t;
        }
      } else if (this.inBlack) {
        const held = t - this.blackSince;
        this.inBlack = false;
        if (held > 0.15) {
          // came out of black -> treat as a fade transition (scene boundary)
          result.transition = "fade";
          result.cut = true;
          this.lastCutTime = t;
          this.prevHist = hist;
          this.prevPix = pix;
          return result;
        }
      }

      // flat black for a long stretch while playing = probably DRM-protected
      if (meanLum < 0.005 && variance < 0.0005) this.flatFrames++;
      else this.flatFrames = 0;
      result.drmSuspect = this.flatFrames > 50; // ~4s of pure black

      // ---- difference score ----------------------------------------------
      if (this.prevHist) {
        let histDiff = 0;
        for (let i = 0; i < BINS; i++) {
          histDiff += Math.abs(hist[i] - this.prevHist[i]);
        }
        histDiff *= 0.5; // 0..1

        let pixDiff = 0;
        for (let i = 0; i < pix.length; i++) {
          pixDiff += Math.abs(pix[i] - this.prevPix[i]);
        }
        pixDiff = pixDiff / pix.length / 255; // 0..1

        const score = 0.65 * histDiff + 0.35 * pixDiff;
        result.score = +score.toFixed(4);

        const beatsFloor = score > this.floor;
        const beatsTrend = score > this.ratio * this.ema;
        const spacedOut = t - this.lastCutTime > this.minShot;

        if (beatsFloor && beatsTrend && spacedOut) {
          result.cut = true;
          result.transition = "cut";
          this.lastCutTime = t;
          this.ema = Math.max(this.ema, score * 0.35); // don't let one cut poison the trend
        } else {
          this.ema = 0.9 * this.ema + 0.1 * score;
        }
      }

      this.prevHist = hist;
      this.prevPix = pix;
      return result;
    }
  }

  FL.ShotDetector = ShotDetector;
  FL.FRAME_W = W;
  FL.FRAME_H = H;
})();
