/* FilmLens — composition engine.
   Three jobs, all inside the browser, no AI, no network:
     1. analyze(video)  — measure one frame: where the visual weight sits,
        symmetry, dominant line angles, vanishing point, negative space,
        contrast, light distribution. Returns numbers + suggested tags.
     2. drawGuides()    — draw composition overlays on the real picture area.
     3. Motion / Fps    — how the camera moved and what frame rate it ran at.

   Everything here reports *evidence*, never verdicts. The maths knows where
   the frame is heavy; it does not know what the subject is. */
(function () {
  "use strict";

  const FL = (window.__FILMLENS = window.__FILMLENS || {});

  // ======================================================== frame analysis ==
  const AW = 160; // analysis width

  let aCanvas = null, aCtx = null;

  function ensureCanvas(w, h) {
    if (!aCanvas) {
      aCanvas = document.createElement("canvas");
      aCtx = aCanvas.getContext("2d", { willReadFrequently: true });
    }
    if (aCanvas.width !== w || aCanvas.height !== h) {
      aCanvas.width = w;
      aCanvas.height = h;
    }
    return aCtx;
  }

  /**
   * Find baked-in black bars so the guides land on the actual picture.
   *
   * The trap here is a genuinely dark frame — a night scene with one lit
   * window would otherwise get "cropped" down to the lit part, throwing every
   * guide off. Two rules keep that from happening: a real bar ENDS before a
   * quarter of the axis is gone (if we run into the cap while still in the
   * dark, it was never a bar), and a real letterbox leaves most of the axis
   * intact.
   */
  function findPictureBox(lum, w, h) {
    const rowMean = new Float32Array(h), rowMax = new Float32Array(h);
    const colMean = new Float32Array(w), colMax = new Float32Array(w);
    for (let y = 0; y < h; y++) {
      let s = 0, mx = 0;
      for (let x = 0; x < w; x++) {
        const v = lum[y * w + x];
        s += v;
        if (v > mx) mx = v;
      }
      rowMean[y] = s / w;
      rowMax[y] = mx;
    }
    for (let x = 0; x < w; x++) {
      let s = 0, mx = 0;
      for (let y = 0; y < h; y++) {
        const v = lum[y * w + x];
        s += v;
        if (v > mx) mx = v;
      }
      colMean[x] = s / h;
      colMax[x] = mx;
    }

    const DARK = 0.03, DARK_MAX = 0.1;
    const darkRow = (y) => rowMean[y] < DARK && rowMax[y] < DARK_MAX;
    const darkCol = (x) => colMean[x] < DARK && colMax[x] < DARK_MAX;

    const capY = h * 0.24, capX = w * 0.24;
    let top = 0, bottom = h - 1, left = 0, right = w - 1;
    while (top < capY && darkRow(top)) top++;
    while (h - 1 - bottom < capY && darkRow(bottom)) bottom--;
    while (left < capX && darkCol(left)) left++;
    while (w - 1 - right < capX && darkCol(right)) right--;

    // hit the cap while still in darkness → not a letterbox, just a dark frame
    if (darkRow(top) || darkRow(bottom) || (bottom - top + 1) / h < 0.52) {
      top = 0;
      bottom = h - 1;
    }
    if (darkCol(left) || darkCol(right) || (right - left + 1) / w < 0.52) {
      left = 0;
      right = w - 1;
    }

    // ignore a 1px nibble
    if (top < 2) top = 0;
    if (left < 2) left = 0;
    if (bottom > h - 3) bottom = h - 1;
    if (right > w - 3) right = w - 1;
    return { x0: left, y0: top, x1: right, y1: bottom };
  }

  function hueOf(r, g, b) {
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b);
    if (mx === mn) return -1;
    const d = mx - mn;
    let hu;
    if (mx === r) hu = ((g - b) / d) % 6;
    else if (mx === g) hu = (b - r) / d + 2;
    else hu = (r - g) / d + 4;
    hu *= 60;
    return hu < 0 ? hu + 360 : hu;
  }

  /** Hough transform over the strongest edges. Returns top lines. */
  function houghLines(mag, w, h, thresh) {
    const ANG = 90; // 2-degree steps
    const diag = Math.ceil(Math.sqrt(w * w + h * h));
    const RHO = diag; // 1px steps, offset by diag/2
    const acc = new Float32Array(ANG * RHO);
    const sin = new Float32Array(ANG), cos = new Float32Array(ANG);
    for (let a = 0; a < ANG; a++) {
      const th = (a * 2 * Math.PI) / 180;
      sin[a] = Math.sin(th);
      cos[a] = Math.cos(th);
    }
    const cx = w / 2, cy = h / 2;
    for (let y = 1; y < h - 1; y++) {
      for (let x = 1; x < w - 1; x++) {
        const m = mag[y * w + x];
        if (m < thresh) continue;
        for (let a = 0; a < ANG; a++) {
          const rho = (x - cx) * cos[a] + (y - cy) * sin[a];
          const ri = Math.round(rho + RHO / 2);
          if (ri >= 0 && ri < RHO) acc[a * RHO + ri] += m;
        }
      }
    }
    const peaks = [];
    for (let a = 0; a < ANG; a++) {
      for (let ri = 0; ri < RHO; ri++) {
        const v = acc[a * RHO + ri];
        if (v <= 0) continue;
        peaks.push({ a, ri, v });
      }
    }
    peaks.sort((p, q) => q.v - p.v);

    const picked = [];
    for (const p of peaks) {
      if (picked.length >= 4) break;
      const clash = picked.some(
        (q) => Math.abs(q.a - p.a) < 5 && Math.abs(q.ri - p.ri) < 10
      );
      if (clash) continue;
      const theta = (p.a * 2 * Math.PI) / 180;
      const rho = p.ri - RHO / 2;
      // inclination from horizontal, in degrees, range (-90, 90]
      let inc = p.a * 2 - 90;
      if (inc <= -90) inc += 180;
      picked.push({
        theta,
        rho,
        strength: +(p.v / (peaks[0].v || 1)).toFixed(3),
        inclination: inc,
        // unit-frame line: a point + direction, for drawing
        px: (cx + rho * Math.cos(theta)) / w,
        py: (cy + rho * Math.sin(theta)) / h,
        dx: -Math.sin(theta),
        dy: Math.cos(theta),
      });
    }
    return picked;
  }

  function lineIntersect(l1, l2, w, h) {
    // convert to ax+by=c in pixel space
    const a1 = Math.cos(l1.theta), b1 = Math.sin(l1.theta), c1 = l1.rho;
    const a2 = Math.cos(l2.theta), b2 = Math.sin(l2.theta), c2 = l2.rho;
    const det = a1 * b2 - a2 * b1;
    if (Math.abs(det) < 1e-6) return null;
    const x = (c1 * b2 - c2 * b1) / det + w / 2;
    const y = (a1 * c2 - a2 * c1) / det + h / 2;
    return { x, y };
  }

  /** the classic compositional anchor points, in unit-frame coordinates */
  const ANCHORS = (() => {
    const a = [];
    for (const ax of [1 / 3, 2 / 3]) for (const ay of [1 / 3, 2 / 3]) a.push({ kind: "third", ax, ay });
    for (const ax of [0.382, 0.618]) for (const ay of [0.382, 0.618]) a.push({ kind: "phi", ax, ay });
    a.push({ kind: "center", ax: 0.5, ay: 0.5 });
    return a;
  })();

  function anchorFit(x, y) {
    let best = null;
    const byKind = {};
    for (const a of ANCHORS) {
      const d = Math.hypot(a.ax - x, a.ay - y);
      if (byKind[a.kind] === undefined || d < byKind[a.kind]) byKind[a.kind] = d;
      if (!best || d < best.d) best = { d, kind: a.kind, ax: a.ax, ay: a.ay };
    }
    return {
      nearest: { kind: best.kind, x: best.ax, y: best.ay, distance: +best.d.toFixed(3) },
      distances: {
        third: +byKind.third.toFixed(3),
        phi: +byKind.phi.toFixed(3),
        center: +byKind.center.toFixed(3),
      },
    };
  }

  function analyze(video) {
    if (!video || video.readyState < 2) return null;
    const vw = video.videoWidth || 16, vh = video.videoHeight || 9;
    const h = Math.max(24, Math.round((AW * vh) / vw));
    const ctx = ensureCanvas(AW, h);
    try {
      ctx.drawImage(video, 0, 0, AW, h);
    } catch (e) {
      return { error: "draw_failed" };
    }
    let px;
    try {
      px = ctx.getImageData(0, 0, AW, h).data;
    } catch (e) {
      return { error: "tainted" };
    }

    // luminance over the whole frame, then crop to the picture box
    const fullLum = new Float32Array(AW * h);
    for (let i = 0, k = 0; i < px.length; i += 4, k++) {
      fullLum[k] = (0.2126 * px[i] + 0.7152 * px[i + 1] + 0.0722 * px[i + 2]) / 255;
    }
    const box = findPictureBox(fullLum, AW, h);
    const W = box.x1 - box.x0 + 1;
    const H = box.y1 - box.y0 + 1;
    if (W < 16 || H < 12) return { error: "too_small" };

    const lum = new Float32Array(W * H);
    const rgb = new Float32Array(W * H * 3);
    for (let y = 0; y < H; y++) {
      for (let x = 0; x < W; x++) {
        const src = (y + box.y0) * AW + (x + box.x0);
        lum[y * W + x] = fullLum[src];
        const s4 = src * 4;
        const d3 = (y * W + x) * 3;
        rgb[d3] = px[s4];
        rgb[d3 + 1] = px[s4 + 1];
        rgb[d3 + 2] = px[s4 + 2];
      }
    }

    // ---- Sobel edges ----
    const mag = new Float32Array(W * H);
    let magSum = 0, magSq = 0, magMax = 0;
    for (let y = 1; y < H - 1; y++) {
      for (let x = 1; x < W - 1; x++) {
        const i = y * W + x;
        const gx =
          -lum[i - W - 1] - 2 * lum[i - 1] - lum[i + W - 1] +
          lum[i - W + 1] + 2 * lum[i + 1] + lum[i + W + 1];
        const gy =
          -lum[i - W - 1] - 2 * lum[i - W] - lum[i - W + 1] +
          lum[i + W - 1] + 2 * lum[i + W] + lum[i + W + 1];
        const m = Math.sqrt(gx * gx + gy * gy);
        mag[i] = m;
        magSum += m;
        magSq += m * m;
        if (m > magMax) magMax = m;
      }
    }
    const nInner = Math.max(1, (W - 2) * (H - 2));
    const magMean = magSum / nInner;
    const magStd = Math.sqrt(Math.max(0, magSq / nInner - magMean * magMean));

    // ---- luminance stats ----
    let lSum = 0, lSq = 0, dark = 0, bright = 0;
    for (let i = 0; i < lum.length; i++) {
      lSum += lum[i];
      lSq += lum[i] * lum[i];
      if (lum[i] < 0.15) dark++;
      if (lum[i] > 0.8) bright++;
    }
    const lMean = lSum / lum.length;
    const lStd = Math.sqrt(Math.max(0, lSq / lum.length - lMean * lMean));
    const darkRatio = dark / lum.length;
    const brightRatio = bright / lum.length;

    // ---- visual weight centroid (edge energy + contrast deviation) ----
    let wx = 0, wy = 0, wsum = 0;
    for (let y = 0; y < H; y++) {
      for (let x = 0; x < W; x++) {
        const i = y * W + x;
        const weight = mag[i] / (magMax || 1) + Math.abs(lum[i] - lMean) * 0.6;
        wx += x * weight;
        wy += y * weight;
        wsum += weight;
      }
    }
    const cxF = wsum ? wx / wsum / W : 0.5;
    const cyF = wsum ? wy / wsum / H : 0.5;

    // ---- distance to the classic anchors ----
    const fit = anchorFit(cxF, cyF);

    // ---- symmetry (mirror match) ----
    let symDiff = 0, symN = 0;
    const halfW = Math.floor(W / 2);
    for (let y = 0; y < H; y++) {
      for (let x = 0; x < halfW; x++) {
        symDiff += Math.abs(lum[y * W + x] - lum[y * W + (W - 1 - x)]);
        symN++;
      }
    }
    const symmetry = symN ? Math.max(0, 100 * (1 - (symDiff / symN) / 0.35)) : 0;

    // left / right and top / bottom weight balance
    let lW = 0, rW = 0, tW = 0, bW = 0;
    for (let y = 0; y < H; y++) {
      for (let x = 0; x < W; x++) {
        const e = mag[y * W + x];
        if (x < W / 2) lW += e; else rW += e;
        if (y < H / 2) tW += e; else bW += e;
      }
    }
    const lrBalance = lW + rW ? (rW - lW) / (lW + rW) : 0;
    const tbBalance = tW + bW ? (bW - tW) / (tW + bW) : 0;

    // ---- negative space: cells with almost no detail ----
    const CELL = 8;
    const cols = Math.ceil(W / CELL), rows = Math.ceil(H / CELL);
    let emptyCells = 0, totalCells = 0;
    const cellEnergy = new Float32Array(cols * rows);
    for (let cy2 = 0; cy2 < rows; cy2++) {
      for (let cx2 = 0; cx2 < cols; cx2++) {
        let e = 0, n = 0;
        for (let y = cy2 * CELL; y < Math.min(H, (cy2 + 1) * CELL); y++) {
          for (let x = cx2 * CELL; x < Math.min(W, (cx2 + 1) * CELL); x++) {
            e += mag[y * W + x];
            n++;
          }
        }
        const avg = n ? e / n : 0;
        cellEnergy[cy2 * cols + cx2] = avg;
        totalCells++;
        if (avg < magMean * 0.45) emptyCells++;
      }
    }
    const negativeSpace = totalCells ? emptyCells / totalCells : 0;

    // ---- sharpness distribution: centre vs edges, and by depth band ----
    const bandSharp = [0, 0, 0];
    const bandN = [0, 0, 0];
    let centreSharp = 0, centreN = 0, outerSharp = 0, outerN = 0;
    for (let y = 0; y < H; y++) {
      const band = y < H / 3 ? 0 : y < (2 * H) / 3 ? 1 : 2;
      for (let x = 0; x < W; x++) {
        const m = mag[y * W + x];
        bandSharp[band] += m;
        bandN[band]++;
        const inCentre = x > W * 0.28 && x < W * 0.72 && y > H * 0.2 && y < H * 0.85;
        if (inCentre) { centreSharp += m; centreN++; } else { outerSharp += m; outerN++; }
      }
    }
    const centreAvg = centreN ? centreSharp / centreN : 0;
    const outerAvg = outerN ? outerSharp / outerN : 0;
    const focusRatio = outerAvg ? +(centreAvg / outerAvg).toFixed(2) : null;
    const bands = bandSharp.map((s, i) => +(bandN[i] ? s / bandN[i] / (magMean || 1) : 0).toFixed(2));

    // ---- figure / ground: weight region vs the rest ----
    let inLum = 0, inN = 0, outLum = 0, outN = 0;
    const rx = W * 0.18, ry = H * 0.22;
    for (let y = 0; y < H; y++) {
      for (let x = 0; x < W; x++) {
        const inside = Math.abs(x - cxF * W) < rx && Math.abs(y - cyF * H) < ry;
        if (inside) { inLum += lum[y * W + x]; inN++; } else { outLum += lum[y * W + x]; outN++; }
      }
    }
    const figureGround = inN && outN ? +Math.abs(inLum / inN - outLum / outN).toFixed(3) : 0;

    // ---- texture contrast: variance spread across cells ----
    let ceMean = 0;
    for (let i = 0; i < cellEnergy.length; i++) ceMean += cellEnergy[i];
    ceMean /= Math.max(1, cellEnergy.length);
    let ceVar = 0;
    for (let i = 0; i < cellEnergy.length; i++) ceVar += (cellEnergy[i] - ceMean) ** 2;
    const textureContrast = +Math.sqrt(ceVar / Math.max(1, cellEnergy.length)) .toFixed(3);

    // ---- pattern / repetition: horizontal autocorrelation ----
    let patternScore = 0;
    {
      const mid = Math.floor(H / 2);
      const row = [];
      for (let x = 0; x < W; x++) row.push(mag[mid * W + x]);
      let bestCorr = 0;
      for (let lag = 4; lag < Math.floor(W / 3); lag++) {
        let num = 0, d1 = 0, d2 = 0;
        for (let x = 0; x + lag < W; x++) {
          num += row[x] * row[x + lag];
          d1 += row[x] * row[x];
          d2 += row[x + lag] * row[x + lag];
        }
        const c = d1 && d2 ? num / Math.sqrt(d1 * d2) : 0;
        if (c > bestCorr) bestCorr = c;
      }
      patternScore = +bestCorr.toFixed(3);
    }

    // ---- brightest region (light pool) ----
    let bx = 0, by = 0, bsum = 0;
    for (let y = 0; y < H; y++) {
      for (let x = 0; x < W; x++) {
        const v = lum[y * W + x];
        if (v > 0.75) { bx += x; by += y; bsum++; }
      }
    }
    const lightPool = bsum > 4
      ? { x: +(bx / bsum / W).toFixed(3), y: +(by / bsum / H).toFixed(3), area: +(bsum / lum.length).toFixed(3) }
      : null;

    // ---- dominant hues ----
    const hueBins = new Float32Array(12);
    for (let i = 0; i < W * H; i++) {
      const r = rgb[i * 3], g = rgb[i * 3 + 1], b = rgb[i * 3 + 2];
      const hu = hueOf(r, g, b);
      if (hu < 0) continue;
      const mx = Math.max(r, g, b), mn = Math.min(r, g, b);
      const sat = mx ? (mx - mn) / mx : 0;
      if (sat < 0.18) continue;
      hueBins[Math.floor(hu / 30) % 12] += sat;
    }
    const hueRank = Array.from(hueBins)
      .map((v, i) => ({ hue: i * 30 + 15, v }))
      .sort((a, b) => b.v - a.v);
    const hueTotal = hueRank.reduce((a, x) => a + x.v, 0) || 1;
    const hues = hueRank.slice(0, 2).filter((x) => x.v / hueTotal > 0.12);
    let hueSpread = null;
    if (hues.length === 2) {
      let d = Math.abs(hues[0].hue - hues[1].hue);
      hueSpread = d > 180 ? 360 - d : d;
    }

    // ---- lines & vanishing point ----
    // A frame full of strong edges (stripes, railings, a crowd) pushes
    // mean+1.6σ above the actual maximum, and then nothing passes at all —
    // so the threshold is also capped relative to the strongest edge.
    const lineThresh = Math.max(
      magMean * 1.1,
      Math.min(magMean + 1.6 * magStd, magMax * 0.5)
    );
    const lines = houghLines(mag, W, H, lineThresh);
    let horiz = 0, vert = 0, diag = 0;
    for (const l of lines) {
      const a = Math.abs(l.inclination);
      if (a < 12) horiz++;
      else if (a > 78) vert++;
      else diag++;
    }
    let tilt = null;
    const nearHoriz = lines.filter((l) => Math.abs(l.inclination) < 25).sort((a, b) => b.strength - a.strength)[0];
    if (nearHoriz) tilt = +nearHoriz.inclination.toFixed(1);

    let vanishing = null;
    if (lines.length >= 2) {
      const pts = [];
      for (let i = 0; i < lines.length; i++) {
        for (let j = i + 1; j < lines.length; j++) {
          if (Math.abs(lines[i].inclination - lines[j].inclination) < 15) continue;
          const p = lineIntersect(lines[i], lines[j], W, H);
          if (!p) continue;
          if (p.x > -W * 0.4 && p.x < W * 1.4 && p.y > -H * 0.4 && p.y < H * 1.4) pts.push(p);
        }
      }
      if (pts.length >= 2) {
        const xs = pts.map((p) => p.x).sort((a, b) => a - b);
        const ys = pts.map((p) => p.y).sort((a, b) => a - b);
        const mx = xs[Math.floor(xs.length / 2)];
        const my = ys[Math.floor(ys.length / 2)];
        const spread = Math.hypot(xs[xs.length - 1] - xs[0], ys[ys.length - 1] - ys[0]) / W;
        if (spread < 0.55) vanishing = { x: +(mx / W).toFixed(3), y: +(my / H).toFixed(3), lines: pts.length + 1 };
      }
    }

    const aspect = +(W / H).toFixed(2);
    const letterboxed = box.y0 > 1 || box.y1 < h - 2 || box.x0 > 1 || box.x1 < AW - 2;

    const m = {
      picture_box: {
        x: +(box.x0 / AW).toFixed(3),
        y: +(box.y0 / h).toFixed(3),
        w: +(W / AW).toFixed(3),
        h: +(H / h).toFixed(3),
      },
      aspect,
      letterboxed,
      weight: { x: +cxF.toFixed(3), y: +cyF.toFixed(3) },
      nearest: fit.nearest,
      distances: fit.distances,
      symmetry: +symmetry.toFixed(1),
      balance: { left_right: +lrBalance.toFixed(3), top_bottom: +tbBalance.toFixed(3) },
      negative_space: +negativeSpace.toFixed(3),
      brightness: +lMean.toFixed(3),
      tonal_contrast: +lStd.toFixed(3),
      dark_ratio: +darkRatio.toFixed(3),
      bright_ratio: +brightRatio.toFixed(3),
      detail_density: +(magMean / 255).toFixed(4),
      focus_ratio: focusRatio,
      depth_bands: bands,
      figure_ground: figureGround,
      texture_contrast: textureContrast,
      pattern_score: patternScore,
      light_pool: lightPool,
      hues: hues.map((x) => Math.round(x.hue)),
      hue_spread: hueSpread,
      lines: lines.map((l) => ({
        inclination: +l.inclination.toFixed(1),
        strength: l.strength,
        px: +l.px.toFixed(3), py: +l.py.toFixed(3),
        dx: +l.dx.toFixed(3), dy: +l.dy.toFixed(3),
      })),
      line_types: { horizontal: horiz, vertical: vert, diagonal: diag },
      tilt_deg: tilt,
      vanishing_point: vanishing,
    };

    m.suggested = suggest(m);
    m.hints = hints(m);
    return m;
  }

  // ---------------------------------------------------------- suggestions --
  function suggest(m) {
    const out = [];
    const add = (id) => { if (!out.includes(id)) out.push(id); };
    const d = m.distances;

    if (d.center < 0.03) add("dead-center");
    else if (d.center < 0.08) add("center-composition");
    if (d.third < 0.06 && d.third <= d.center) add("rule-of-thirds");
    if (d.phi < 0.05 && d.phi < d.third) add("golden-ratio");
    if (d.center > 0.18) add("off-center");
    if (m.weight.x < 0.15 || m.weight.x > 0.85 || m.weight.y < 0.15 || m.weight.y > 0.85) {
      add("edge-composition");
      if ((m.weight.x < 0.2 || m.weight.x > 0.8) && (m.weight.y < 0.2 || m.weight.y > 0.8)) add("corner-composition");
    }

    if (m.symmetry > 72) add("symmetrical");
    else if (m.symmetry < 48 && Math.abs(m.balance.left_right) < 0.12) add("asymmetrical-balance");

    if (m.line_types.diagonal >= 2) { add("diagonals"); add("leading-lines"); }
    else if (m.line_types.diagonal >= 1 && m.vanishing_point) add("leading-lines");
    if (m.line_types.vertical >= 2) add("vertical-lines");
    if (m.line_types.horizontal >= 2) add("horizontal-lines");
    if (m.vanishing_point) add("vanishing-point");
    if (m.tilt_deg !== null && Math.abs(m.tilt_deg) > 4) add("dynamic-framing");

    if (m.negative_space > 0.58) {
      add("negative-space");
      if (m.figure_ground > 0.12) { add("isolation"); add("negative-space-isolation"); }
    }
    if (m.negative_space < 0.22) add("crowding");

    if (m.focus_ratio !== null && m.focus_ratio > 1.55) add("shallow-depth");
    if (m.focus_ratio !== null && m.focus_ratio < 1.15 && m.detail_density > 0.04) add("deep-focus");
    const bs = m.depth_bands;
    if (bs && Math.max(...bs) - Math.min(...bs) > 0.7) { add("layering"); add("fg-mg-bg"); }

    if (m.figure_ground > 0.16) add("figure-ground");
    if (m.tonal_contrast > 0.22) add("tonal-contrast");
    if (m.texture_contrast > 12) add("texture-contrast");
    if (m.pattern_score > 0.75) add("pattern-repetition");
    if (m.hue_spread !== null && m.hue_spread > 130) add("color-contrast");

    if (m.dark_ratio > 0.42 && m.bright_ratio > 0.06) { add("chiaroscuro"); add("light-shadow"); }
    if (m.light_pool && m.light_pool.area < 0.14 && m.dark_ratio > 0.45) add("light-pool");
    if (m.dark_ratio > 0.4 && m.bright_ratio > 0.14 && m.detail_density < 0.05) add("silhouette");

    return out;
  }

  function hints(m) {
    const out = [];
    const d = m.distances;
    const pct = (v) => Math.round(v * 100) + "%";

    // Graded, not pass/fail. 4% from centre is centred for all practical
    // purposes — saying "kisi anchor par nahi" there was just wrong.
    if (d.center < 0.03) out.push("Dead centre framing");
    else if (d.third < 0.05) out.push(`Sits on the thirds (${pct(d.third)} off)`);
    else if (d.phi < 0.045) out.push(`On the golden-ratio point (${pct(d.phi)} off)`);
    else if (d.center < 0.08) out.push(`Near centre (${pct(d.center)} off)`);
    else if (d.third < 0.09) out.push(`Close to the thirds (${pct(d.third)} off)`);
    else out.push(`Not on any anchor — nearest is ${m.nearest.kind} (${pct(m.nearest.distance)})`);

    out.push(`Symmetry ${m.symmetry}%`);
    if (m.line_types.diagonal >= 2) out.push("Diagonal lead-in");
    if (m.vanishing_point) out.push(`Vanishing point ~${pct(m.vanishing_point.x)}×${pct(m.vanishing_point.y)}`);
    if (m.tilt_deg !== null && Math.abs(m.tilt_deg) > 3) out.push(`Camera tilted ${m.tilt_deg}°`);
    if (m.negative_space > 0.58) out.push(`Negative space ${pct(m.negative_space)}`);
    if (m.focus_ratio !== null && m.focus_ratio > 1.55) out.push("Background soft (shallow)");
    if (m.dark_ratio > 0.42 && m.bright_ratio > 0.06) out.push("Chiaroscuro / low-key");
    if (m.letterboxed) out.push(`Letterboxed ${m.aspect}:1`);
    return out;
  }

  // ============================================================== overlays ==
  const GUIDES = [
    { id: "thirds", label: "Rule of Thirds" },
    { id: "phi", label: "Golden Ratio (phi)" },
    { id: "spiral", label: "Golden Spiral" },
    { id: "triangle", label: "Golden Triangle" },
    { id: "dynsym", label: "Dynamic Symmetry" },
    { id: "center", label: "Center / Bullseye" },
    { id: "diagonals", label: "Diagonals" },
    { id: "symmetry", label: "Symmetry Axis" },
    { id: "radial", label: "Radial" },
    { id: "horizon", label: "Horizon + Eyeline" },
    { id: "lookroom", label: "Look Room / Headroom" },
    { id: "crop", label: "9:16 + 1:1 Crop" },
    { id: "quadrants", label: "Quadrants" },
    { id: "none", label: "Guides off" },
  ];

  let CLEAN = false; // set per drawGuides call — dims lines, hides labels

  function stroke(ctx, fn, color = "rgba(255,255,255,0.85)", width = 1) {
    ctx.save();
    ctx.lineWidth = width + 2;
    ctx.strokeStyle = "rgba(0,0,0,0.45)";
    fn();
    ctx.lineWidth = width;
    ctx.strokeStyle = color;
    fn();
    ctx.restore();
  }

  function line(ctx, x1, y1, x2, y2) {
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.stroke();
  }

  function dot(ctx, x, y, r, color) {
    ctx.save();
    ctx.beginPath();
    ctx.arc(x, y, r + 1.5, 0, Math.PI * 2);
    ctx.fillStyle = "rgba(0,0,0,0.5)";
    ctx.fill();
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fillStyle = color;
    ctx.fill();
    ctx.restore();
  }

  function label(ctx, text, x, y) {
    if (CLEAN) return;
    ctx.save();
    ctx.font = "600 11px -apple-system, Segoe UI, Roboto, sans-serif";
    const w = ctx.measureText(text).width + 10;
    ctx.fillStyle = "rgba(0,0,0,0.6)";
    ctx.fillRect(x, y - 12, w, 16);
    ctx.fillStyle = "#ffb454";
    ctx.fillText(text, x + 5, y);
    ctx.restore();
  }

  function drawSpiral(ctx, R, flip) {
    // golden spiral built from shrinking squares
    let x = R.x, y = R.y, w = R.w, h = R.h;
    let dir = flip % 4; // which corner it starts from
    ctx.beginPath();
    for (let i = 0; i < 9; i++) {
      const s = Math.min(w, h);
      let cx, cy, start;
      if (dir === 0) { cx = x + s; cy = y + s; start = Math.PI; }
      else if (dir === 1) { cx = x + w - s; cy = y + s; start = Math.PI * 1.5; }
      else if (dir === 2) { cx = x + w - s; cy = y + h - s; start = 0; }
      else { cx = x + s; cy = y + h - s; start = Math.PI * 0.5; }
      ctx.arc(cx, cy, s, start, start + Math.PI / 2);
      if (w > h) {
        if (dir === 0 || dir === 3) x += s;
        w -= s;
      } else {
        if (dir === 0 || dir === 1) y += s;
        h -= s;
      }
      dir = (dir + 1) % 4;
      if (w < 2 || h < 2) break;
    }
    ctx.stroke();
  }

  /**
   * ctx    — overlay canvas 2d context (already cleared)
   * R      — {x,y,w,h} the actual PICTURE rect in canvas pixels
   * state  — {guide, spiralFlip, showWeight}
   * m      — latest analyze() result, or null
   */
  function drawGuides(ctx, R, state, m) {
    const g = state.guide || "thirds";
    const X = (f) => R.x + R.w * f;
    const Y = (f) => R.y + R.h * f;

    CLEAN = !!state.clean;
    ctx.save();
    if (CLEAN) ctx.globalAlpha = 0.5;
    try {
      drawGuidesInner(ctx, R, state, m, g, X, Y);
    } finally {
      ctx.restore();
      CLEAN = false;
    }
  }

  function drawGuidesInner(ctx, R, state, m, g, X, Y) {

    if (g === "thirds" || g === "phi") {
      const fs = g === "thirds" ? [1 / 3, 2 / 3] : [0.382, 0.618];
      stroke(ctx, () => {
        for (const f of fs) {
          line(ctx, X(f), R.y, X(f), R.y + R.h);
          line(ctx, R.x, Y(f), R.x + R.w, Y(f));
        }
      });
      for (const fx of fs) for (const fy of fs) dot(ctx, X(fx), Y(fy), 3, "rgba(255,180,84,0.95)");
    }

    if (g === "spiral") {
      stroke(ctx, () => drawSpiral(ctx, R, state.spiralFlip || 0), "rgba(255,180,84,0.95)", 1.5);
      stroke(ctx, () => {
        line(ctx, X(0.618), R.y, X(0.618), R.y + R.h);
        line(ctx, R.x, Y(0.618), R.x + R.w, Y(0.618));
      }, "rgba(255,255,255,0.35)");
      label(ctx, `spiral ${(state.spiralFlip || 0) % 4 + 1}/4  ·  ⌥O to flip`, R.x + 8, R.y + 20);
    }

    if (g === "triangle") {
      stroke(ctx, () => {
        line(ctx, R.x, R.y, R.x + R.w, R.y + R.h); // main diagonal
      }, "rgba(255,180,84,0.95)", 1.5);
      // perpendiculars from the other two corners onto that diagonal
      const dx = R.w, dy = R.h;
      const len2 = dx * dx + dy * dy;
      for (const c of [{ x: R.x + R.w, y: R.y }, { x: R.x, y: R.y + R.h }]) {
        const t = ((c.x - R.x) * dx + (c.y - R.y) * dy) / len2;
        const fx = R.x + t * dx, fy = R.y + t * dy;
        stroke(ctx, () => line(ctx, c.x, c.y, fx, fy));
        dot(ctx, fx, fy, 3, "rgba(255,180,84,0.95)");
      }
    }

    if (g === "dynsym") {
      stroke(ctx, () => {
        line(ctx, R.x, R.y, R.x + R.w, R.y + R.h);
        line(ctx, R.x + R.w, R.y, R.x, R.y + R.h);
      }, "rgba(255,255,255,0.6)");
      // reciprocals: each corner to the midpoints of the opposite sides
      stroke(ctx, () => {
        line(ctx, R.x, R.y, R.x + R.w, Y(0.5));
        line(ctx, R.x, R.y, X(0.5), R.y + R.h);
        line(ctx, R.x + R.w, R.y, R.x, Y(0.5));
        line(ctx, R.x + R.w, R.y, X(0.5), R.y + R.h);
        line(ctx, R.x, R.y + R.h, R.x + R.w, Y(0.5));
        line(ctx, R.x, R.y + R.h, X(0.5), R.y);
        line(ctx, R.x + R.w, R.y + R.h, R.x, Y(0.5));
        line(ctx, R.x + R.w, R.y + R.h, X(0.5), R.y);
      }, "rgba(255,180,84,0.55)");
      label(ctx, "dynamic symmetry armature", R.x + 8, R.y + 20);
    }

    if (g === "center") {
      stroke(ctx, () => {
        line(ctx, X(0.5), R.y, X(0.5), R.y + R.h);
        line(ctx, R.x, Y(0.5), R.x + R.w, Y(0.5));
      });
      for (const r of [0.06, 0.12, 0.2]) {
        stroke(ctx, () => {
          ctx.beginPath();
          ctx.arc(X(0.5), Y(0.5), R.w * r, 0, Math.PI * 2);
          ctx.stroke();
        }, "rgba(255,180,84,0.6)");
      }
      label(ctx, "bullseye zones", R.x + 8, R.y + 20);
    }

    if (g === "diagonals") {
      stroke(ctx, () => {
        line(ctx, R.x, R.y, R.x + R.w, R.y + R.h);
        line(ctx, R.x + R.w, R.y, R.x, R.y + R.h);
      }, "rgba(255,255,255,0.75)");
      stroke(ctx, () => {
        line(ctx, R.x, R.y + R.h, R.x + R.w * 0.5, R.y);
        line(ctx, R.x + R.w, R.y + R.h, R.x + R.w * 0.5, R.y);
      }, "rgba(255,180,84,0.6)");
      label(ctx, "baroque / sinister diagonals", R.x + 8, R.y + 20);
    }

    if (g === "symmetry") {
      stroke(ctx, () => line(ctx, X(0.5), R.y, X(0.5), R.y + R.h), "rgba(255,180,84,0.95)", 1.5);
      stroke(ctx, () => line(ctx, R.x, Y(0.5), R.x + R.w, Y(0.5)), "rgba(255,255,255,0.4)");
      if (m) label(ctx, `symmetry ${m.symmetry}%`, X(0.5) + 8, R.y + 20);
    }

    if (g === "radial") {
      stroke(ctx, () => {
        for (let a = 0; a < 12; a++) {
          const th = (a * Math.PI) / 6;
          line(ctx, X(0.5), Y(0.5), X(0.5) + Math.cos(th) * R.w, Y(0.5) + Math.sin(th) * R.w);
        }
      }, "rgba(255,255,255,0.35)");
      for (const r of [0.1, 0.2, 0.32]) {
        stroke(ctx, () => {
          ctx.beginPath();
          ctx.arc(X(0.5), Y(0.5), R.w * r, 0, Math.PI * 2);
          ctx.stroke();
        }, "rgba(255,180,84,0.5)");
      }
    }

    if (g === "horizon") {
      stroke(ctx, () => {
        line(ctx, R.x, Y(1 / 3), R.x + R.w, Y(1 / 3));
        line(ctx, R.x, Y(2 / 3), R.x + R.w, Y(2 / 3));
      }, "rgba(255,255,255,0.5)");
      stroke(ctx, () => line(ctx, R.x, Y(0.28), R.x + R.w, Y(0.28)), "rgba(255,180,84,0.95)", 1.5);
      label(ctx, "eyeline", R.x + 8, Y(0.28) - 4);
      stroke(ctx, () => line(ctx, R.x, Y(0.08), R.x + R.w, Y(0.08)), "rgba(120,200,255,0.8)");
      label(ctx, "headroom limit", R.x + 8, Y(0.08) - 4);
      if (m && m.tilt_deg !== null && Math.abs(m.tilt_deg) > 1.5) {
        ctx.save();
        ctx.translate(X(0.5), Y(0.5));
        ctx.rotate((m.tilt_deg * Math.PI) / 180);
        stroke(ctx, () => line(ctx, -R.w / 2, 0, R.w / 2, 0), "rgba(242,114,111,0.9)", 1.5);
        ctx.restore();
        label(ctx, `tilt ${m.tilt_deg}°`, X(0.5) + 10, Y(0.5) - 6);
      }
    }

    if (g === "lookroom") {
      stroke(ctx, () => {
        line(ctx, X(1 / 3), R.y, X(1 / 3), R.y + R.h);
        line(ctx, X(2 / 3), R.y, X(2 / 3), R.y + R.h);
      }, "rgba(255,255,255,0.5)");
      ctx.save();
      ctx.fillStyle = "rgba(255,180,84,0.10)";
      ctx.fillRect(R.x, R.y, R.w / 3, R.h);
      ctx.fillRect(R.x + (R.w * 2) / 3, R.y, R.w / 3, R.h);
      ctx.restore();
      stroke(ctx, () => line(ctx, R.x, Y(0.12), R.x + R.w, Y(0.12)), "rgba(120,200,255,0.8)");
      label(ctx, "look room zones · headroom", R.x + 8, R.y + 20);
    }

    if (g === "crop") {
      // 9:16 centred inside the picture
      const ch = R.h;
      const cw = (ch * 9) / 16;
      const cx = R.x + (R.w - cw) / 2;
      ctx.save();
      ctx.fillStyle = "rgba(0,0,0,0.42)";
      ctx.fillRect(R.x, R.y, cx - R.x, R.h);
      ctx.fillRect(cx + cw, R.y, R.x + R.w - (cx + cw), R.h);
      ctx.restore();
      stroke(ctx, () => ctx.strokeRect(cx, R.y, cw, ch), "rgba(255,180,84,0.95)", 1.5);
      const sq = Math.min(R.w, R.h);
      stroke(ctx, () => ctx.strokeRect(R.x + (R.w - sq) / 2, R.y + (R.h - sq) / 2, sq, sq), "rgba(120,200,255,0.8)");
      label(ctx, "9:16 reel crop  ·  1:1", cx + 6, R.y + 20);
    }

    if (g === "quadrants") {
      stroke(ctx, () => {
        line(ctx, X(0.5), R.y, X(0.5), R.y + R.h);
        line(ctx, R.x, Y(0.5), R.x + R.w, Y(0.5));
        line(ctx, X(0.25), R.y, X(0.25), R.y + R.h);
        line(ctx, X(0.75), R.y, X(0.75), R.y + R.h);
        line(ctx, R.x, Y(0.25), R.x + R.w, Y(0.25));
        line(ctx, R.x, Y(0.75), R.x + R.w, Y(0.75));
      }, "rgba(255,255,255,0.45)");
    }

    // ---- the detection layer, drawn on top of any guide ----
    if (state.showWeight && m && !m.error) {
      // visual weight
      dot(ctx, X(m.weight.x), Y(m.weight.y), 6, "rgba(90,209,155,0.95)");
      stroke(ctx, () => {
        ctx.beginPath();
        ctx.arc(X(m.weight.x), Y(m.weight.y), 16, 0, Math.PI * 2);
        ctx.stroke();
      }, "rgba(90,209,155,0.6)");
      // nearest anchor + the gap
      dot(ctx, X(m.nearest.x), Y(m.nearest.y), 4, "rgba(242,114,111,0.95)");
      stroke(ctx, () => line(ctx, X(m.weight.x), Y(m.weight.y), X(m.nearest.x), Y(m.nearest.y)),
        "rgba(242,114,111,0.8)");
      label(ctx, `weight → ${m.nearest.kind} ${Math.round(m.nearest.distance * 100)}%`,
        X(m.weight.x) + 20, Y(m.weight.y) - 8);

      // dominant lines
      for (const l of m.lines) {
        const px = R.x + l.px * R.w, py = R.y + l.py * R.h;
        const dx = l.dx * R.w * 2, dy = l.dy * R.h * 2;
        stroke(ctx, () => line(ctx, px - dx, py - dy, px + dx, py + dy),
          `rgba(120,200,255,${0.25 + 0.55 * l.strength})`);
      }
      if (m.vanishing_point) {
        const vx = X(m.vanishing_point.x), vy = Y(m.vanishing_point.y);
        dot(ctx, vx, vy, 5, "rgba(120,200,255,0.95)");
        label(ctx, "vanishing point", vx + 10, vy - 6);
      }
      if (m.light_pool && m.light_pool.area < 0.2) {
        dot(ctx, X(m.light_pool.x), Y(m.light_pool.y), 4, "rgba(255,240,150,0.9)");
      }
    }
  }

  // ================================================== live-overlay smoother =
  /**
   * One frame's reading is noisy: when two straight lines are almost equally
   * strong, the "strongest line" flips between them twice a second and the
   * overlay flickers. This averages the numbers across reads and shows a line
   * only once it has held for a couple of reads, so the overlay sits still
   * unless something actually changed.
   *
   * Only the LIVE overlay is smoothed. A marked or paused frame is stored raw,
   * because there the single-frame reading is the honest one.
   */
  class Smoother {
    constructor(alpha = 0.35) {
      this.a = alpha;
      this.prev = null;
      this.prevRawVp = null;
      this.history = [];
    }

    reset() {
      this.prev = null;
      this.prevRawVp = null;
      this.history = [];
    }

    push(m) {
      if (!m || m.error) return m;
      const out = JSON.parse(JSON.stringify(m));
      const p = this.prev;
      const mix = (n, o) => (typeof o === "number" ? o + this.a * (n - o) : n);

      if (p) {
        out.weight.x = +mix(m.weight.x, p.weight.x).toFixed(3);
        out.weight.y = +mix(m.weight.y, p.weight.y).toFixed(3);
        out.symmetry = +mix(m.symmetry, p.symmetry).toFixed(1);
        out.negative_space = +mix(m.negative_space, p.negative_space).toFixed(3);
        if (m.tilt_deg !== null && p.tilt_deg !== null) {
          out.tilt_deg = +mix(m.tilt_deg, p.tilt_deg).toFixed(1);
        }
      }

      // anchors re-derived from the smoothed weight, so the readout matches
      // the dot the viewer is looking at
      const fit = anchorFit(out.weight.x, out.weight.y);
      out.nearest = fit.nearest;
      out.distances = fit.distances;

      // a line must have shown up in earlier reads too
      this.history.push(m.lines || []);
      if (this.history.length > 3) this.history.shift();
      if (this.history.length === 3) {
        const older = this.history.slice(0, 2);
        out.lines = (m.lines || []).filter((l) =>
          older.some((prevLines) =>
            prevLines.some(
              (o) =>
                Math.abs(o.inclination - l.inclination) < 10 &&
                Math.hypot(o.px - l.px, o.py - l.py) < 0.12
            )
          )
        );
      }

      // A vanishing point seen in only one read is noise, so it has to show
      // up twice. The check runs against the previous RAW sighting, not the
      // previous smoothed output — comparing against the output would keep
      // reading back the suppressed null and the point could never appear.
      if (out.vanishing_point && this.prevRawVp) {
        const base = p && p.vanishing_point ? p.vanishing_point : this.prevRawVp;
        out.vanishing_point.x = +mix(m.vanishing_point.x, base.x).toFixed(3);
        out.vanishing_point.y = +mix(m.vanishing_point.y, base.y).toFixed(3);
      } else if (out.vanishing_point) {
        out.vanishing_point = null;
      }
      this.prevRawVp = m.vanishing_point || null;

      out.suggested = suggest(out);
      out.hints = hints(out);
      this.prev = out;
      return out;
    }
  }

  // ======================================================= camera movement ==
  const MW = 64;

  class Motion {
    constructor() {
      this.canvas = document.createElement("canvas");
      this.ctx = this.canvas.getContext("2d", { willReadFrequently: true });
      this.prev = null;
      this.h = 36;
      this.reset();
    }

    reset() {
      this.samples = [];
      this.prev = null;
    }

    feed(video, t) {
      if (!video || video.readyState < 2) return;
      const vw = video.videoWidth || 16, vh = video.videoHeight || 9;
      this.h = Math.max(18, Math.round((MW * vh) / vw));
      if (this.canvas.width !== MW || this.canvas.height !== this.h) {
        this.canvas.width = MW;
        this.canvas.height = this.h;
        this.prev = null;
      }
      try {
        this.ctx.drawImage(video, 0, 0, MW, this.h);
      } catch (e) { return; }
      let px;
      try {
        px = this.ctx.getImageData(0, 0, MW, this.h).data;
      } catch (e) { return; }

      const g = new Float32Array(MW * this.h);
      for (let i = 0, k = 0; i < px.length; i += 4, k++) {
        g[k] = (0.2126 * px[i] + 0.7152 * px[i + 1] + 0.0722 * px[i + 2]) / 255;
      }

      if (this.prev) {
        const v = this.blockMatch(this.prev, g, MW, this.h);
        if (v) this.samples.push(v);
        if (this.samples.length > 400) this.samples.shift();
      }
      this.prev = g;
    }

    /**
     * 3x3 grid of blocks, ±3px search — cheap optical flow.
     *
     * Two things matter for honesty here. A featureless block (sky, a wall,
     * out-of-focus background) matches equally well at every offset, so its
     * "motion" is noise — those blocks are skipped. And zero motion is the
     * baseline that a candidate must beat by a margin, otherwise ties in the
     * search order invent a drift that never happened.
     */
    blockMatch(a, b, w, h) {
      const RANGE = 3;
      const bw = Math.floor(w / 5), bh = Math.floor(h / 5);
      const vecs = [];

      for (let gy = 1; gy <= 3; gy++) {
        for (let gx = 1; gx <= 3; gx++) {
          const ox = gx * bw, oy = gy * bh;

          // is there anything here to track?
          let sum = 0, sq = 0, n = 0;
          for (let y = 0; y < bh; y += 2) {
            for (let x = 0; x < bw; x += 2) {
              const v = a[(oy + y) * w + (ox + x)];
              sum += v;
              sq += v * v;
              n++;
            }
          }
          if (!n) continue;
          const sd = Math.sqrt(Math.max(0, sq / n - (sum / n) ** 2));
          if (sd < 0.04) continue; // featureless — its match means nothing

          const err = (dx, dy) => {
            let e = 0;
            for (let y = 0; y < bh; y += 2) {
              for (let x = 0; x < bw; x += 2) {
                const ax = ox + x, ay = oy + y;
                const bx = ax + dx, by = ay + dy;
                if (bx < 0 || by < 0 || bx >= w || by >= h) { e += 1; continue; }
                e += Math.abs(a[ay * w + ax] - b[by * w + bx]);
              }
            }
            return e;
          };

          let bestE = err(0, 0), bdx = 0, bdy = 0;
          const margin = 0.02 * n; // must be a real improvement, not a tie
          for (let dy = -RANGE; dy <= RANGE; dy++) {
            for (let dx = -RANGE; dx <= RANGE; dx++) {
              if (dx === 0 && dy === 0) continue;
              const e = err(dx, dy);
              if (e < bestE - margin) { bestE = e; bdx = dx; bdy = dy; }
            }
          }
          vecs.push({ x: ox + bw / 2, y: oy + bh / 2, dx: bdx, dy: bdy });
        }
      }

      if (!vecs.length) return { mx: 0, my: 0, div: 0, spread: 0, flat: true };

      let mx = 0, my = 0;
      for (const v of vecs) { mx += v.dx; my += v.dy; }
      mx /= vecs.length; my /= vecs.length;
      // divergence: do the vectors spread out from the centre? (that's a zoom)
      let div = 0;
      for (const v of vecs) {
        const rx = v.x - w / 2, ry = v.y - h / 2;
        const len = Math.hypot(rx, ry) || 1;
        div += ((v.dx - mx) * rx + (v.dy - my) * ry) / len;
      }
      div /= vecs.length;
      let varSum = 0;
      for (const v of vecs) varSum += (v.dx - mx) ** 2 + (v.dy - my) ** 2;
      return {
        mx: +mx.toFixed(3),
        my: +my.toFixed(3),
        div: +div.toFixed(3),
        spread: +Math.sqrt(varSum / vecs.length).toFixed(3),
      };
    }

    /** classify the shot from everything fed since the last reset */
    summary() {
      const s = this.samples;
      if (s.length < 4) return { move: "unknown", samples: s.length };
      const avg = (f) => s.reduce((a, x) => a + f(x), 0) / s.length;
      const mx = avg((x) => x.mx), my = avg((x) => x.my);
      const absMx = avg((x) => Math.abs(x.mx)), absMy = avg((x) => Math.abs(x.my));
      const div = avg((x) => x.div), spread = avg((x) => x.spread);
      const energy = absMx + absMy;

      // sign consistency tells a deliberate move from a shake
      const consist = Math.abs(mx) / (absMx || 1);
      const consistY = Math.abs(my) / (absMy || 1);

      let move = "static";
      const parts = [];
      if (Math.abs(div) > 0.35) { move = "zoom"; parts.push(div > 0 ? "zoom in / push" : "zoom out / pull"); }
      if (absMx > 0.22 && consist > 0.55) { move = move === "static" ? "pan" : move; parts.push(mx > 0 ? "pan left→right" : "pan right→left"); }
      if (absMy > 0.22 && consistY > 0.55) { move = move === "static" ? "tilt" : move; parts.push(my > 0 ? "tilt down" : "tilt up"); }
      if (move === "static" && energy > 0.3 && spread > 0.7) { move = "handheld"; parts.push("handheld / unstable"); }
      if (move === "static" && energy > 0.18) { move = "drift"; parts.push("slight drift"); }
      if (move === "static") parts.push("locked off");

      return {
        move,
        detail: parts.join(" + "),
        energy: +energy.toFixed(3),
        divergence: +div.toFixed(3),
        spread: +spread.toFixed(3),
        samples: s.length,
      };
    }
  }

  // ============================================================ frame rate ==
  const Fps = {
    times: [],
    lastQuality: null,
    reset() {
      this.times = [];
      this.lastQuality = null;
    },
    note(mediaTime) {
      const t = this.times;
      if (t.length && Math.abs(mediaTime - t[t.length - 1]) > 1.5) t.length = 0; // seek
      t.push(mediaTime);
      if (t.length > 300) t.shift();
    },
    estimate(video) {
      const t = this.times;
      if (t.length < 20) return null;
      const deltas = [];
      let dupes = 0;
      for (let i = 1; i < t.length; i++) {
        const d = t[i] - t[i - 1];
        if (d <= 0.0005) { dupes++; continue; }
        if (d > 0 && d < 0.5) deltas.push(d);
      }
      if (deltas.length < 10) return null;
      deltas.sort((a, b) => a - b);
      const med = deltas[Math.floor(deltas.length / 2)];
      const fps = 1 / med;

      // spread of deltas: a clean single-rate source is tight, telecine isn't
      const q1 = deltas[Math.floor(deltas.length * 0.25)];
      const q3 = deltas[Math.floor(deltas.length * 0.75)];
      const jitter = (q3 - q1) / med;

      const CANON = [23.976, 24, 25, 29.97, 30, 48, 50, 59.94, 60];
      let source = CANON[0], bestD = Infinity;
      for (const c of CANON) {
        const d = Math.abs(c - fps);
        if (d < bestD) { bestD = d; source = c; }
      }

      let note = null;
      if (dupes / Math.max(1, t.length) > 0.12) note = "duplicate frames — looks like 24fps carried in a 30fps stream (telecine)";
      else if (jitter > 0.35) note = "frame timing uneven — variable frame rate or a re-encode";

      let container = null;
      try {
        const q = video && video.getVideoPlaybackQuality ? video.getVideoPlaybackQuality() : null;
        if (q) container = { total_frames: q.totalVideoFrames, dropped: q.droppedVideoFrames };
      } catch (e) { /* not supported */ }

      return {
        measured_fps: +fps.toFixed(2),
        likely_source_fps: source,
        confident: bestD < 0.8,
        duplicate_ratio: +(dupes / Math.max(1, t.length)).toFixed(3),
        jitter: +jitter.toFixed(3),
        note,
        playback: container,
      };
    },
  };

  FL.Compose = { analyze, drawGuides, GUIDES, Motion, Fps, Smoother, suggest, hints, anchorFit };
})();
