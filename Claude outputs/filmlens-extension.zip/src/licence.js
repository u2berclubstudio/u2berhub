/* FilmLens — licence gate (invite code + email).

   HONEST SCOPE, stated once here so nobody is misled later: this is access
   control, not copy protection. An extension's code sits on the user's own
   machine, so a technical person can delete the check and reload. What this
   does achieve is real: casual forwarding of the folder stops working, you
   learn who is actually using it, and you can revoke someone's access.

   How it works:
     1. The user enters email + invite code once, in the popup.
     2. The service worker posts them to your server.
     3. Your server checks the code and seats, then returns a token signed
        RS256 with a private key that never leaves your server.
     4. The extension verifies that token offline against the PUBLIC key
        below — so it can check a token but can never mint one.
     5. The token lasts 30 days. A daily background check refreshes it when
        your server is reachable, and the extension keeps working until the
        expiry if your server is down. One VPS hiccup must not stop forty
        people from studying a film.

   Runs in both the content script and the service worker, so it attaches to
   `self` rather than `window`. */
(function () {
  "use strict";

  const ROOT = typeof self !== "undefined" ? self : window;
  const FL = (ROOT.__FILMLENS = ROOT.__FILMLENS || {});

  const API_BASE = "https://tools.u2berclub.com/api/filmlens";
  const STORE_KEY = "fl_licence";
  const DEVICE_KEY = "fl_device";
  const GRACE_DAYS = 30;

  /**
   * Public key for verifying licence tokens. Replace this whole object with
   * the one printed by server/scripts/generate-keys.mjs — the extension
   * refuses to activate while the placeholder is here, so you cannot ship a
   * build that trusts nothing.
   */
  const PUBLIC_JWK = {
    kty: "RSA",
    n: "kNhj5Fnr2jVDmlmDUsDWXgftMIPvuBWgydgrNpB1bfWIe265yFKYZ0vskyyuQCyidtoY3Eq5ILS6Od9WOCaMvxWsTBWwPG7yI60ydW98xC7MEAEnVNcX-bMEiBedZN_zal6ewAMfdmM2rz40iocBIVmWsfExEqEnAZ_NEX2E9-cnxYhD9lUAaJydG4L5pf8V4WWyCb4OQD6T3sWDf7U-EURtY_D1KK9AH5upZvNez-JGq-321zHDeLCkGWkGdmWimnP00RSFjhA0mf3OyFnTU_ij8pacfXMHupP1CcfTNkXJ3VDw7KYmlehAA70BcT_a9aDoOX25TmUyGa19Og4uKw",
    e: "AQAB",
    alg: "RS256",
    ext: true,
  };

  const placeholderKey = () => PUBLIC_JWK.n.startsWith("REPLACE_WITH");

  // ---- small helpers ------------------------------------------------------
  function b64urlToBytes(str) {
    const pad = str.length % 4 ? "=".repeat(4 - (str.length % 4)) : "";
    const b64 = (str + pad).replace(/-/g, "+").replace(/_/g, "/");
    const bin = atob(b64);
    const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }

  function decodeSegment(seg) {
    return JSON.parse(new TextDecoder().decode(b64urlToBytes(seg)));
  }

  function storageGet(keys) {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.get(keys, (res) => resolve(res || {}));
      } catch (e) {
        resolve({});
      }
    });
  }

  function storageSet(obj) {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.set(obj, () => resolve(true));
      } catch (e) {
        resolve(false);
      }
    });
  }

  async function deviceId() {
    const got = await storageGet(DEVICE_KEY);
    if (got[DEVICE_KEY]) return got[DEVICE_KEY];
    const id =
      (crypto.randomUUID && crypto.randomUUID()) ||
      [...crypto.getRandomValues(new Uint8Array(16))].map((b) => b.toString(16).padStart(2, "0")).join("");
    await storageSet({ [DEVICE_KEY]: id });
    return id;
  }

  // ---- token verification -------------------------------------------------
  let keyPromise = null;
  function publicKey() {
    if (!keyPromise) {
      keyPromise = crypto.subtle.importKey(
        "jwk",
        PUBLIC_JWK,
        { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
        false,
        ["verify"]
      );
    }
    return keyPromise;
  }

  /**
   * Verify a licence token fully offline.
   * Returns { ok, payload, reason }.
   */
  async function verifyToken(token, expectDevice) {
    if (!token || typeof token !== "string") return { ok: false, reason: "no_token" };
    if (placeholderKey()) return { ok: false, reason: "no_public_key" };

    const parts = token.split(".");
    if (parts.length !== 3) return { ok: false, reason: "malformed" };

    let payload;
    try {
      payload = decodeSegment(parts[1]);
    } catch (e) {
      return { ok: false, reason: "malformed" };
    }

    let valid = false;
    try {
      valid = await crypto.subtle.verify(
        "RSASSA-PKCS1-v1_5",
        await publicKey(),
        b64urlToBytes(parts[2]),
        new TextEncoder().encode(`${parts[0]}.${parts[1]}`)
      );
    } catch (e) {
      return { ok: false, reason: "verify_failed" };
    }
    if (!valid) return { ok: false, reason: "bad_signature" };

    const now = Math.floor(Date.now() / 1000);
    if (!payload.exp || payload.exp < now) return { ok: false, payload, reason: "expired" };
    if (expectDevice && payload.did && payload.did !== expectDevice) {
      return { ok: false, payload, reason: "wrong_device" };
    }
    return { ok: true, payload };
  }

  /**
   * The gate the rest of the extension asks.
   * Returns { active, email, code, expires_at, days_left, reason }.
   */
  async function check() {
    const [store, did] = await Promise.all([storageGet(STORE_KEY), deviceId()]);
    const lic = store[STORE_KEY];
    if (!lic || !lic.token) {
      return { active: false, reason: placeholderKey() ? "no_public_key" : "not_activated", device_id: did };
    }
    const res = await verifyToken(lic.token, did);
    if (!res.ok) {
      return { active: false, reason: res.reason, email: lic.email, code: lic.code, device_id: did };
    }
    const daysLeft = Math.max(0, Math.ceil((res.payload.exp - Date.now() / 1000) / 86400));
    return {
      active: true,
      email: res.payload.sub || lic.email,
      code: res.payload.code || lic.code,
      expires_at: res.payload.exp,
      days_left: daysLeft,
      last_check: lic.last_check || null,
      device_id: did,
    };
  }

  // ---- network (service worker only) --------------------------------------
  async function activate(email, code) {
    if (placeholderKey()) {
      return { ok: false, error: "This build has no licence public key — run server/scripts/generate-keys.mjs first." };
    }
    const did = await deviceId();
    const clean = { email: String(email || "").trim().toLowerCase(), code: String(code || "").trim().toUpperCase() };
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(clean.email)) return { ok: false, error: "That email does not look right." };
    if (clean.code.length < 6) return { ok: false, error: "That invite code looks too short." };

    let res;
    try {
      res = await fetch(`${API_BASE}/activate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...clean, device_id: did, version: chrome.runtime.getManifest().version }),
      });
    } catch (e) {
      return { ok: false, error: "Could not reach the server. Check your connection and try again." };
    }

    let body = {};
    try { body = await res.json(); } catch (e) { /* non-JSON error page */ }

    if (!res.ok || !body.token) {
      return { ok: false, error: body.error || `Activation refused (${res.status}).` };
    }

    const verified = await verifyToken(body.token, did);
    if (!verified.ok) {
      return { ok: false, error: "The server's token failed verification — the keys may not match." };
    }

    await storageSet({
      [STORE_KEY]: {
        token: body.token,
        email: clean.email,
        code: clean.code,
        last_check: Date.now(),
      },
    });
    return { ok: true, email: clean.email, code: clean.code, days_left: Math.ceil((verified.payload.exp - Date.now() / 1000) / 86400) };
  }

  /** daily background refresh; silent and failure-tolerant by design */
  async function refresh() {
    const [store, did] = await Promise.all([storageGet(STORE_KEY), deviceId()]);
    const lic = store[STORE_KEY];
    if (!lic || !lic.token) return { ok: false, reason: "not_activated" };

    let res;
    try {
      res = await fetch(`${API_BASE}/verify`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token: lic.token, device_id: did }),
      });
    } catch (e) {
      // Server unreachable is NOT a failure — the token stays valid until it
      // expires. This is the whole point of the grace period.
      return { ok: false, reason: "offline", kept: true };
    }

    if (res.status === 401 || res.status === 403) {
      // explicit revocation — this one does lock the extension
      await storageSet({ [STORE_KEY]: null });
      return { ok: false, reason: "revoked" };
    }

    let body = {};
    try { body = await res.json(); } catch (e) { /* ignore */ }

    if (body.token) {
      const verified = await verifyToken(body.token, did);
      if (verified.ok) {
        await storageSet({
          [STORE_KEY]: { ...lic, token: body.token, last_check: Date.now() },
        });
        return { ok: true, refreshed: true };
      }
    }
    await storageSet({ [STORE_KEY]: { ...lic, last_check: Date.now() } });
    return { ok: true, refreshed: false };
  }

  async function deactivate() {
    const [store, did] = await Promise.all([storageGet(STORE_KEY), deviceId()]);
    const lic = store[STORE_KEY];
    await storageSet({ [STORE_KEY]: null });
    if (!lic || !lic.token) return { ok: true };
    try {
      await fetch(`${API_BASE}/deactivate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token: lic.token, device_id: did }),
      });
    } catch (e) { /* the local copy is gone either way */ }
    return { ok: true };
  }

  FL.Licence = {
    check,
    activate,
    refresh,
    deactivate,
    verifyToken,
    deviceId,
    API_BASE,
    GRACE_DAYS,
    hasPublicKey: () => !placeholderKey(),
  };
})();
