/* FilmLens — service worker.

   One job: capture the visible tab. A content script cannot do this, and tab
   capture is the only way to include what OTHER extensions have drawn on the
   page (a highlighter, a circle tool, a pointer overlay). Canvas capture sees
   just the video; tab capture sees the composited page.

   Chrome's rule: captureVisibleTab needs the `activeTab` permission, and
   `activeTab` is only granted when the user triggers the extension through
   Chrome itself — a keyboard command, the toolbar icon, or a context menu. A
   button inside the page does NOT grant it, no matter what host permissions
   the extension has. So the real path is the keyboard command below, and the
   in-page button is a fallback that tells you which key to press.

   DRM-protected video still comes back black here — that protection sits
   below the browser, not above it. */

importScripts("licence.js");
const Licence = self.__FILMLENS.Licence;

// ---- licence: activation, daily refresh, revocation --------------------
chrome.runtime.onMessage.addListener((msg, sender, respond) => {
  if (!msg) return;

  if (msg.type === "filmlens:licence.check") {
    Licence.check().then(respond);
    return true;
  }
  if (msg.type === "filmlens:licence.activate") {
    Licence.activate(msg.email, msg.code).then(respond);
    return true;
  }
  if (msg.type === "filmlens:licence.refresh") {
    Licence.refresh().then(respond);
    return true;
  }
  if (msg.type === "filmlens:licence.deactivate") {
    Licence.deactivate().then(respond);
    return true;
  }
});

// One check a day is plenty. Failing to reach the server does not lock
// anyone out — only an explicit revocation does.
if (chrome.alarms) {
  chrome.runtime.onInstalled.addListener(() => {
    chrome.alarms.create("filmlens-licence", { periodInMinutes: 60 * 24, delayInMinutes: 1 });
  });
  chrome.runtime.onStartup.addListener(() => {
    chrome.alarms.create("filmlens-licence", { periodInMinutes: 60 * 24, delayInMinutes: 1 });
  });
  chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === "filmlens-licence") Licence.refresh();
  });
}

function captureAndSend(tab) {
  if (!tab || tab.id === undefined) return;
  chrome.tabs.captureVisibleTab(tab.windowId, { format: "png" }, (dataUrl) => {
    const err = chrome.runtime.lastError;
    if (err || !dataUrl) {
      chrome.tabs.sendMessage(tab.id, {
        type: "filmlens:screenshotFailed",
        error: (err && err.message) || "capture returned nothing",
      });
      return;
    }
    chrome.tabs.sendMessage(tab.id, { type: "filmlens:screenshot", dataUrl });
  });
}

// The path that actually works: Chrome's own shortcut grants activeTab.
if (chrome.commands && chrome.commands.onCommand) {
  chrome.commands.onCommand.addListener((command) => {
    if (command !== "capture-screen") return;
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      captureAndSend(tabs && tabs[0]);
    });
  });
}

// Clicking the toolbar icon also grants activeTab, so it works as a backup.
// (The popup takes precedence, so this only fires if the popup is removed.)
if (chrome.action && chrome.action.onClicked) {
  chrome.action.onClicked.addListener((tab) => captureAndSend(tab));
}

// The in-page button asks through here. It usually fails on permissions —
// that failure is reported honestly so the panel can name the shortcut.
chrome.runtime.onMessage.addListener((msg, sender, respond) => {
  if (!msg || msg.type !== "filmlens:captureTab") return;

  const windowId = sender.tab ? sender.tab.windowId : chrome.windows.WINDOW_ID_CURRENT;
  try {
    chrome.tabs.captureVisibleTab(windowId, { format: "png" }, (dataUrl) => {
      const err = chrome.runtime.lastError;
      if (err || !dataUrl) {
        const message = (err && err.message) || "capture returned nothing";
        respond({
          ok: false,
          error: message,
          needsShortcut: /permission|activeTab|all_urls/i.test(message),
        });
        return;
      }
      respond({ ok: true, dataUrl });
    });
  } catch (e) {
    respond({ ok: false, error: String(e && e.message ? e.message : e) });
  }
  return true; // keep the channel open for the async respond
});
