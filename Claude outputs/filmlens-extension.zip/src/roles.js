/* FilmLens — role lenses.
   One film, six different pairs of eyes. Only ONE role is active at a time:
   that is the whole point. A DOP and a story writer notice different things,
   and trying to notice both at once means noticing neither. Switch with ⌥Q,
   and the six keys ⌥3–⌥8 change meaning with the role.

   Slot types:
     "mark" — one tap, logs the moment. The film does not stop.
     "card" — the film pauses, a small card asks its question, Enter saves.

   Machine prefill: for the DOP and Editor lenses the extension has already
   measured the answer (camera movement, framing, shot length), so those cards
   open pre-filled and you only confirm or correct. The writing lenses have no
   measurement behind them — there the card just asks, and the answer is
   entirely yours. That asymmetry is honest, not a gap.

   Every slot carries `help` — three short lines (what / when / why) shown on
   hover, so you never have to remember what a key does. */
(function () {
  "use strict";

  const FL = (window.__FILMLENS = window.__FILMLENS || {});

  const CHARGES = [
    "Hope", "Tension", "Fear", "Joy", "Loss",
    "Anger", "Calm", "Doubt", "Relief", "Suspicion",
  ];

  // ---- prefill helpers ----------------------------------------------------
  function framingFromMachine(ctx) {
    const s = (ctx.metrics && ctx.metrics.suggested) || [];
    if (s.includes("dead-center")) return "Dead centre";
    if (s.includes("center-composition")) return "Centre";
    if (s.includes("golden-ratio")) return "Phi / golden";
    if (s.includes("rule-of-thirds")) return "Thirds";
    if (s.includes("symmetrical")) return "Symmetry";
    if (s.includes("diagonals") || s.includes("leading-lines")) return "Diagonal";
    if (s.includes("off-center")) return "Off-centre";
    return null;
  }

  const MOVE_MAP = {
    static: "Static",
    pan: "Pan",
    tilt: "Tilt",
    zoom: "Zoom",
    handheld: "Handheld",
    drift: "Slight drift",
  };

  function movementFromMachine(ctx) {
    const sh = ctx.lastShot;
    if (!sh || !sh.camera) return null;
    return MOVE_MAP[sh.camera] || null;
  }

  function depthFromMachine(ctx) {
    const m = ctx.metrics;
    if (!m || typeof m.focus_ratio !== "number") return null;
    if (m.focus_ratio > 1.55) return "Shallow";
    if (m.focus_ratio < 1.15) return "Deep";
    return null;
  }

  function tiltNote(ctx) {
    const m = ctx.metrics;
    if (!m || m.tilt_deg === null || m.tilt_deg === undefined) return null;
    if (Math.abs(m.tilt_deg) < 3) return null;
    return `Measured: horizon tilted ${m.tilt_deg}° — this may be a dutch angle`;
  }

  function lengthEvidence(ctx) {
    const sh = ctx.lastShot;
    const asl = ctx.filmAsl;
    if (!sh || !sh.dur) return null;
    if (!asl) return `Measured: this shot ran ${sh.dur}s`;
    const rel = sh.dur / asl;
    const word =
      rel > 1.6 ? "much longer than the film's average"
        : rel < 0.6 ? "much shorter than average"
          : "about average";
    return `Measured: shot ${sh.dur}s · film average ${asl.toFixed(1)}s — ${word}`;
  }

  function sceneEvidence(ctx) {
    const sc = ctx.scene;
    if (!sc) return null;
    const dur = ctx.t - sc.start;
    return `Measured: this scene has run ${dur.toFixed(0)}s across ${sc.shot_count} shots`;
  }

  // ---- the six lenses -----------------------------------------------------
  const ROLES = [
    {
      id: "story",
      name: "Story Writer",
      icon: "🖋",
      blurb: "Structure — setup, payoff, stakes",
      pausePreferred: false,
      slots: [
        {
          id: "setup", short: "Setup", label: "A setup was planted", type: "mark",
          help: {
            what: "Marks the moment something is introduced that will matter later — an object, a skill, a promise, a wound.",
            when: "The instant you notice the film showing you something for no apparent reason yet.",
            why: "Setups are invisible on first watch. Logging them is the only way to catch the payoff later.",
          },
        },
        {
          id: "payoff", short: "Payoff", label: "A payoff landed — of which setup?", type: "card",
          linkTo: "setup",
          note: "What exactly cashed in?",
          help: {
            what: "Records a payoff and links it back to the setup you logged earlier.",
            when: "When something planted earlier suddenly pays off.",
            why: "The gap between setup and payoff is the writer's real craft — the link is what you study.",
          },
        },
        {
          id: "turn", short: "Turn", label: "The story turned", type: "mark", keyframe: true,
          help: {
            what: "Marks a story pivot — after this, the old situation cannot come back.",
            when: "5 or 6 times in a whole film. Not more.",
            why: "These few timestamps become the film's act map when laid over the pacing curve.",
          },
        },
        {
          id: "want-need", short: "Want/Need", label: "Want vs Need surfaced", type: "card",
          rows: [{ id: "which", label: "What surfaced?", chips: ["Want", "Need", "Clash of both"] }],
          note: "What does the character think they want, and what do they actually need?",
          help: {
            what: "Captures the gap between what a character chases and what would actually heal them.",
            when: "When a line or choice reveals either side of that gap.",
            why: "Every character arc lives in this gap. Spot it and you can build one yourself.",
          },
        },
        {
          id: "stakes", short: "Stakes", label: "Stakes raised — failing now costs more", type: "mark",
          help: {
            what: "Marks the moment the price of failure goes up.",
            when: "A deadline appears, an ally leaves, a secret gets out.",
            why: "Tension is not speed. Tension is cost. This is where you learn to raise it.",
          },
        },
        {
          id: "theme", short: "Theme", label: "The theme echoed", type: "mark",
          help: {
            what: "Marks a line, image or choice that restates what the film is really about.",
            when: "When a moment feels bigger than the plot it belongs to.",
            why: "Good films repeat their theme in different clothes. Collect the repeats.",
          },
        },
      ],
    },

    {
      id: "screenplay",
      name: "Screenplay Writer",
      icon: "📄",
      blurb: "Scene craft — charge, conflict, entry and exit",
      pausePreferred: false,
      slots: [
        {
          id: "value", short: "Charge", label: "The scene's charge changed", type: "card",
          rows: [
            { id: "in", label: "Charge at the start", chips: CHARGES },
            { id: "out", label: "Charge at the end", chips: CHARGES },
          ],
          evidence: sceneEvidence,
          help: {
            what: "Logs the emotional charge a scene opened on and the one it closed on.",
            when: "At the end of a scene, before the next one settles in.",
            why: "If the charge did not change, the scene did not work. This is the single most useful test in screenwriting.",
          },
        },
        {
          id: "conflict", short: "Conflict", label: "Conflict — who against what", type: "card",
          rows: [{ id: "type", label: "Type of conflict", chips: ["Person vs person", "Person vs circumstance", "Person vs self", "Hidden"] }],
          note: "Who wanted what?",
          help: {
            what: "Names the opposing forces inside the scene.",
            when: "Once per scene, usually mid-scene when the push becomes clear.",
            why: "Two different wants in one room is all a scene is. Naming them teaches you to build one.",
          },
        },
        {
          id: "expo", short: "Expo", label: "Exposition delivered invisibly", type: "mark",
          help: {
            what: "Marks information handed to the audience without a lecture.",
            when: "When you learn something important during an argument, a joke or a task.",
            why: "Collecting these cures the worst beginner habit — characters explaining the plot.",
          },
        },
        {
          id: "entry-exit", short: "In/Out", label: "Late entry / early exit", type: "card",
          rows: [{ id: "craft", label: "What was done", chips: ["Late entry", "Early exit", "Both", "Neither"] }],
          help: {
            what: "Records whether the scene started after the beginning and ended before the end.",
            when: "Right as a scene finishes.",
            why: "This one trick is most of what makes a script feel fast.",
          },
        },
        {
          id: "skippable", short: "Essential?", label: "What breaks without this scene", type: "card",
          rows: [{ id: "verdict", label: "Verdict", chips: ["Essential", "Could be cut", "Not sure"] }],
          note: "Why?",
          help: {
            what: "Your judgement on whether the film survives without this scene.",
            when: "At the end of a scene, honestly.",
            why: "Learning to spot a weak scene matters as much as spotting a great one.",
          },
        },
        {
          id: "act", short: "Act break", label: "Act break / sequence ended", type: "mark",
          help: {
            what: "Marks a structural seam — the end of an act or a sequence.",
            when: "When a chunk of the film clearly closes and a new one opens.",
            why: "Your marks plus the measured pacing curve make the structure map in the report.",
          },
        },
      ],
    },

    {
      id: "dialogue",
      name: "Dialogue Writer",
      icon: "💬",
      blurb: "Lines — subtext, voice, silence",
      pausePreferred: false,
      slots: [
        {
          id: "subtext", short: "Subtext", label: "Said X, meant Y", type: "card",
          note: "What was said, and what was actually meant?",
          help: {
            what: "Captures a line whose surface meaning is not its real meaning.",
            when: "When a polite line lands like a threat, or praise lands like sabotage.",
            why: "Subtext is the whole difference between flat dialogue and dialogue people quote.",
          },
        },
        {
          id: "keeper", short: "Keeper", label: "A line worth keeping", type: "card",
          note: "Write the line",
          help: {
            what: "Stores a line you want to study or remember, in your own words.",
            when: "The moment a line makes you sit up.",
            why: "A collection of lines you personally love becomes your own style guide.",
          },
        },
        {
          id: "on-nose", short: "On-nose", label: "On the nose — said it straight", type: "mark",
          help: {
            what: "Marks dialogue that states the feeling or the plot point outright.",
            when: "When a character says exactly what they feel with no cover.",
            why: "Collecting the bad examples trains your ear faster than collecting the good ones.",
          },
        },
        {
          id: "voice", short: "Voice", label: "Only this character could say it", type: "mark",
          help: {
            what: "Marks a line that fits one character and nobody else.",
            when: "When the words carry the speaker's background, class or temper.",
            why: "Distinct voice is what stops every character sounding like the writer.",
          },
        },
        {
          id: "silence", short: "Silence", label: "Silence did the work", type: "mark",
          help: {
            what: "Marks a beat where saying nothing was the strongest choice.",
            when: "A pause, a look, a held breath instead of a line.",
            why: "Beginners over-write. This is the antidote.",
          },
        },
        {
          id: "expo-line", short: "Hidden info", label: "The line smuggled information", type: "mark",
          help: {
            what: "Marks a line that quietly delivers a fact you will need later.",
            when: "When you only realise afterwards that you were told something.",
            why: "This is how exposition is supposed to travel.",
          },
        },
      ],
    },

    {
      id: "dop",
      name: "Cinematographer / DOP",
      icon: "🎥",
      blurb: "The frame — size, angle, movement, light",
      pausePreferred: true,
      slots: [
        {
          id: "size", short: "Shot size", label: "Shot size, and why that size", type: "card",
          rows: [
            { id: "size", label: "Size", chips: ["ECU", "Close-up", "Medium CU", "Medium", "Medium wide", "Wide", "Extreme wide"] },
            { id: "why", label: "Why this size?", chips: ["Loneliness", "Power", "Entrapment", "Show the space", "Intimacy", "Reaction", "Geography", "Scale"] },
          ],
          keyframe: true,
          help: {
            what: "Records how big the subject is in frame, and the reason the film chose that size.",
            when: "Pause on a frame that strikes you, then press.",
            why: "The size is easy to name; the reason is the lesson. A wide can mean loneliness or scale — only the scene tells you which.",
          },
        },
        {
          id: "framing", short: "Framing", label: "Which compositional structure", type: "card",
          rows: [{ id: "grid", label: "Grid", chips: ["Thirds", "Phi / golden", "Centre", "Dead centre", "Symmetry", "Diagonal", "Off-centre", "None"] }],
          prefill: (ctx) => ({ grid: framingFromMachine(ctx) }),
          keyframe: true,
          help: {
            what: "Records the structure the frame is built on. Opens pre-filled from the measurement.",
            when: "With the grid overlay on, paused on a frame.",
            why: "Confirming or correcting the machine is what trains your eye — far faster than guessing from scratch.",
          },
        },
        {
          id: "angle", short: "Angle", label: "Camera angle", type: "card",
          rows: [{ id: "angle", label: "Angle", chips: ["Low", "Eye level", "High", "Overhead", "Dutch", "Over-shoulder", "POV"] }],
          evidence: tiltNote,
          help: {
            what: "Records where the camera sits relative to the subject.",
            when: "On any frame where the height feels deliberate.",
            why: "Angle is the cheapest way a film tells you who holds the power.",
          },
        },
        {
          id: "movement", short: "Movement", label: "Camera movement", type: "card",
          rows: [{ id: "move", label: "Movement", chips: ["Static", "Pan", "Tilt", "Dolly", "Handheld", "Crane", "Zoom", "Slight drift"] }],
          prefill: (ctx) => ({ move: movementFromMachine(ctx) }),
          help: {
            what: "Records how the camera moved through the shot. Pre-filled from frame-to-frame measurement.",
            when: "Right after a shot ends, while it is fresh.",
            why: "A camera should move when the story moves. Logging both teaches you when it is motivated.",
          },
        },
        {
          id: "light", short: "Light", label: "Light and lens look", type: "card",
          rows: [
            { id: "dir", label: "Key light from", chips: ["Front", "Side", "Back / rim", "Top", "Practical", "Not sure"] },
            { id: "quality", label: "Quality", chips: ["Hard", "Soft"] },
            { id: "depth", label: "Depth", chips: ["Shallow", "Deep", "In between"] },
          ],
          prefill: (ctx) => ({ depth: depthFromMachine(ctx) }),
          help: {
            what: "Records where the light comes from, how hard it is, and how much stays in focus.",
            when: "On a frame with a clear lighting idea.",
            why: "Note: f-stop can never be read from a video. Depth here is measured from how soft the background is, which is the part that actually matters on screen.",
          },
        },
        {
          id: "frame", short: "Great frame", label: "Keep this frame", type: "mark", keyframe: true,
          help: {
            what: "Saves the frame plus its full measurement, with no questions asked.",
            when: "Any frame you want in your collection.",
            why: "Twenty of these from one film show you your own taste, in one glance.",
          },
        },
      ],
    },

    {
      id: "director",
      name: "Director",
      icon: "🎬",
      blurb: "Intent — feel, function, blocking",
      pausePreferred: false,
      slots: [
        {
          id: "feel", short: "Feel", label: "What should the audience feel here", type: "card",
          rows: [{ id: "feel", label: "Feel", chips: ["Fear", "Sympathy", "Anger", "Laughter", "Unease", "Relief", "Suspicion", "Sadness", "Thrill"] }],
          help: {
            what: "Records the feeling the scene is engineered to produce.",
            when: "At a moment where the intent is unmistakable.",
            why: "Directing is deciding the audience's feeling in advance. Compare this against your own Hooked/Drift marks — the mismatches teach the most.",
          },
        },
        {
          id: "job", short: "Scene's job", label: "What job is this scene doing", type: "card",
          rows: [{ id: "job", label: "Job", chips: ["Setup", "Character build", "Information", "Tension", "Relief", "Payoff", "Transition"] }],
          evidence: sceneEvidence,
          help: {
            what: "Names the work the scene performs for the film as a whole.",
            when: "Once per scene.",
            why: "Every scene must do a job. A scene that does two jobs badly should have been two scenes.",
          },
        },
        {
          id: "pov", short: "Whose scene", label: "Whose scene is this", type: "card",
          note: "Whose eyes are we watching through, and how do you know?",
          help: {
            what: "Records which character the scene belongs to.",
            when: "When you can feel the film siding with someone.",
            why: "Audiences feel through whoever the camera stands beside. Deciding that is a directing choice, not an accident.",
          },
        },
        {
          id: "blocking", short: "Blocking", label: "Blocking / staging", type: "mark", keyframe: true,
          help: {
            what: "Saves a frame where the actors' positions tell the story.",
            when: "When who stands where, or who turns away, says more than the dialogue.",
            why: "Blocking is the cheapest and most ignored tool a director has.",
          },
        },
        {
          id: "performance", short: "Performance", label: "Performance beat — without words", type: "mark",
          help: {
            what: "Marks something an actor does rather than says.",
            when: "A swallow, a glance, a hand that stops moving.",
            why: "These are the beats a director asks for on set. Noticing them is how you learn to ask.",
          },
        },
        {
          id: "why-here", short: "Why here", label: "Why is the camera here", type: "card",
          note: "What is the reason for showing it from this position?",
          keyframe: true,
          help: {
            what: "Records the justification for the camera's placement in this shot.",
            when: "On a shot where the position feels chosen, not default.",
            why: "Motivated framing is the line between a shot and a decision.",
          },
        },
      ],
    },

    {
      id: "editor",
      name: "Editor",
      icon: "✂️",
      blurb: "The cut — how much was kept, where it broke",
      pausePreferred: true,
      slots: [
        {
          id: "trim-in", short: "Trim earlier", label: "I would have cut in later than this", type: "mark",
          help: {
            what: "Marks a shot or scene that takes too long to get going.",
            when: "The moment you feel yourself waiting.",
            why: "Most beginner edits are slow at the front. Training that instinct is the whole job.",
          },
        },
        {
          id: "hold", short: "Hold longer", label: "I would have held this longer", type: "mark",
          help: {
            what: "Marks a moment cut away from too soon.",
            when: "When you wanted one more second and did not get it.",
            why: "Knowing when to hold is rarer, and more valuable, than knowing when to cut.",
          },
        },
        {
          id: "cut-on", short: "Cut on", label: "What the cut landed on", type: "card",
          rows: [{ id: "on", label: "Cut point", chips: ["On action", "On dialogue", "On a look", "On a reaction", "On sound", "No clear reason"] }],
          evidence: lengthEvidence,
          help: {
            what: "Records what motivated the cut point itself.",
            when: "Right after a cut you noticed.",
            why: "A cut on action disappears; a cut with no reason is felt. This is how you stop being felt.",
          },
        },
        {
          id: "transition", short: "Transition", label: "Type of transition", type: "card",
          rows: [{ id: "type", label: "Type", chips: ["Straight cut", "Dissolve", "Match cut", "Sound bridge", "J-cut", "L-cut", "Fade", "Wipe"] }],
          help: {
            what: "Records how one shot handed over to the next.",
            when: "On any transition that was not a plain cut.",
            why: "Sound bridges and J/L-cuts are what make an edit feel professional, and they are invisible until you look for them.",
          },
        },
        {
          id: "pace", short: "Pace", label: "How the pace feels here", type: "card",
          rows: [{ id: "pace", label: "Pace", chips: ["Right", "Slow", "Fast", "Deliberately slow"] }],
          evidence: lengthEvidence,
          help: {
            what: "Your verdict on the pace, next to the measured shot length and film average.",
            when: "Wherever the rhythm stands out, either way.",
            why: "Comparing your feeling against the measurement is how a gut instinct becomes a skill.",
          },
        },
        {
          id: "verdict", short: "Verdict", label: "Verdict on this scene", type: "card",
          rows: [{ id: "verdict", label: "Verdict", chips: ["Keep", "Trim 20%", "Trim 40%", "Halve it", "Drop it"] }],
          note: "Why?",
          evidence: sceneEvidence,
          help: {
            what: "The editor's call on the whole scene, with a reason.",
            when: "At the end of a scene.",
            why: "An editor's real power is deciding what never reaches the audience.",
          },
        },
      ],
    },
  ];

  const FREE = {
    id: "free",
    name: "Free watching",
    icon: "👀",
    blurb: "No lens — just Hooked / Drift and the generic markers",
    pausePreferred: false,
    slots: [],
  };

  const BY_ID = { free: FREE };
  for (const r of ROLES) BY_ID[r.id] = r;

  /** the roles on the ⌥Q rotation: Free first, then whatever is enabled */
  function rotation(enabled) {
    const on = Array.isArray(enabled) && enabled.length ? enabled : ROLES.map((r) => r.id);
    return ["free", ...ROLES.filter((r) => on.includes(r.id)).map((r) => r.id)];
  }

  function slotOf(roleId, n) {
    const r = BY_ID[roleId];
    if (!r || !r.slots.length) return null;
    return r.slots[n - 3] || null; // ⌥3 → slot 0
  }

  /** resolve prefill + evidence against the current measurement context */
  function resolve(slot, ctx) {
    const out = { prefill: {}, evidence: null };
    if (!slot) return out;
    try {
      if (typeof slot.prefill === "function") {
        const p = slot.prefill(ctx) || {};
        for (const [k, v] of Object.entries(p)) if (v) out.prefill[k] = v;
      }
      if (typeof slot.evidence === "function") out.evidence = slot.evidence(ctx) || null;
    } catch (e) {
      /* a prefill is a convenience, never a reason to block the card */
    }
    return out;
  }

  FL.Roles = { ROLES, FREE, BY_ID, rotation, slotOf, resolve, CHARGES };
})();
