/* Headless sanity tests — no browser needed.
   Covers the shot detector, the ZIP writer, scene grouping, the composition
   measurement engine, the guide renderer, camera-motion classification and
   frame-rate estimation.                                                    */
import fs from "node:fs";
import path from "node:path";
import vm from "node:vm";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const SRC = path.join(__dirname, "..", "src");

// ---- synthetic frame source ----------------------------------------------
// Every fake canvas asks FRAME(w, h) for its pixels, so the same generator
// serves the 48x27 detector and the 160xN composition engine.
let FRAME = () => null;

function rgba(w, h, fn) {
  const buf = new Uint8ClampedArray(w * h * 4);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const i = (y * w + x) * 4;
      const [r, g, b] = fn(x / w, y / h, x, y);
      buf[i] = r; buf[i + 1] = g; buf[i + 2] = b; buf[i + 3] = 255;
    }
  }
  return buf;
}

const flat = (r, g, b, noise = 0) => (w, h) =>
  rgba(w, h, () => {
    const n = noise ? (Math.random() - 0.5) * noise : 0;
    return [r + n, g + n, b + n];
  });

// ---- fake DOM -------------------------------------------------------------
function drawOps() {
  const ops = [];
  const rec = (name) => (...a) => { ops.push(name); return undefined; };
  return {
    ops,
    save: rec("save"), restore: rec("restore"),
    beginPath: rec("beginPath"), closePath: rec("closePath"),
    moveTo: rec("moveTo"), lineTo: rec("lineTo"), stroke: rec("stroke"),
    arc: rec("arc"), fill: rec("fill"), fillRect: rec("fillRect"),
    strokeRect: rec("strokeRect"), fillText: rec("fillText"),
    clearRect: rec("clearRect"), translate: rec("translate"),
    rotate: rec("rotate"), scale: rec("scale"), setTransform: rec("setTransform"),
    measureText: () => ({ width: 40 }),
    drawImage(src) { if (!FRAME) throw new Error("no frame"); },
    getImageData(x, y, w, h) {
      const data = FRAME(w, h);
      if (!data) throw new Error("no frame");
      return { data, width: w, height: h };
    },
  };
}

function fakeCanvas() {
  const c = {
    width: 0, height: 0,
    _ctx: null,
    getContext() {
      if (!c._ctx) c._ctx = drawOps();
      return c._ctx;
    },
    toDataURL: () => "data:image/jpeg;base64,",
    toBlob: (cb) => cb(null),
  };
  return c;
}

const sandbox = {
  window: { __FILMLENS_TEST: true, devicePixelRatio: 1, addEventListener() {} },
  document: { createElement: () => fakeCanvas(), addEventListener() {}, querySelector: () => null },
  Blob, TextEncoder, atob, console, Math, performance,
  setInterval: () => 0, clearInterval: () => {}, setTimeout: () => 0,
  location: { href: "https://www.youtube.com/watch?v=test123" },
  chrome: { storage: { local: { get() {}, set() {}, remove() {} } } },
};
sandbox.globalThis = sandbox;
vm.createContext(sandbox);

for (const f of ["zip.js", "pdf.js", "detector.js", "tags.js", "roles.js", "compose.js", "content.js"]) {
  vm.runInContext(fs.readFileSync(path.join(SRC, f), "utf8"), sandbox, { filename: f });
}
const FL = sandbox.window.__FILMLENS;

let failures = 0;
function check(name, cond, extra = "") {
  if (cond) console.log(`  ok   ${name}`);
  else { console.log(`  FAIL ${name} ${extra}`); failures++; }
}

const video = { readyState: 4, videoWidth: 640, videoHeight: 360 };

// ======================================================= shot detector =====
console.log("\nshot detector");
{
  const d = new FL.ShotDetector({ sensitivity: 0.5, minShot: 0.3 });
  let t = 0;
  const cuts = [];
  const feed = (gen, n) => {
    FRAME = gen;
    for (let i = 0; i < n; i++) {
      const r = d.sample(video, t);
      if (r && r.cut) cuts.push(+t.toFixed(2));
      t += 0.08;
    }
  };
  feed(flat(40, 60, 120, 6), 25);
  feed(flat(200, 170, 90, 6), 25);
  feed(flat(30, 30, 30, 6), 25);
  check("detects both hard cuts", cuts.length === 2, `(got ${cuts.length}: ${cuts})`);
  check("cut lands at the shot boundary", cuts[0] > 1.8 && cuts[0] < 2.3, `(got ${cuts[0]})`);
}
{
  const d = new FL.ShotDetector({ sensitivity: 0.5, minShot: 0.3 });
  let t = 0, cuts = 0, phase = 0;
  for (let i = 0; i < 80; i++) {
    phase += 2.2;
    FRAME = (w, h) => rgba(w, h, (fx, fy, x) => {
      const v = 90 + 70 * Math.sin((x + phase) * 0.35);
      return [v, v * 0.8, v * 0.55];
    });
    const r = d.sample(video, t);
    if (r && r.cut) cuts++;
    t += 0.08;
  }
  check("steady pan produces no false cuts", cuts === 0, `(got ${cuts})`);
}
{
  const d = new FL.ShotDetector({ sensitivity: 0.5, minShot: 0.3 });
  let t = 0, fades = 0;
  const step = (gen) => {
    FRAME = gen;
    const r = d.sample(video, t);
    if (r && r.transition === "fade") fades++;
    t += 0.08;
  };
  for (let i = 0; i < 20; i++) step(flat(150, 140, 130, 4));
  for (let i = 10; i >= 0; i--) step(flat(i * 15, i * 14, i * 13, 1));
  for (let i = 0; i < 12; i++) step(flat(0, 0, 0, 0));
  for (let i = 0; i < 20; i++) step(flat(180, 60, 40, 4));
  check("fade through black flagged once", fades === 1, `(got ${fades})`);
}

// ============================================================ zip writer ===
console.log("\nzip writer");
{
  const files = [
    { name: "session.json", data: JSON.stringify({ hello: "world" }) },
    { name: "scenes.csv", data: "i,start,end\n0,0,12.5\n" },
    { name: "frames/scene_000.jpg", data: new Uint8Array([0xff, 0xd8, 0xff, 0xe0]) },
  ];
  const buf = Buffer.from(await FL.zip.buildZip(files).arrayBuffer());
  fs.writeFileSync(path.join(__dirname, "test-out.zip"), buf);
  check("zip has local header signature", buf.readUInt32LE(0) === 0x04034b50);
  check("zip non-trivial size", buf.length > 150, `(${buf.length} bytes)`);
}

// ========================================================= scene grouping ==
console.log("\nscene grouping");
{
  const { sceneScore, sceneThreshold, colorDist } = FL;
  const TH = sceneThreshold(0.5);
  check("threshold scales with the slider",
    sceneThreshold(0) > TH && TH > sceneThreshold(1));

  const inside = sceneScore({
    sceneMean: { r: 95, g: 80, b: 70 }, sceneBright: 0.33, sceneAsl: 3.5,
    shotMean: { r: 100, g: 84, b: 72 }, shotBright: 0.34,
    elapsed: 2, captionGap: 0.4, sceneDur: 30, minScene: 12,
  });
  check("dialogue cut inside a scene does not split", inside < TH, `(${inside.toFixed(2)} vs ${TH})`);

  const obvious = sceneScore({
    sceneMean: { r: 95, g: 80, b: 70 }, sceneBright: 0.33, sceneAsl: 3.5,
    shotMean: { r: 60, g: 70, b: 110 }, shotBright: 0.27,
    elapsed: 2, captionGap: 2.5, sceneDur: 40, minScene: 12,
  });
  check("clear scene change splits", obvious >= TH, `(${obvious.toFixed(2)})`);

  const subtle = sceneScore({
    sceneMean: { r: 95, g: 80, b: 70 }, sceneBright: 0.33, sceneAsl: 1.8,
    shotMean: { r: 99, g: 83, b: 73 }, shotBright: 0.335,
    elapsed: 2, captionGap: 2.4, sceneDur: 60, minScene: 12,
  });
  check("same-palette scene change still splits", subtle >= TH, `(${subtle.toFixed(2)})`);

  const dB = colorDist({ r: 95, g: 80, b: 70 }, { r: 60, g: 70, b: 110 });
  const dC = colorDist({ r: 95, g: 80, b: 70 }, { r: 99, g: 83, b: 73 });
  check("old colour-only rule would have missed both", dB < 0.2 && dC < 0.2,
    `(${dB.toFixed(3)}, ${dC.toFixed(3)})`);
}

// ==================================================== composition engine ===
console.log("\ncomposition — measurement");
{
  // a textured bright block in the TOP-RIGHT third, flat mid-grey elsewhere
  FRAME = (w, h) => rgba(w, h, (fx, fy, x, y) => {
    const inBlock = fx > 0.55 && fx < 0.78 && fy > 0.22 && fy < 0.45;
    if (inBlock) {
      const v = 200 + 50 * (((x + y) % 3) - 1);
      return [v, v, v];
    }
    return [70, 70, 70];
  });
  const m = FL.Compose.analyze(video);
  check("analyze returns metrics", m && !m.error, m && m.error);
  check("visual weight lands in the top-right quadrant",
    m.weight.x > 0.5 && m.weight.y < 0.5, `(${m.weight.x} × ${m.weight.y})`);
  check("nearest anchor is a top-right anchor",
    m.nearest.x > 0.5 && m.nearest.y < 0.5, `(${m.nearest.kind} ${m.nearest.x},${m.nearest.y})`);
  check("suggests a placement technique",
    m.suggested.some((s) => ["rule-of-thirds", "golden-ratio", "off-center", "edge-composition"].includes(s)),
    `(${m.suggested.join(",")})`);
  check("hints are human-readable", Array.isArray(m.hints) && m.hints.length > 0);
}
{
  // left/right mirror — symmetry must read high
  FRAME = (w, h) => rgba(w, h, (fx, fy) => {
    const d = Math.abs(fx - 0.5);
    const v = 40 + 380 * d * (0.5 + 0.5 * Math.sin(fy * 20));
    return [v, v * 0.9, v * 0.8];
  });
  const sym = FL.Compose.analyze(video);
  FRAME = (w, h) => rgba(w, h, (fx, fy) => (fx < 0.4 ? [230, 220, 200] : [30, 30, 40]));
  const asym = FL.Compose.analyze(video);
  check("mirrored frame scores higher symmetry than one-sided",
    sym.symmetry > asym.symmetry + 20, `(${sym.symmetry} vs ${asym.symmetry})`);
  check("mirrored frame reads as symmetrical", sym.symmetry > 70, `(${sym.symmetry})`);
}
{
  // baked-in letterbox bars, top and bottom 20%
  FRAME = (w, h) => rgba(w, h, (fx, fy, x, y) => {
    if (fy < 0.2 || fy > 0.8) return [0, 0, 0];
    const v = 120 + 80 * Math.sin(x * 0.9);
    return [v, v * 0.8, v * 0.6];
  });
  const m = FL.Compose.analyze(video);
  check("letterbox detected", m.letterboxed === true);
  check("picture box excludes the bars",
    m.picture_box.y > 0.15 && m.picture_box.y < 0.25 && m.picture_box.h > 0.5 && m.picture_box.h < 0.68,
    `(y ${m.picture_box.y}, h ${m.picture_box.h})`);
  check("aspect widened by the crop", m.aspect > 2, `(${m.aspect})`);
}
{
  // strong vertical stripes
  FRAME = (w, h) => rgba(w, h, (fx, fy, x) => {
    const v = x % 12 < 3 ? 235 : 40;
    return [v, v, v];
  });
  const m = FL.Compose.analyze(video);
  check("vertical lines dominate over horizontal",
    m.line_types.vertical > m.line_types.horizontal,
    `(v ${m.line_types.vertical} / h ${m.line_types.horizontal})`);
  check("repetition detected", m.pattern_score > 0.6, `(${m.pattern_score})`);
  check("suggests vertical-lines or pattern",
    m.suggested.includes("vertical-lines") || m.suggested.includes("pattern-repetition"),
    `(${m.suggested.join(",")})`);
}
{
  // low-key frame: mostly black with a small bright pool
  FRAME = (w, h) => rgba(w, h, (fx, fy) => {
    const d = Math.hypot(fx - 0.4, fy - 0.5);
    return d < 0.09 ? [245, 235, 210] : [8, 8, 12];
  });
  const m = FL.Compose.analyze(video);
  check("dark frame flagged low-key", m.dark_ratio > 0.7, `(${m.dark_ratio})`);
  check("light pool located near the blob",
    m.light_pool && Math.abs(m.light_pool.x - 0.4) < 0.12, JSON.stringify(m.light_pool));
  check("suggests chiaroscuro or light-pool",
    m.suggested.includes("chiaroscuro") || m.suggested.includes("light-pool"),
    `(${m.suggested.join(",")})`);
}

// ======================================================== guide rendering ==
console.log("\ncomposition — guides");
{
  const R = { x: 0, y: 0, w: 1280, h: 720 };
  const m = FL.Compose.analyze(video); // whatever the last FRAME was
  let drew = 0;
  for (const g of FL.Compose.GUIDES) {
    const ctx = drawOps();
    try {
      FL.Compose.drawGuides(ctx, R, { guide: g.id, spiralFlip: 1, showWeight: true }, m);
      if (g.id !== "none" && ctx.ops.length > 0) drew++;
      if (g.id === "none" && ctx.ops.length >= 0) drew++;
    } catch (e) {
      check(`guide "${g.id}" renders`, false, e.message);
    }
  }
  check("every guide renders without throwing", drew === FL.Compose.GUIDES.length,
    `(${drew}/${FL.Compose.GUIDES.length})`);

  const ctx2 = drawOps();
  FL.Compose.drawGuides(ctx2, R, { guide: "thirds", showWeight: false }, null);
  check("guides render with no metrics available", ctx2.ops.includes("stroke"));
}

// ============================================ readout wording + smoothing ==
console.log("\nreadout wording");
{
  // a complete-enough metrics object to feed hints()/suggest() directly
  const fake = (over = {}) => ({
    weight: { x: 0.5, y: 0.5 },
    nearest: { kind: "center", x: 0.5, y: 0.5, distance: 0.04 },
    distances: { third: 0.18, phi: 0.14, center: 0.04 },
    symmetry: 56.6,
    balance: { left_right: 0.02, top_bottom: 0.03 },
    negative_space: 0.3,
    brightness: 0.4,
    tonal_contrast: 0.15,
    dark_ratio: 0.2,
    bright_ratio: 0.02,
    detail_density: 0.03,
    focus_ratio: 1.2,
    depth_bands: [1, 1, 1],
    figure_ground: 0.05,
    texture_contrast: 4,
    pattern_score: 0.2,
    light_pool: null,
    hues: [30],
    hue_spread: null,
    lines: [],
    line_types: { horizontal: 1, vertical: 0, diagonal: 0 },
    tilt_deg: 2.1,
    vanishing_point: null,
    aspect: 1.78,
    letterboxed: false,
    ...over,
  });

  const near = FL.Compose.hints(fake());
  check("4% from centre reads as nearly centred",
    /centre/i.test(near[0]) && !/kisi anchor par nahi/i.test(near[0]), near[0]);

  const dead = FL.Compose.hints(fake({ distances: { third: 0.2, phi: 0.16, center: 0.02 } }));
  check("2% from centre still reads dead centre", /dead centre/i.test(dead[0]), dead[0]);

  const thirds = FL.Compose.hints(fake({
    distances: { third: 0.03, phi: 0.06, center: 0.2 },
    nearest: { kind: "third", x: 0.667, y: 0.333, distance: 0.03 },
  }));
  check("3% from a third reads as on the thirds", /sits on the thirds/i.test(thirds[0]), thirds[0]);

  const nowhere = FL.Compose.hints(fake({
    distances: { third: 0.15, phi: 0.16, center: 0.22 },
    nearest: { kind: "third", x: 0.333, y: 0.333, distance: 0.15 },
  }));
  check("genuinely off-anchor still says so", /not on any anchor/i.test(nowhere[0]), nowhere[0]);

  check("4% from centre suggests center-composition",
    FL.Compose.suggest(fake()).includes("center-composition"));

  console.log("\nlive-overlay smoothing");
  const sm = new FL.Compose.Smoother(0.35);

  // a jumpy weight must be damped, not followed
  sm.push(fake({ weight: { x: 0.3, y: 0.5 } }));
  const jumped = sm.push(fake({ weight: { x: 0.7, y: 0.5 } }));
  check("weight jump is damped", jumped.weight.x > 0.3 && jumped.weight.x < 0.6,
    `(${jumped.weight.x})`);

  // a line that shows up in only one read must not be drawn
  const steady = { inclination: 12, strength: 1, px: 0.5, py: 0.5, dx: 1, dy: 0 };
  const oneOff = { inclination: -70, strength: 0.9, px: 0.2, py: 0.8, dx: 0, dy: 1 };
  const s2 = new FL.Compose.Smoother();
  s2.push(fake({ lines: [steady] }));
  s2.push(fake({ lines: [steady] }));
  const third = s2.push(fake({ lines: [steady, oneOff] }));
  check("persistent line survives", third.lines.some((l) => Math.abs(l.inclination - 12) < 2));
  check("one-frame flicker line is dropped",
    !third.lines.some((l) => Math.abs(l.inclination + 70) < 2),
    JSON.stringify(third.lines.map((l) => l.inclination)));

  // a vanishing point seen once is noise
  const s3 = new FL.Compose.Smoother();
  const vp = { x: 0.6, y: 0.5, lines: 3 };
  const first = s3.push(fake({ vanishing_point: vp }));
  check("first-sighting vanishing point suppressed", first.vanishing_point === null);
  const second = s3.push(fake({ vanishing_point: vp }));
  check("vanishing point shown once it persists", second.vanishing_point !== null);

  // anchors are re-derived from the smoothed weight, so dot and text agree
  const s4 = new FL.Compose.Smoother(1); // alpha 1 = follow immediately
  s4.push(fake({ weight: { x: 0.5, y: 0.5 } }));
  const moved = s4.push(fake({ weight: { x: 0.667, y: 0.333 } }));
  check("readout anchors follow the smoothed dot",
    moved.nearest.kind === "third", `(${moved.nearest.kind} ${moved.distances.third})`);
}

// ============================================================= clean mode ==
console.log("\nclean mode");
{
  const R = { x: 0, y: 0, w: 1280, h: 720 };
  const m = FL.Compose.analyze(video);

  const loud = drawOps();
  FL.Compose.drawGuides(loud, R, { guide: "spiral", spiralFlip: 0, showWeight: true }, m);
  const quiet = drawOps();
  FL.Compose.drawGuides(quiet, R, { guide: "spiral", spiralFlip: 0, showWeight: true, clean: true }, m);

  check("normal mode draws labels", loud.ops.includes("fillText"));
  check("clean mode draws no labels", !quiet.ops.includes("fillText"));
  check("clean mode still draws the guide", quiet.ops.includes("stroke"));
  check("clean mode dims via globalAlpha", quiet.ops.includes("save") && quiet.ops.includes("restore"));
}

// ======================================================== camera movement ==
console.log("\ncamera movement");
{
  const stripes = (offset) => (w, h) =>
    rgba(w, h, (fx, fy, x, y) => {
      const v = (x + offset) % 10 < 4 ? 220 : 40;
      const v2 = (y % 14 < 5) ? v : v * 0.75;
      return [v2, v2, v2];
    });

  const still = new FL.Compose.Motion();
  FRAME = stripes(0);
  for (let i = 0; i < 10; i++) still.feed(video, i * 0.16);
  check("locked-off shot reads static", still.summary().move === "static",
    JSON.stringify(still.summary()));

  const panning = new FL.Compose.Motion();
  for (let i = 0; i < 12; i++) {
    FRAME = stripes(i * 2);
    panning.feed(video, i * 0.16);
  }
  const ps = panning.summary();
  check("horizontal move reads as a pan", ps.move === "pan", JSON.stringify(ps));
  check("pan direction recorded", /pan/.test(ps.detail || ""), ps.detail);
}

// ============================================================= frame rate ==
console.log("\nframe rate");
{
  const Fps = FL.Compose.Fps;
  Fps.reset();
  for (let i = 0; i < 120; i++) Fps.note(i / 24);
  const est = Fps.estimate(null);
  check("24fps source measured", est && Math.abs(est.measured_fps - 24) < 0.6,
    est && String(est.measured_fps));
  check("source fps snapped to a standard rate", est && est.likely_source_fps === 24,
    est && String(est.likely_source_fps));
  check("confident on a clean source", est && est.confident === true);

  Fps.reset();
  // 24fps carried in a 30fps stream: every 5th frame repeats
  let t = 0;
  for (let i = 0; i < 150; i++) {
    Fps.note(t);
    if (i % 5 !== 0) t += 1 / 24;
  }
  const tel = Fps.estimate(null);
  check("duplicate frames detected (telecine)", tel && tel.duplicate_ratio > 0.1,
    tel && String(tel.duplicate_ratio));
  check("telecine note raised", tel && !!tel.note, tel && String(tel.note));
}

// ================================================================== tags ===
console.log("\ntag taxonomy");
{
  const T = FL.Tags;
  // 74 techniques from the source list; "static vs dynamic composition" is
  // carried as two separate tags because they are opposites, hence 75.
  check("full taxonomy present", T.TAGS.length === 75, `(${T.TAGS.length})`);
  check("10 groups", T.GROUPS.length === 10, `(${T.GROUPS.length})`);
  check("ids are unique", new Set(T.TAGS.map((x) => x.id)).size === T.TAGS.length);
  check("search finds by label", T.search("chiaro").some((x) => x.id === "chiaroscuro"));
  check("search finds by group", T.search("lighting").length >= 6);
  check("every group has at least one technique",
    T.GROUPS.every((g) => T.TAGS.some((t) => t.group === g)));
  check("machine-suggestable subset is a minority",
    T.TAGS.filter((t) => t.auto).length < T.TAGS.length / 2,
    `(${T.TAGS.filter((t) => t.auto).length}/${T.TAGS.length})`);
  // every id the engine can suggest must exist in the taxonomy
  const ids = new Set(T.TAGS.map((x) => x.id));
  const src = fs.readFileSync(path.join(SRC, "compose.js"), "utf8");
  const suggested = [...src.matchAll(/add\("([a-z0-9-]+)"\)/g)].map((m) => m[1]);
  const orphans = suggested.filter((s) => !ids.has(s));
  check("engine suggests only real tag ids", orphans.length === 0, `(${orphans.join(",")})`);
}

// ============================================================== roles =====
console.log("\nrole lenses");
{
  const R = FL.Roles;
  check("six lenses defined", R.ROLES.length === 6, `(${R.ROLES.length})`);
  check("every lens has exactly six slots",
    R.ROLES.every((r) => r.slots.length === 6),
    R.ROLES.map((r) => `${r.id}:${r.slots.length}`).join(" "));
  check("slot ids unique inside each lens",
    R.ROLES.every((r) => new Set(r.slots.map((s) => s.id)).size === 6));
  check("every slot is a mark or a card",
    R.ROLES.every((r) => r.slots.every((s) => s.type === "mark" || s.type === "card")));
  check("every card slot asks something (rows, note or link)",
    R.ROLES.every((r) => r.slots.every((s) =>
      s.type !== "card" || s.rows || s.note || s.linkTo)));
  check("the writing lenses prefer playing, DOP and Editor prefer pausing",
    R.BY_ID.dop.pausePreferred && R.BY_ID.editor.pausePreferred &&
    !R.BY_ID.story.pausePreferred && !R.BY_ID.dialogue.pausePreferred);

  // ⌥3–⌥8 map onto slots 0–5, and nothing outside that
  check("⌥3 maps to the first slot", R.slotOf("dop", 3).id === "size");
  check("⌥8 maps to the last slot", R.slotOf("dop", 8).id === "frame");
  check("⌥9 maps to nothing", R.slotOf("dop", 9) === null);
  check("free watching has no slots", R.slotOf("free", 3) === null);

  // rotation always offers Free, and respects what is enabled
  const rot = R.rotation(["dop", "editor"]);
  check("rotation starts at free watching", rot[0] === "free");
  check("rotation only includes enabled lenses",
    rot.length === 3 && rot.includes("dop") && rot.includes("editor"), rot.join(","));
  check("empty enabled list falls back to all lenses",
    R.rotation([]).length === 7, String(R.rotation([]).length));

  console.log("\nrole prefill from measurements");
  // DOP framing prefilled from what the maths suggested
  const framing = R.slotOf("dop", 4);
  const pf = R.resolve(framing, { metrics: { suggested: ["rule-of-thirds"] } });
  check("framing card prefilled from machine suggestion", pf.prefill.grid === "Thirds",
    JSON.stringify(pf.prefill));
  const pfCentre = R.resolve(framing, { metrics: { suggested: ["dead-center"] } });
  check("dead-centre suggestion maps to its own chip", pfCentre.prefill.grid === "Dead centre");

  // DOP movement prefilled from the detected camera move
  const moveSlot = R.slotOf("dop", 6);
  const pm = R.resolve(moveSlot, { lastShot: { camera: "pan" } });
  check("movement card prefilled from detected pan", pm.prefill.move === "Pan");
  const pmNone = R.resolve(moveSlot, { lastShot: null });
  check("no shot yet means no prefill", Object.keys(pmNone.prefill).length === 0);

  // light card prefilled from focus ratio
  const lightSlot = R.slotOf("dop", 7);
  check("shallow depth prefilled from focus ratio",
    R.resolve(lightSlot, { metrics: { focus_ratio: 2.1 } }).prefill.depth === "Shallow");
  check("deep focus prefilled from focus ratio",
    R.resolve(lightSlot, { metrics: { focus_ratio: 1.0 } }).prefill.depth === "Deep");

  // editor cards carry measured evidence, not a prefilled answer
  const pace = R.slotOf("editor", 7);
  const ev = R.resolve(pace, { lastShot: { dur: 8.4 }, filmAsl: 3.2 });
  check("editor pace card shows length evidence", /8.4/.test(ev.evidence || ""), ev.evidence);
  check("evidence names the film average", /3\.2/.test(ev.evidence || ""), ev.evidence);
  check("editor pace card does not pre-answer", Object.keys(ev.prefill).length === 0);

  // a broken prefill must never block the card
  const bad = R.resolve({ prefill: () => { throw new Error("boom"); } }, {});
  check("a throwing prefill is swallowed", bad.prefill && Object.keys(bad.prefill).length === 0);

  // the writing lenses have no machine answers at all — that is the design
  const writingSlots = ["story", "screenplay", "dialogue"].flatMap((id) => R.BY_ID[id].slots);
  check("no writing-lens slot claims a machine prefill",
    writingSlots.every((s) => typeof s.prefill !== "function"));

  // payoff links back to a setup in the same lens
  const payoff = R.slotOf("story", 4);
  check("payoff slot links to the setup slot", payoff.linkTo === "setup");
  check("the linked slot actually exists",
    R.BY_ID.story.slots.some((s) => s.id === payoff.linkTo));
}

// ================================================== help text coverage ====
console.log("\nhover help");
{
  const R = FL.Roles;
  const all = R.ROLES.flatMap((r) => r.slots);
  check("every role slot has help", all.every((s) => s.help),
    all.filter((s) => !s.help).map((s) => s.id).join(","));
  check("help always has what / when / why",
    all.every((s) => s.help.what && s.help.when && s.help.why));
  // short answers are fine ("Once per scene."); walls of text are not
  check("help lines are a few sentences, not a wall",
    all.every((s) => Object.values(s.help).every((v) => v.length > 12 && v.length < 300)),
    all.filter((s) => Object.values(s.help).some((v) => v.length >= 300)).map((s) => s.id).join(","));
  check("no help text is in Hinglish",
    all.every((s) => !/\b(karo|nahi|hai|kyun|dabao|mein|wala)\b/i.test(Object.values(s.help).join(" "))));
  check("no role label or chip is in Hinglish",
    R.ROLES.every((r) =>
      !/\b(karo|nahi|hai|kyun|dabao|mein|wala|kya|zaroori)\b/i.test(
        JSON.stringify({ n: r.name, b: r.blurb, s: r.slots.map((x) => [x.label, x.short, x.note, x.rows]) })
      )));
}

// ============================================================== PDF =======
console.log("\npdf writer");
{
  const jpegPath = path.join(__dirname, "fixture.jpg");
  const jpeg = fs.existsSync(jpegPath) ? new Uint8Array(fs.readFileSync(jpegPath)) : null;

  const doc = new FL.Pdf("FilmLens test report");
  doc.heading("Sholay — study report", 1);
  doc.text("Generated by the test harness.", { size: 9 });
  doc.heading("What the machine measured", 2);
  doc.kv("Shots detected", 1423);
  doc.kv("Average shot length", "3.4s");
  doc.text(
    "A long paragraph that has to wrap across more than one line so the wrapping maths is actually exercised rather than merely present, and it keeps going for a while to make sure a second and even a third line are produced.",
    { size: 10 }
  );
  if (jpeg) {
    const size = FL.pdfHelpers.jpegSize(jpeg);
    check("jpeg dimensions parsed from SOF marker", size && size.w > 0 && size.h > 0, JSON.stringify(size));
    doc.image(jpeg, 300);
  }
  // force a page break
  for (let i = 0; i < 70; i++) doc.text(`filler line ${i}`, { size: 9 });
  doc.heading("Editor", 2);
  doc.text("12:04  I would have cut in later than this", { size: 10, bold: true });

  const blob = doc.build();
  const buf = Buffer.from(await blob.arrayBuffer());
  const out = path.join(__dirname, "test-out.pdf");
  fs.writeFileSync(out, buf);

  check("pdf header present", buf.slice(0, 8).toString().startsWith("%PDF-1.4"));
  check("pdf ends with EOF", buf.slice(-8).toString().includes("%%EOF"));
  check("pdf has more than one page", (buf.toString("latin1").match(/\/Type \/Page[^s]/g) || []).length > 1,
    String((buf.toString("latin1").match(/\/Type \/Page[^s]/g) || []).length));
  check("non-latin characters are stripped, not emitted",
    !/[ऀ-ॿ]/.test(buf.toString("latin1")));
  check("emoji removed from pdf text", FL.pdfHelpers.latin1("🎥 Shot size") === " Shot size",
    JSON.stringify(FL.pdfHelpers.latin1("🎥 Shot size")));
  check("text wrapping produces multiple lines",
    doc.wrap("one two three four five six seven eight nine ten eleven twelve thirteen", 10, false, 120).length > 1);
}

// ======================================= licence: server ↔ extension =====
// The one integration that must not drift: tokens the Node server signs have
// to verify inside the extension's WebCrypto check, and nothing else must.
console.log("\nlicence signing round-trip");
{
  const nodeCrypto = await import("node:crypto");
  const { createRequire } = await import("node:module");
  const require = createRequire(import.meta.url);
  // only the token module — signing must be testable without a web framework
  const router = require(path.join(SRC, "..", "server", "filmlens-token.js"));

  const { privateKey, publicKey } = nodeCrypto.generateKeyPairSync("rsa", {
    modulusLength: 2048,
    publicKeyEncoding: { type: "spki", format: "pem" },
    privateKeyEncoding: { type: "pkcs8", format: "pem" },
  });
  const jwk = nodeCrypto.createPublicKey(publicKey).export({ format: "jwk" });

  // Swap in the test key whatever the shipped build carries — these tests have
  // to pass on a release build with a real customer key baked in, not just on
  // a fresh checkout with the placeholder.
  const licFile = fs.readFileSync(path.join(SRC, "licence.js"), "utf8");
  const swapModulus = (src, n) => {
    const out = src.replace(/n:\s*"[^"]+"/, `n: "${n}"`);
    if (out === src) throw new Error("could not find the PUBLIC_JWK modulus to patch");
    return out;
  };
  const licSrc = swapModulus(licFile, jwk.n);

  const store = {};
  const licSandbox = {
    self: {},
    crypto: globalThis.crypto,
    atob,
    TextEncoder,
    TextDecoder,
    JSON,
    Math,
    Date,
    console,
    fetch: async () => { throw new Error("offline in tests"); },
    chrome: {
      runtime: { getManifest: () => ({ version: "test" }) },
      storage: {
        local: {
          get(keys, cb) {
            const out = {};
            for (const k of [].concat(keys)) if (store[k] !== undefined) out[k] = store[k];
            cb(out);
          },
          set(obj, cb) { Object.assign(store, obj); cb && cb(); },
        },
      },
    },
  };
  licSandbox.globalThis = licSandbox;
  vm.createContext(licSandbox);
  vm.runInContext(licSrc, licSandbox, { filename: "licence.js" });
  const Lic = licSandbox.self.__FILMLENS.Licence;

  check("extension reports it has a public key", Lic.hasPublicKey() === true);

  const now = Math.floor(Date.now() / 1000);
  const good = router.signToken(
    { sub: "atul@example.com", code: "FL-A1B2-C3D4", did: "device-1", iat: now, exp: now + 2592000 },
    privateKey
  );

  const okRes = await Lic.verifyToken(good, "device-1");
  check("server-signed token verifies in the extension", okRes.ok === true, JSON.stringify(okRes));
  check("payload survives the round-trip",
    okRes.ok && okRes.payload.sub === "atul@example.com" && okRes.payload.code === "FL-A1B2-C3D4");

  const wrongDevice = await Lic.verifyToken(good, "device-2");
  check("a token from another device is refused",
    !wrongDevice.ok && wrongDevice.reason === "wrong_device", JSON.stringify(wrongDevice));

  const expired = router.signToken(
    { sub: "a@b.com", code: "FL-OLD", did: "device-1", iat: now - 100000, exp: now - 10 },
    privateKey
  );
  const expRes = await Lic.verifyToken(expired, "device-1");
  check("an expired token is refused", !expRes.ok && expRes.reason === "expired", JSON.stringify(expRes));

  // tamper with the payload, keep the signature
  const parts = good.split(".");
  const payload = JSON.parse(Buffer.from(parts[1], "base64url").toString());
  payload.code = "FL-FREE-RIDE";
  const forged = [
    parts[0],
    Buffer.from(JSON.stringify(payload)).toString("base64url"),
    parts[2],
  ].join(".");
  const forgedRes = await Lic.verifyToken(forged, "device-1");
  check("a tampered payload fails the signature check",
    !forgedRes.ok && forgedRes.reason === "bad_signature", JSON.stringify(forgedRes));

  // a token signed by a DIFFERENT key must not pass
  const other = nodeCrypto.generateKeyPairSync("rsa", {
    modulusLength: 2048,
    publicKeyEncoding: { type: "spki", format: "pem" },
    privateKeyEncoding: { type: "pkcs8", format: "pem" },
  });
  const impostor = router.signToken(
    { sub: "x@y.com", code: "FL-FAKE", did: "device-1", iat: now, exp: now + 1000 },
    other.privateKey
  );
  const impRes = await Lic.verifyToken(impostor, "device-1");
  check("a token from a different key is refused",
    !impRes.ok && impRes.reason === "bad_signature", JSON.stringify(impRes));

  check("garbage is refused", !(await Lic.verifyToken("not.a.token", "device-1")).ok);
  check("an empty token is refused", !(await Lic.verifyToken("", "device-1")).ok);

  // the gate itself
  const beforeActivation = await Lic.check();
  check("gate is closed before activation",
    beforeActivation.active === false && beforeActivation.reason === "not_activated",
    JSON.stringify(beforeActivation));
  check("a device id is generated and kept", typeof beforeActivation.device_id === "string" &&
    beforeActivation.device_id.length > 8);

  store.fl_licence = { token: good, email: "atul@example.com", code: "FL-A1B2-C3D4" };
  store.fl_device = "device-1";
  const afterActivation = await Lic.check();
  check("gate opens with a valid stored token", afterActivation.active === true, JSON.stringify(afterActivation));
  check("gate reports days remaining", afterActivation.days_left > 25 && afterActivation.days_left <= 30,
    String(afterActivation.days_left));

  store.fl_licence = { token: expired, email: "a@b.com", code: "FL-OLD" };
  check("gate closes on an expired token", (await Lic.check()).active === false);

  // the server's own verifier must agree
  check("server verifies its own token", !!router.verifyToken(good, privateKey));
  check("server rejects a forged token", router.verifyToken(forged, privateKey) === null);
  check("server rejects an expired token", router.verifyToken(expired, privateKey) === null);

  // and a build that still has the placeholder must refuse to work at all
  const placeholderSandbox = { ...licSandbox, self: {} };
  placeholderSandbox.globalThis = placeholderSandbox;
  vm.createContext(placeholderSandbox);
  vm.runInContext(swapModulus(licFile, "REPLACE_WITH_YOUR_PUBLIC_MODULUS"), placeholderSandbox, {
    filename: "licence-placeholder.js",
  });
  const Placeholder = placeholderSandbox.self.__FILMLENS.Licence;
  check("a build with the placeholder key reports no key", Placeholder.hasPublicKey() === false);
  const phCheck = await Placeholder.check();
  check("a build with the placeholder key stays locked",
    phCheck.active === false && phCheck.reason === "no_public_key", JSON.stringify(phCheck));
  const phActivate = await Placeholder.activate("a@b.com", "FL-TEST-CODE");
  check("a build with the placeholder key refuses to activate",
    phActivate.ok === false && /public key/i.test(phActivate.error), JSON.stringify(phActivate));
}

console.log(failures ? `\n${failures} FAILURE(S)\n` : "\nall checks passed\n");
process.exit(failures ? 1 : 0);
