/* FilmLens licence tokens — RS256, signed with node:crypto only.
 *
 * Kept separate from the Express router on purpose: token signing has nothing
 * to do with HTTP, it is the one piece that must agree exactly with the
 * extension's WebCrypto verification, and it can be unit-tested without
 * pulling in a web framework.
 *
 * The private key signs; the extension holds only the public key, so it can
 * check a licence but never issue one.
 */
"use strict";

const crypto = require("node:crypto");

const b64u = (buf) => Buffer.from(buf).toString("base64url");

/** payload → compact JWS (RS256) */
function signToken(payload, privateKeyPem) {
  const header = { alg: "RS256", typ: "JWT" };
  const data = `${b64u(JSON.stringify(header))}.${b64u(JSON.stringify(payload))}`;
  const sig = crypto.sign("sha256", Buffer.from(data), privateKeyPem);
  return `${data}.${b64u(sig)}`;
}

/**
 * Verify signature and expiry. Returns the payload, or null.
 * Accepts either the private key (public is derived) or a public key.
 */
function verifyToken(token, keyPem) {
  const parts = String(token || "").split(".");
  if (parts.length !== 3) return null;

  let pub;
  try {
    pub = crypto.createPublicKey(keyPem);
  } catch (e) {
    return null;
  }

  let ok = false;
  try {
    ok = crypto.verify(
      "sha256",
      Buffer.from(`${parts[0]}.${parts[1]}`),
      pub,
      Buffer.from(parts[2], "base64url")
    );
  } catch (e) {
    return null;
  }
  if (!ok) return null;

  try {
    const payload = JSON.parse(Buffer.from(parts[1], "base64url").toString("utf8"));
    if (!payload.exp || payload.exp < Math.floor(Date.now() / 1000)) return null;
    return payload;
  } catch (e) {
    return null;
  }
}

/** the public half, in the JWK shape the extension's src/licence.js expects */
function publicJwk(keyPem) {
  const jwk = crypto.createPublicKey(keyPem).export({ format: "jwk" });
  return { kty: jwk.kty, n: jwk.n, e: jwk.e, alg: "RS256", ext: true };
}

module.exports = { signToken, verifyToken, publicJwk };
