# The licence server is installed in u2berhub

The server side of FilmLens licensing now lives inside the hub repo
(`u2berhub`), not here. These files were written into it:

| File | What it is |
|---|---|
| `server/filmlens.js` | the licence API — an ESM Express router using the hub's own `q()` and `adminOnly` |
| `server/db/schema.sql` | two tables appended: `filmlens_codes`, `filmlens_activations` (created on boot by `initDb()`) |
| `server/index.js` | one import + `app.use("/api/filmlens", filmlens)` |
| `client/src/Admin.jsx` | a third admin tab, "FilmLens keys" |
| `scripts/filmlens-keys.mjs` | generates the signing key pair |
| `.gitignore` | ignores `.keys/` |

Only `filmlens-token.js` stays here, as the reference implementation of the
token format and the fixture the test harness verifies the extension against.
If the token format ever changes it must change in both places, and
`node test/harness.mjs` is what catches a mismatch.

## Endpoints

| Method | Path | Guard | Caller |
|---|---|---|---|
| POST | `/api/filmlens/activate` | public | the extension popup, once per profile |
| POST | `/api/filmlens/verify` | public | the extension, once a day |
| POST | `/api/filmlens/deactivate` | public | "Sign out this device" |
| GET | `/api/filmlens/health` | public | you, after deploying |
| GET/POST | `/api/filmlens/admin/*` | hub login + admin | the admin tab |

The three public endpoints carry a signed token, which is the authentication —
they need no hub session, because the extension has no cookie. Everything under
`/admin` goes through the hub's normal `auth(true)` + `adminOnly`, so it is the
same login you already use.

## Where the signing key lives

`server/filmlens.js` reads `.keys/filmlens-private.pem` from the repo root. It
is a file rather than an env var on purpose: the hub's `env.js` cannot hold
multi-line values, so a PEM pasted into `.env` would arrive with literal `\n`
and fail to parse. (`FILMLENS_PRIVATE_KEY` is still accepted, with the escapes
undone, if you ever need it.)

The public half of that pair is already baked into this extension's
`src/licence.js`. If you ever regenerate the key, every activated user has to
activate again, and the new public JWK must be pasted into `src/licence.js`.

## Deploying

```bash
# on the Mac
git add -A && git commit -m "FilmLens licence API + admin tab" && git push

# on the VPS, in the app folder (pm2 info u2berhub shows which one)
git pull
mkdir -p .keys && chmod 700 .keys
# put the private key there — see the note below
npm run build          # rebuilds the React client with the new admin tab
pm2 restart u2berhub   # schema.sql creates the two tables on boot

curl https://tools.u2berclub.com/api/filmlens/health
# { "ok": true, "signing_key": true, "token_days": 30 }
```

Nginx already proxies `location /` to the Node app, so `/api/filmlens` needs no
Nginx change.

**The private key.** It was generated on the Mac, and this extension build
trusts its public half. So copy that one file across:

```bash
scp .keys/filmlens-private.pem root@<vps>:<app-folder>/.keys/
ssh root@<vps> "chmod 600 <app-folder>/.keys/filmlens-private.pem"
```

If you would rather the key never travel, run `node scripts/filmlens-keys.mjs`
on the VPS instead and paste the public JWK it prints into `src/licence.js`
here — then the extension has to be re-zipped and re-shared.
